import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { initDatabase } from "./db/index.js";

import projectsRouter from "./routes/projects.js";
import postsRouter from "./routes/posts.js";
import fragmentsRouter from "./routes/fragments.js";
import ritualsRouter from "./routes/rituals.js";
import mindModelsRouter from "./routes/mindModels.js";
import vfsRouter from "./routes/vfs.js";
import vfsGitRouter from "./routes/vfsGit.js";
import aiRouter from "./routes/ai.js";
import mcpRouter from "./routes/mcp.js";
import skillsRouter from "./routes/skills.js";
import cacheRouter from "./routes/cache.js";
import evalRouter from "./routes/eval.js";
import feedRouter from "./routes/feed.js";
import { initVFSGitTable } from "./agent/vfsGitEngine.js";

const PORT = 3000;

export async function createApp() {
  await initDatabase();
  initVFSGitTable();

  const app = express();
  app.use(express.json({ limit: "10mb" }));

  // --- API Routes Registration ---
  app.use("/api/projects", projectsRouter);
  app.use("/api/posts", postsRouter);
  app.use("/api/fragments", fragmentsRouter);
  app.use("/api/rituals", ritualsRouter);
  app.use("/api/mind-models", mindModelsRouter);
  app.use("/api/vfs/git", vfsGitRouter);
  app.use("/api/vfs", vfsRouter);
  app.use("/api/ai", aiRouter);
  app.use("/api/mcp", mcpRouter);
  app.use("/api/skills", skillsRouter);
  app.use("/api/cache", cacheRouter);
  app.use("/api/eval", evalRouter);
  app.use("/api", feedRouter);

  // Health check endpoint
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", app: "NebulaTide Fullstack Server", timestamp: new Date().toISOString() });
  });

  // --- Vite Dev or Production Static Serve ---
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  return app;
}

export async function startServer() {
  const app = await createApp();
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`🌌 [NebulaTide Server] Express & SQLite running on http://0.0.0.0:${PORT}`);
  });
}
