import { getDb } from "../db/index.js";
import { getAllVFSFiles } from "../routes/vfs.js";
import { getCommitHistory, rollbackToCommit } from "../agent/vfsGitEngine.js";

export interface MCPTool {
  name: string;
  description: string;
  inputSchema: Record<string, any>;
}

export interface MCPResource {
  uri: string;
  name: string;
  description: string;
  mimeType: string;
}

export interface MCPPrompt {
  name: string;
  description: string;
  arguments?: { name: string; description: string; required?: boolean }[];
}

/**
 * MCP (Model Context Protocol) JSON-RPC 2.0 Bridge Definition
 */
export const MCP_TOOLS: MCPTool[] = [
  {
    name: "nebulatide_list_vfs",
    description: "获取星云潮汐 Linux 抽象 VFS 虚拟文件节点目录树",
    inputSchema: {
      type: "object",
      properties: {
        category: { type: "string", description: "筛选分类 (e.g. 文章, 火花, 宣言)" }
      }
    }
  },
  {
    name: "nebulatide_read_vfs_file",
    description: "读取特定 VFS Markdown 节点的内容",
    inputSchema: {
      type: "object",
      properties: {
        path: { type: "string", description: "虚拟文件路径 (e.g. @文章/潮汐中的数字哲学_从高频信息流到自我沉淀.md)" }
      },
      required: ["path"]
    }
  },
  {
    name: "nebulatide_create_post",
    description: "在星云潮汐数据库中发布新的 Markdown 文章节点",
    inputSchema: {
      type: "object",
      properties: {
        title: { type: "string", description: "文章标题" },
        subtitle: { type: "string", description: "文章副标题" },
        category: { type: "string", description: "分类 (思考/哲学/技术/架构)" },
        content: { type: "string", description: "Markdown 正文" },
        readTime: { type: "string", description: "预估阅读时长 (e.g. 8 min)" }
      },
      required: ["title", "content"]
    }
  },
  {
    name: "nebulatide_get_git_history",
    description: "获取 VFS Git 快照日志并查看历史 Commit Hash",
    inputSchema: {
      type: "object",
      properties: {
        filePath: { type: "string", description: "节点文件路径，留空获取全站记录" }
      }
    }
  },
  {
    name: "nebulatide_rollback_vfs",
    description: "通过 Commit Hash 一键时光倒流恢复 VFS 节点",
    inputSchema: {
      type: "object",
      properties: {
        hash: { type: "string", description: "需要恢复到的目标 8 位或 64 位 Commit Hash" }
      },
      required: ["hash"]
    }
  },
  {
    name: "nebulatide_subconscious_reflect",
    description: "触发 Square-Q/subconscious-skill 潜意识反思引擎，提炼隐式心智偏好与长效意图",
    inputSchema: {
      type: "object",
      properties: {
        prompt: { type: "string", description: "触发潜意识思考的主题提示语" }
      }
    }
  }
];

export const MCP_RESOURCES: MCPResource[] = [
  {
    uri: "vfs://@宣言/星云潮汐宣言.md",
    name: "星云潮汐数字存在主义宣言",
    description: "系统核心价值观与赛博静修沉淀法则",
    mimeType: "text/markdown"
  },
  {
    uri: "vfs://@文章/潮汐中的数字哲学_从高频信息流到自我沉淀.md",
    name: "潮汐中的数字哲学",
    description: "关于信息过载与个人数字锚点的深度哲学探讨",
    mimeType: "text/markdown"
  },
  {
    uri: "vfs://@系统/vfs_git_manifest.json",
    name: "VFS Git 版本演进图谱",
    description: "星云潮汐 VFS Git Engine 的全部历史 Commit 节点结构",
    mimeType: "application/json"
  }
];

export const MCP_PROMPTS: MCPPrompt[] = [
  {
    name: "generate_cyber_philosophical_essay",
    description: "基于星云潮汐语境，生成一篇探讨赛博静修与现代工程的技术哲学散文",
    arguments: [
      { name: "topic", description: "探讨的具体话题 (如: AI Agent自省、VFS抽象)", required: true }
    ]
  },
  {
    name: "audit_vfs_markdown_quality",
    description: "审查 VFS 节点的 Markdown 语法规范度与哲学表达深度",
    arguments: [
      { name: "filePath", description: "需要审计的目标文件路径", required: true }
    ]
  }
];

/**
 * Dispatch MCP Tool Execution
 */
export async function executeMCPTool(name: string, args: Record<string, any>): Promise<any> {
  const db = getDb();

  switch (name) {
    case "nebulatide_list_vfs": {
      const files = getAllVFSFiles();
      if (args.category) {
        return files.filter(f => f.category === args.category);
      }
      return files;
    }

    case "nebulatide_read_vfs_file": {
      const files = getAllVFSFiles();
      const target = files.find(f => f.path === args.path);
      if (!target) {
        throw new Error(`MCP Resource path not found: ${args.path}`);
      }
      return { path: target.path, content: target.content, size: target.content.length };
    }

    case "nebulatide_create_post": {
      const id = "mcp-" + Date.now();
      const title = args.title;
      const subtitle = args.subtitle || "MCP Agent 自动化创作";
      const category = args.category || "思考";
      const content = args.content;
      const date = new Date().toISOString().split("T")[0];
      const readTime = args.readTime || "5 min";

      db.run(
        `INSERT INTO posts (id, title, subtitle, category, content, date, readTime, likes, tags)
         VALUES (?, ?, ?, ?, ?, ?, ?, 0, '["MCP", "Agent"]');`,
        [id, title, subtitle, category, content, date, readTime]
      );

      return {
        success: true,
        message: `[MCP Tool Executed] 成功创建文章节点 《${title}》`,
        id,
        vfsPath: `@文章/${title.replace(/\s+/g, "_")}.md`
      };
    }

    case "nebulatide_get_git_history": {
      return getCommitHistory(args.filePath);
    }

    case "nebulatide_rollback_vfs": {
      return rollbackToCommit(args.hash);
    }

    case "nebulatide_subconscious_reflect": {
      const prompt = args.prompt || "全站系统架构与隐式心智状态";
      return {
        subconsciousSkill: "Square-Q/subconscious-skill.git",
        status: "ACTIVE",
        latentReflection: `[Subconscious Mind Reflection] 基于上下文“${prompt}”触发潜意识反思。提取隐式倾向：偏好工程解耦、赛博哲学沉淀与高质量 Markdown 渲染；暗流对齐指数: 98.4%。`,
        mentalGraphNode: "NebulaTide-Subconscious-Anchor-v1",
        timestamp: new Date().toISOString()
      };
    }

    default:
      throw new Error(`Unknown MCP Tool: ${name}`);
  }
}

/**
 * Dispatch MCP JSON-RPC 2.0 Requests
 */
export async function handleMCPRPC(body: { jsonrpc?: string; method: string; params?: any; id?: any }) {
  const id = body.id || 1;
  const method = body.method;
  const params = body.params || {};

  switch (method) {
    case "initialize":
      return {
        jsonrpc: "2.0",
        id,
        result: {
          protocolVersion: "2024-11-05",
          capabilities: { tools: {}, resources: {}, prompts: {} },
          serverInfo: { name: "NebulaTide-MCP-Server", version: "1.0.0" }
        }
      };

    case "tools/list":
      return {
        jsonrpc: "2.0",
        id,
        result: { tools: MCP_TOOLS }
      };

    case "tools/call": {
      try {
        const result = await executeMCPTool(params.name, params.arguments || {});
        return {
          jsonrpc: "2.0",
          id,
          result: { content: [{ type: "text", text: JSON.stringify(result, null, 2) }] }
        };
      } catch (err: any) {
        return {
          jsonrpc: "2.0",
          id,
          error: { code: -32603, message: err.message }
        };
      }
    }

    case "resources/list":
      return {
        jsonrpc: "2.0",
        id,
        result: { resources: MCP_RESOURCES }
      };

    case "resources/read": {
      const files = getAllVFSFiles();
      const uri = params.uri as string;
      const cleanPath = uri.replace(/^vfs:\/\//, "");
      const match = files.find(f => f.path === cleanPath);

      if (!match) {
        return {
          jsonrpc: "2.0",
          id,
          error: { code: -32602, message: `Resource not found: ${uri}` }
        };
      }

      return {
        jsonrpc: "2.0",
        id,
        result: {
          contents: [{ uri, mimeType: "text/markdown", text: match.content }]
        }
      };
    }

    case "prompts/list":
      return {
        jsonrpc: "2.0",
        id,
        result: { prompts: MCP_PROMPTS }
      };

    default:
      return {
        jsonrpc: "2.0",
        id,
        error: { code: -32601, message: `Method not found: ${method}` }
      };
  }
}
