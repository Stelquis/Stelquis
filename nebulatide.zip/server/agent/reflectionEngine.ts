/**
 * 🤖 NebulaTide Agentic Reflection & Tool Healing Engine
 * (用于自动校验、修护、补充 AI 生成的 Action Payload，确保 100% 可成功执行)
 */

export interface AgenticActionPayload {
  type: "CREATE_POST" | "CREATE_PROJECT" | "CREATE_CATEGORY" | string;
  label: string;
  payload: Record<string, any>;
  healingMetadata?: {
    healed: boolean;
    attempts: number;
    originalIssue?: string;
    healedAt?: string;
  };
}

/**
 * Agentic Reflection & Tool Healing Algorithm
 */
export function validateAndHealAgenticAction(rawAction: AgenticActionPayload | null): AgenticActionPayload | null {
  if (!rawAction) return null;

  let attempts = 0;
  let isHealed = false;
  const issues: string[] = [];

  const healedPayload: Record<string, any> = { ...rawAction.payload };

  // Validation & Healing Strategy per Action Type
  if (rawAction.type === "CREATE_POST") {
    // 1. Validate Title
    if (!healedPayload.title || typeof healedPayload.title !== "string" || healedPayload.title.trim().length === 0) {
      attempts++;
      isHealed = true;
      issues.push("缺少文章标题或字段截断");
      healedPayload.title = "星潮 AI 研讨极速草稿";
    } else {
      healedPayload.title = healedPayload.title.trim().replace(/^["'“‘]|["'”’]$/g, "");
    }

    // 2. Validate Category
    const validCategories = ["思考", "哲学", "技术", "架构", "设计", "随笔"];
    if (!healedPayload.category || !validCategories.includes(healedPayload.category)) {
      attempts++;
      isHealed = true;
      issues.push("分类不规范或未匹配，已自动重映射为 '思考'");
      healedPayload.category = "思考";
    }

    // 3. Validate Summary
    if (!healedPayload.summary || typeof healedPayload.summary !== "string") {
      attempts++;
      isHealed = true;
      issues.push("缺少摘要，已自动基于语义补充");
      healedPayload.summary = `关于《${healedPayload.title}》的思考草稿，由 NebulaTide 智囊智能重构生成。`;
    }
  } else if (rawAction.type === "CREATE_PROJECT") {
    // 1. Validate Title
    if (!healedPayload.title || typeof healedPayload.title !== "string" || healedPayload.title.trim().length === 0) {
      attempts++;
      isHealed = true;
      issues.push("缺少项目名称");
      healedPayload.title = "NebulaTide AI-Native Core";
    } else {
      healedPayload.title = healedPayload.title.trim().replace(/^["'“‘]|["'”’]$/g, "");
    }

    // 2. Validate Category
    if (!healedPayload.category) {
      healedPayload.category = "开源";
    }

    // 3. Validate Description
    if (!healedPayload.description || typeof healedPayload.description !== "string") {
      attempts++;
      isHealed = true;
      issues.push("缺少项目描述，自动填充模板");
      healedPayload.description = "由 AI 智囊推荐初始化的现代开源全栈项目。";
    }
  } else if (rawAction.type === "CREATE_CATEGORY") {
    if (!healedPayload.name || typeof healedPayload.name !== "string" || healedPayload.name.trim().length === 0) {
      attempts++;
      isHealed = true;
      issues.push("缺少分类名称");
      healedPayload.name = "AI架构";
    } else {
      healedPayload.name = healedPayload.name.trim().replace(/^["'“‘]|["'”’]$/g, "");
    }
  }

  // If healing was applied, attach healingMetadata
  return {
    type: rawAction.type,
    label: rawAction.label,
    payload: healedPayload,
    healingMetadata: {
      healed: isHealed,
      attempts: isHealed ? Math.max(1, attempts) : 0,
      originalIssue: issues.length > 0 ? issues.join("; ") : undefined,
      healedAt: isHealed ? new Date().toISOString() : undefined
    }
  };
}
