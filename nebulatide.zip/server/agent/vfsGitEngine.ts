import { getDb, saveDatabase } from "../db/index.js";
import crypto from "crypto";

export interface VFSCommit {
  hash: string;
  filePath: string;
  author: string;
  message: string;
  content: string;
  metadata?: Record<string, any>;
  createdAt: string;
  parentHash?: string;
}

export interface DiffLine {
  type: "added" | "removed" | "unchanged";
  oldLineNumber?: number;
  newLineNumber?: number;
  text: string;
}

/**
 * 确保 vfs_commits 数据表存在，并插入初始演进 Commit 节点
 */
export function initVFSGitTable() {
  const db = getDb();
  db.run(`
    CREATE TABLE IF NOT EXISTS vfs_commits (
      hash TEXT PRIMARY KEY,
      filePath TEXT,
      author TEXT,
      message TEXT,
      content TEXT,
      metadata TEXT,
      createdAt TEXT,
      parentHash TEXT
    );
  `);

  // 检查是否有记录，若无则注入初始 Seed Commits
  const stmt = db.prepare("SELECT COUNT(*) as count FROM vfs_commits");
  let count = 0;
  if (stmt.step()) {
    count = (stmt.getAsObject().count as number) || 0;
  }
  stmt.free();

  if (count === 0) {
    console.log("[VFS Git Engine] Seeding initial VFS Commit Snapshots...");

    // 1. Initial commit for 宣言
    const manifestoContent1 = `# 星云潮汐 · 数字存在主义宣言\n\n在信息爆炸与喧嚣碎片构筑的数字纪元中，我们拒绝做无意识的数据流转节点。`;
    const manifestoContent2 = `# 星云潮汐 · 数字存在主义宣言\n\n在信息爆炸与喧嚣碎片构筑的数字纪元中，我们拒绝做无意识的数据流转节点。\n\n## 核心理念 (Core Tenets)\n1. **赛博静修 (Cyber Solitude)**: 在高频链接的时代，保持独立的精神锚点与深度思考场域。\n2. **星云凝结 (Nebula Condensation)**: 零散的微小灵感（火花）终将凝结为深邃的体系（潮汐长文与代码沙盒）。\n3. **开源共享 (Open-Source Soul)**: 代码是现代哲学的实体呈现，知识与工具应当如同潮汐般自由流动。\n\n> "代码是现代哲学的实体呈现。" — 星云航行者`;

    const c1 = recordCommitInternal("@宣言/星云潮汐宣言.md", "Niu", "feat: 创生数字存在主义最初版草稿", manifestoContent1, { version: "0.9.0" }, "2026-07-26 14:20:00");
    recordCommitInternal("@宣言/星云潮汐宣言.md", "DeepSeek-V4 (AI Copilot)", "refactor: 扩展核心三大理念与赛博静修论断", manifestoContent2, { version: "1.0.0" }, "2026-07-27 01:10:00", c1.hash);

    // 2. Initial commit for 潮汐中的数字哲学
    const postContent1 = `---
title: 潮汐中的数字哲学：从高频信息流到自我沉淀
subtitle: 在信息爆炸时代，如何建立个人数字锚点与思考场域
category: 哲学
date: 2026-07-25
readTime: 8 min
tags: [数字存在主义, 深度思考, 赛博静修]
likes: 128
---

# 潮汐中的数字哲学

在信息爆炸的赛博纪元，我们每天接收海量的信息碎片。这些信息的无序涌动就像大洋中的无名浪花。`;

    const postContent2 = `---
title: 潮汐中的数字哲学：从高频信息流到自我沉淀
subtitle: 在信息爆炸时代，如何建立个人数字锚点与思考场域
category: 哲学
date: 2026-07-25
readTime: 8 min
tags: [数字存在主义, 深度思考, 赛博静修]
likes: 128
---

# 潮汐中的数字哲学

在信息爆炸的赛博纪元，我们每天接收海量的信息碎片。这些信息的无序涌动就像大洋中的无名浪花，若不加过滤与沉淀，个体便容易沦为数据的盲目流转节点。

## 一、高频流动的困境
当我们在社交网络与实时推文中疲于奔命，注意力被分割成微小的毫秒级片段。

## 二、建立数字锚点
星云潮汐博客系统的终极目的，是打造一个不被算法和广告污染的纯粹思考场域。在这里，代码与思想同频演进。`;

    const p1 = recordCommitInternal("@文章/潮汐中的数字哲学_从高频信息流到自我沉淀.md", "Niu", "docs: 初始化文章第一版大纲", postContent1, { author: "Niu" }, "2026-07-25 10:00:00");
    recordCommitInternal("@文章/潮汐中的数字哲学_从高频信息流到自我沉淀.md", "DeepSeek-V4 (AI Copilot)", "feat: AI 辅助增补‘高频流动的困境’与‘建立数字锚点’章节", postContent2, { author: "Niu", AIHealed: true }, "2026-07-27 02:00:00", p1.hash);

    saveDatabase();
  }
}

function recordCommitInternal(
  filePath: string,
  author: string,
  message: string,
  content: string,
  metadata: Record<string, any> = {},
  createdAtStr?: string,
  parentHash?: string
): VFSCommit {
  const db = getDb();
  const createdAt = createdAtStr || new Date().toISOString().replace("T", " ").split(".")[0];
  const hash = crypto
    .createHash("sha256")
    .update(`${filePath}:${createdAt}:${content}:${message}`)
    .digest("hex")
    .slice(0, 8);

  db.run(
    `INSERT INTO vfs_commits (hash, filePath, author, message, content, metadata, createdAt, parentHash)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    [hash, filePath, author, message, content, JSON.stringify(metadata), createdAt, parentHash || null]
  );

  return {
    hash,
    filePath,
    author,
    message,
    content,
    metadata,
    createdAt,
    parentHash
  };
}

/**
 * 记录新的 Commit 快照
 */
export function createCommit(
  filePath: string,
  author: string,
  message: string,
  content: string,
  metadata: Record<string, any> = {}
): VFSCommit {
  initVFSGitTable();
  const db = getDb();

  // Find parent hash if any exists for this file
  let parentHash: string | undefined = undefined;
  const stmt = db.prepare("SELECT hash FROM vfs_commits WHERE filePath = ? ORDER BY createdAt DESC LIMIT 1");
  stmt.bind([filePath]);
  if (stmt.step()) {
    parentHash = stmt.getAsObject().hash as string;
  }
  stmt.free();

  const commit = recordCommitInternal(filePath, author, message, content, metadata, undefined, parentHash);
  saveDatabase();
  return commit;
}

/**
 * 获取特定文件或全站的历史 Commit 列表
 */
export function getCommitHistory(filePath?: string): VFSCommit[] {
  initVFSGitTable();
  const db = getDb();
  const commits: VFSCommit[] = [];

  let query = "SELECT * FROM vfs_commits ORDER BY createdAt DESC";
  let params: any[] = [];

  if (filePath) {
    query = "SELECT * FROM vfs_commits WHERE filePath = ? ORDER BY createdAt DESC";
    params = [filePath];
  }

  const stmt = db.prepare(query);
  if (params.length > 0) stmt.bind(params);

  while (stmt.step()) {
    const row = stmt.getAsObject();
    commits.push({
      hash: row.hash as string,
      filePath: row.filePath as string,
      author: row.author as string,
      message: row.message as string,
      content: row.content as string,
      metadata: row.metadata ? JSON.parse(row.metadata as string) : {},
      createdAt: row.createdAt as string,
      parentHash: row.parentHash ? (row.parentHash as string) : undefined
    });
  }
  stmt.free();

  return commits;
}

/**
 * 根据 Commit Hash 查询详情
 */
export function getCommitByHash(hash: string): VFSCommit | null {
  initVFSGitTable();
  const db = getDb();
  const stmt = db.prepare("SELECT * FROM vfs_commits WHERE hash = ? LIMIT 1");
  stmt.bind([hash]);

  if (stmt.step()) {
    const row = stmt.getAsObject();
    stmt.free();
    return {
      hash: row.hash as string,
      filePath: row.filePath as string,
      author: row.author as string,
      message: row.message as string,
      content: row.content as string,
      metadata: row.metadata ? JSON.parse(row.metadata as string) : {},
      createdAt: row.createdAt as string,
      parentHash: row.parentHash ? (row.parentHash as string) : undefined
    };
  }
  stmt.free();
  return null;
}

/**
 * 计算两段 Markdown 文本的逐行 Line-by-Line Diff
 */
export function computeLineDiff(oldText: string, newText: string): DiffLine[] {
  const oldLines = oldText ? oldText.split("\n") : [];
  const newLines = newText ? newText.split("\n") : [];
  const diffs: DiffLine[] = [];

  let i = 0;
  let j = 0;
  let oldLineNum = 1;
  let newLineNum = 1;

  while (i < oldLines.length || j < newLines.length) {
    if (i < oldLines.length && j < newLines.length && oldLines[i] === newLines[j]) {
      diffs.push({
        type: "unchanged",
        oldLineNumber: oldLineNum++,
        newLineNumber: newLineNum++,
        text: oldLines[i]
      });
      i++;
      j++;
    } else if (j < newLines.length && (i >= oldLines.length || !oldLines.slice(i).includes(newLines[j]))) {
      diffs.push({
        type: "added",
        newLineNumber: newLineNum++,
        text: newLines[j]
      });
      j++;
    } else {
      diffs.push({
        type: "removed",
        oldLineNumber: oldLineNum++,
        text: oldLines[i]
      });
      i++;
    }
  }

  return diffs;
}

/**
 * 将指定 Commit 时光倒流并还原至数据库 (Rollback)
 */
export function rollbackToCommit(hash: string): { success: boolean; message: string; restoredCommit?: VFSCommit } {
  const targetCommit = getCommitByHash(hash);
  if (!targetCommit) {
    return { success: false, message: `找不到指定的 Commit Hash: ${hash}` };
  }

  const db = getDb();
  const filePath = targetCommit.filePath;

  try {
    // 根据 filePath 判断写入哪张数据库表
    if (filePath.startsWith("@文章/")) {
      // 匹配或者尝试在 posts 中寻找对应文章并更新 content
      const titleMatch = targetCommit.content.match(/^title:\s*(.+)$/m) || targetCommit.content.match(/^#\s*(.+)$/m);
      const title = titleMatch ? titleMatch[1].trim() : targetCommit.metadata?.title || "潮汐文章";

      db.run("UPDATE posts SET content = ? WHERE title = ? OR id = ?", [targetCommit.content, title, targetCommit.metadata?.id || ""]);
    } else if (filePath.startsWith("@火花/")) {
      if (targetCommit.metadata?.id) {
        db.run("UPDATE fragments SET content = ? WHERE id = ?", [targetCommit.content, targetCommit.metadata.id]);
      }
    } else if (filePath.startsWith("@项目/")) {
      if (targetCommit.metadata?.id) {
        db.run("UPDATE projects SET description = ? WHERE id = ?", [targetCommit.content, targetCommit.metadata.id]);
      }
    }

    // 记录一条新的 Rollback Commit 节点，保证 Commit 链连续
    const newRollbackCommit = createCommit(
      filePath,
      "VFS Time-Travel System",
      `⏪ 一键时光倒流恢复至 Commit [${hash.slice(0, 7)}]`,
      targetCommit.content,
      { rollbackFromHash: hash, timestamp: new Date().toISOString() }
    );

    saveDatabase();

    return {
      success: true,
      message: `已成功将 VFS 节点 [${filePath}] 时光倒流还原至 Commit [${hash.slice(0, 7)}] (${targetCommit.message})`,
      restoredCommit: newRollbackCommit
    };
  } catch (e: any) {
    return { success: false, message: `回滚失败: ${e.message}` };
  }
}
