import { validateAndHealAgenticAction } from "./reflectionEngine.ts";
import { lookupSemanticCache, saveToSemanticCache } from "./semanticCacheEngine.ts";
import { getAllSkills } from "./skillLoaderEngine.ts";
import { getAllVFSFiles } from "../routes/vfs.ts";

export interface EvalBenchmarkResult {
  id: string;
  timestamp: string;
  overallScore: number;
  totalDurationMs: number;
  passRate: number; // percentage 0-100
  testCasesCount: number;
  passedCount: number;
  failedCount: number;
  details: {
    testId: string;
    name: string;
    category: "ToolCalling" | "VFSSearch" | "SemanticCache" | "ContextPruning" | "MCPSchema";
    passed: boolean;
    durationMs: number;
    score: number;
    message: string;
    inputSample?: string;
    outputSample?: string;
  }[];
}

let lastEvalResult: EvalBenchmarkResult | null = null;
const evalHistory: EvalBenchmarkResult[] = [];

/**
 * Executes full suite of Agentic Sandboxing & Engine benchmarks
 */
export async function runAgentBenchmarkSuite(): Promise<EvalBenchmarkResult> {
  const startTime = Date.now();
  const testResults: EvalBenchmarkResult["details"] = [];

  // --- Test Case 1: Tool Calling Action Validation & Healing ---
  const tc1Start = Date.now();
  try {
    const rawBrokenAction = {
      type: "CREATE_POST",
      label: "创建新文章",
      payload: {
        title: "", // missing title
        category: "未知分类", // invalid category
      }
    };
    const healedResult = validateAndHealAgenticAction(rawBrokenAction as any);
    const passed = healedResult !== null && healedResult.healingMetadata?.healed === true && healedResult.payload.category === "思考";
    testResults.push({
      testId: 'tc-tool-calling-repair',
      name: 'Agent Action Reflection & Tool Healing 测试',
      category: 'ToolCalling',
      passed,
      durationMs: Date.now() - tc1Start,
      score: passed ? 100 : 0,
      message: passed ? '成功自省并重映射缺失标题与非法分类 (Category -> 思考)' : '未成功修复 Action Payload',
      inputSample: JSON.stringify(rawBrokenAction),
      outputSample: JSON.stringify(healedResult || {}),
    });
  } catch (err: any) {
    testResults.push({
      testId: 'tc-tool-calling-repair',
      name: 'Tool Calling 容错修复能力测试',
      category: 'ToolCalling',
      passed: false,
      durationMs: Date.now() - tc1Start,
      score: 0,
      message: `发生异常: ${err.message}`,
    });
  }

  // --- Test Case 2: VFS Node Path Indexing Speed ---
  const tc2Start = Date.now();
  try {
    const vfsNodes = getAllVFSFiles();
    const passed = Array.isArray(vfsNodes) && vfsNodes.length > 0;
    testResults.push({
      testId: 'tc-vfs-indexing',
      name: 'VFS 虚拟文件节点索引速度与树遍历测试',
      category: 'VFSSearch',
      passed,
      durationMs: Date.now() - tc2Start,
      score: passed ? 100 : 0,
      message: passed ? `读取 VFS 节点成功，找到 ${vfsNodes.length} 个活跃文件节点` : 'VFS 节点检索为空',
      outputSample: `Nodes: ${vfsNodes.slice(0, 3).map(n => n.path).join(', ')}...`,
    });
  } catch (err: any) {
    testResults.push({
      testId: 'tc-vfs-indexing',
      name: 'VFS 虚拟文件节点索引测试',
      category: 'VFSSearch',
      passed: false,
      durationMs: Date.now() - tc2Start,
      score: 0,
      message: `异常: ${err.message}`,
    });
  }

  // --- Test Case 3: Semantic Cache Precision & Speed ---
  const tc3Start = Date.now();
  try {
    const testPrompt = "评估测试：如何构建高精度的 Agent 语义缓存系统？";
    saveToSemanticCache(testPrompt, "deepseek-r1", {
      reasoning: "语义缓存分析过程",
      output: "语义缓存是一种利用余弦相似度匹配 Prompt 并毫秒级回放结果的技术。",
    });
    
    // Lookup for identical prompt
    const cacheHit1 = lookupSemanticCache(testPrompt, "deepseek-r1", 0.8);
    // Lookup for highly similar prompt
    const cacheHit2 = lookupSemanticCache("评估测试：怎样设计高精度的 Agent 语义缓存架构？", "deepseek-r1", 0.75);

    const passed = cacheHit1.hit && cacheHit2.hit;
    const score = (cacheHit1.hit ? 50 : 0) + (cacheHit2.hit ? 50 : 0);

    testResults.push({
      testId: 'tc-semantic-cache',
      name: '语义缓存 (Semantic Cache) 余弦相似度匹配测试',
      category: 'SemanticCache',
      passed,
      durationMs: Date.now() - tc3Start,
      score,
      message: passed 
        ? `两阶段测试均精准命中缓存 (相似度 Score: ${(cacheHit2.similarityScore ?? 0.85) * 100}%)`
        : `缓存命中失败 (Hit1: ${cacheHit1.hit}, Hit2: ${cacheHit2.hit})`,
      outputSample: cacheHit2.entry?.response?.output,
    });
  } catch (err: any) {
    testResults.push({
      testId: 'tc-semantic-cache',
      name: '语义缓存测试',
      category: 'SemanticCache',
      passed: false,
      durationMs: Date.now() - tc3Start,
      score: 0,
      message: `异常: ${err.message}`,
    });
  }

  // --- Test Case 4: Dynamic Skill Engine & Context Pruning ---
  const tc4Start = Date.now();
  try {
    const skills = getAllSkills();
    const passed = Array.isArray(skills) && skills.length > 0;
    testResults.push({
      testId: 'tc-skill-loader',
      name: 'Dynamic Skill Engine (技能动态加载器与上下文剪裁) 测试',
      category: 'ContextPruning',
      passed,
      durationMs: Date.now() - tc4Start,
      score: passed ? 100 : 0,
      message: passed ? `装载系统 Skill 成功，当前激活 ${skills.length} 项标准 Prompt 约束` : 'Skill 加载失败',
      outputSample: skills.map(s => s.name).join(', '),
    });
  } catch (err: any) {
    testResults.push({
      testId: 'tc-skill-loader',
      name: 'Skill Engine 测试',
      category: 'ContextPruning',
      passed: false,
      durationMs: Date.now() - tc4Start,
      score: 0,
      message: `异常: ${err.message}`,
    });
  }

  // Calculate Overall Stats
  const totalDurationMs = Date.now() - startTime;
  const passedCount = testResults.filter(t => t.passed).length;
  const testCasesCount = testResults.length;
  const passRate = Math.round((passedCount / testCasesCount) * 100);
  const overallScore = Math.round(testResults.reduce((acc, t) => acc + t.score, 0) / testCasesCount);

  const evalResult: EvalBenchmarkResult = {
    id: `eval_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
    timestamp: new Date().toISOString(),
    overallScore,
    totalDurationMs,
    passRate,
    testCasesCount,
    passedCount,
    failedCount: testCasesCount - passedCount,
    details: testResults,
  };

  lastEvalResult = evalResult;
  evalHistory.unshift(evalResult);
  if (evalHistory.length > 20) evalHistory.pop(); // Keep last 20 runs

  return evalResult;
}

export function getLastEvalResult(): EvalBenchmarkResult | null {
  return lastEvalResult;
}

export function getEvalHistory(): EvalBenchmarkResult[] {
  return evalHistory;
}
