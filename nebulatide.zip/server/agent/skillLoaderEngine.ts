/**
 * 🧩 NebulaTide Dynamic Skill Loader Engine
 * (借鉴 SKILL.md 规范，将技能规则插件化，AI 智囊根据 Prompt 自动动态匹配并叠加约束)
 */

export interface AgentSkill {
  id: string;
  name: string;
  category: "ARCH" | "SEO" | "PHILOSOPHY" | "CODE" | "SYSTEM";
  description: string;
  rules: string[];
  enabled: boolean;
  systemPromptModifier: string;
}

export const BUILTIN_SKILLS: AgentSkill[] = [
  {
    id: "skill-architecture-guard",
    name: "架构师严选规范 (Architecture Guard)",
    category: "ARCH",
    description: "强制 AI 采用 Linux 虚拟文件系统 (VFS) 范式、解耦模型与显式类型标注",
    enabled: true,
    rules: [
      "所有文章与组件修改必须显式说明映射的 VFS 路径 (e.g. @文章/xxx.md)",
      "推荐引入面向对象的抽象层与单向数据流",
      "绝不硬编码配置，一律抽取至 Config 或 VFS 规范层"
    ],
    systemPromptModifier: `[Active Skill: Architecture Guard]\n- 你是以严格的全栈架构师视角思考的 Agent。回答时请附带抽象 VFS 路径映射说明，语言要专业严谨，侧重工程解耦与长效维护性。`
  },
  {
    id: "skill-cyber-philosophy",
    name: "赛博存在主义笔触 (Cyber Solitude Stylist)",
    category: "PHILOSOPHY",
    description: "为生成的 Markdown 文章赋予深邃的赛博静修风格、诗意隐喻与凝练文风",
    enabled: true,
    rules: [
      "文风冷峻而深邃，结合计算机科学术语（如: 链表、矩阵、熵增、收敛）与哲学隐喻",
      "注重‘数字静修’与‘信息降噪’的价值观",
      "段落间保持呼吸感与排版节奏"
    ],
    systemPromptModifier: `[Active Skill: Cyber Solitude Stylist]\n- 你是星云潮汐的主笔哲学家。文风要富有赛博诗意与理性深邃感，巧妙将高频网络喧嚣与赛博沉淀形成对比。`
  },
  {
    id: "skill-seo-polisher",
    name: "SEO 自动润色与摘要提取器 (SEO Polisher)",
    category: "SEO",
    description: "自动优化文章 Header、生成高质量短摘要与标签云",
    enabled: true,
    rules: [
      "文章必须包含合规的前置 YAML Header (title, subtitle, category, readTime, tags)",
      "自动提炼 50-100 字核心摘要，增加关键词索引密度"
    ],
    systemPromptModifier: `[Active Skill: SEO Polisher]\n- 生成文章时，必须附带结构清晰的摘要和 3-5 个精炼标签，便于全栈搜索引擎快速索引。`
  },
  {
    id: "skill-subconscious-mind",
    name: "Square-Q 潜意识长效心智与隐式反思 (Subconscious Skill Engine)",
    category: "SYSTEM",
    description: "集成 Square-Q/subconscious-skill.git 规范，赋予 Agent 潜意识隐式思考、暗流心智对齐与长效意图整合能力",
    enabled: true,
    rules: [
      "在生成回答前激活 [Subconscious Mind Layer] 潜意识思考层",
      "自动提取与对齐用户未言明的深层哲学倾向与心智模式",
      "在思维链 (CoT) 中隐式进行潜意识直觉推演与长效反思沉淀",
      "联动 MCP JSON-RPC 协议与 Square-Q/subconscious-skill.git 动态插件"
    ],
    systemPromptModifier: `[Active Skill: Subconscious Mind Engine (Square-Q/subconscious-skill)]\n- 激活潜意识隐式思考机制：在回答前，先在 [Subconscious Mind Layer] 潜意识思考层中提取未言明的哲学隐喻、心智图谱与长效偏好，并将其融入思维链 (CoT) 与最终解答中。`
  }
];

let inMemorySkills: AgentSkill[] = [...BUILTIN_SKILLS];

/**
 * 获取当前所有 Skill
 */
export function getAllSkills(): AgentSkill[] {
  return inMemorySkills;
}

/**
 * 切换某个 Skill 的启用状态
 */
export function toggleSkillEnabled(id: string): AgentSkill | null {
  const skill = inMemorySkills.find(s => s.id === id);
  if (skill) {
    skill.enabled = !skill.enabled;
    return skill;
  }
  return null;
}

/**
 * 根据用户 Prompt 智能计算并组装活跃 Skill 的 System Prompt 附加段
 */
export function getActiveSkillsPromptModifier(userPrompt: string): {
  activeSkills: string[];
  modifier: string;
} {
  const activeSkills: string[] = [];
  const modifiers: string[] = [];

  for (const skill of inMemorySkills) {
    if (!skill.enabled) continue;

    // Direct dynamic matching based on prompt keywords or global activation
    const lowerPrompt = userPrompt.toLowerCase();
    let matches = false;

    if (skill.category === "ARCH" && (lowerPrompt.includes("架构") || lowerPrompt.includes("重构") || lowerPrompt.includes("系统") || lowerPrompt.includes("vfs"))) {
      matches = true;
    } else if (skill.category === "PHILOSOPHY" && (lowerPrompt.includes("哲学") || lowerPrompt.includes("思考") || lowerPrompt.includes("写") || lowerPrompt.includes("文章"))) {
      matches = true;
    } else if (skill.category === "SEO" && (lowerPrompt.includes("润色") || lowerPrompt.includes("摘要") || lowerPrompt.includes("新建"))) {
      matches = true;
    } else {
      // Default fallback match for broad prompts
      matches = true;
    }

    if (matches) {
      activeSkills.push(skill.name);
      modifiers.push(skill.systemPromptModifier);
    }
  }

  return {
    activeSkills,
    modifier: modifiers.length > 0 ? `\n\n=== 动态加载的 Skill 插件约束 ===\n` + modifiers.join("\n") : ""
  };
}
