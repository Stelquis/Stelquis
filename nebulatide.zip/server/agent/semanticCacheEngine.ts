import crypto from "crypto";

export interface SemanticCacheEntry {
  id: string;
  prompt: string;
  promptNormalized: string;
  model: string;
  response: {
    reasoning: string;
    output: string;
    agenticAction?: any;
    referencedFiles?: string[];
  };
  tokensSaved: number;
  hitCount: number;
  createdAt: string;
  lastAccessedAt: string;
}

export interface CacheStats {
  totalQueries: number;
  cacheHits: number;
  cacheMisses: number;
  hitRate: string;
  totalTokensSaved: number;
  entryCount: number;
}

// In-Memory & Persistence Store for Semantic Caching
let cacheEntries: SemanticCacheEntry[] = [];
let totalQueries = 0;
let cacheHits = 0;
let cacheMisses = 0;
let totalTokensSaved = 0;

/**
 * 规范化文本，用于相似度比对
 */
function normalizeText(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^\w\u4e00-\u9fa5]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

/**
 * 计算两段短文本的 N-Gram + Word Jaccard 混合语义相似度 (0.0 ~ 1.0)
 */
export function calculateSemanticSimilarity(textA: string, textB: string): number {
  const normA = normalizeText(textA);
  const normB = normalizeText(textB);

  if (normA === normB) return 1.0;
  if (!normA || !normB) return 0.0;

  // 1. 单词 / 词组 Jaccard 相似度
  const wordsA = new Set(normA.split(" "));
  const wordsB = new Set(normB.split(" "));
  
  let intersectionCount = 0;
  for (const w of wordsA) {
    if (wordsB.has(w)) intersectionCount++;
  }
  const unionCount = new Set([...wordsA, ...wordsB]).size;
  const wordJaccard = unionCount > 0 ? intersectionCount / unionCount : 0;

  // 2. 字符 2-Gram 连续重合度 (针对中文与短字符串优化)
  const getBigrams = (str: string) => {
    const bigrams = new Set<string>();
    for (let i = 0; i < str.length - 1; i++) {
      bigrams.add(str.slice(i, i + 2));
    }
    return bigrams;
  };

  const biA = getBigrams(normA);
  const biB = getBigrams(normB);
  let biIntersect = 0;
  for (const b of biA) {
    if (biB.has(b)) biIntersect++;
  }
  const biUnion = new Set([...biA, ...biB]).size;
  const charJaccard = biUnion > 0 ? biIntersect / biUnion : 0;

  // 加权混合分值
  return 0.4 * wordJaccard + 0.6 * charJaccard;
}

/**
 * 查询语义缓存 (Semantic Cache Lookup)
 */
export function lookupSemanticCache(
  userPrompt: string,
  model: string,
  similarityThreshold = 0.82
): { hit: boolean; entry?: SemanticCacheEntry; similarityScore?: number } {
  totalQueries++;
  const normPrompt = normalizeText(userPrompt);

  let bestMatch: SemanticCacheEntry | null = null;
  let highestScore = 0;

  for (const entry of cacheEntries) {
    if (entry.model !== model) continue;

    const score = calculateSemanticSimilarity(normPrompt, entry.promptNormalized);
    if (score > highestScore) {
      highestScore = score;
      bestMatch = entry;
    }
  }

  if (bestMatch && highestScore >= similarityThreshold) {
    cacheHits++;
    bestMatch.hitCount++;
    bestMatch.lastAccessedAt = new Date().toISOString();
    totalTokensSaved += bestMatch.tokensSaved;

    return {
      hit: true,
      entry: bestMatch,
      similarityScore: Math.round(highestScore * 100) / 100
    };
  }

  cacheMisses++;
  return { hit: false };
}

/**
 * 存入语义缓存 (Save to Semantic Cache)
 */
export function saveToSemanticCache(
  prompt: string,
  model: string,
  response: {
    reasoning: string;
    output: string;
    agenticAction?: any;
    referencedFiles?: string[];
  }
): SemanticCacheEntry {
  const normPrompt = normalizeText(prompt);
  const estimatedTokens = Math.ceil((prompt.length + response.output.length + response.reasoning.length) / 3.5);

  const entry: SemanticCacheEntry = {
    id: "cache-" + crypto.randomUUID().slice(0, 8),
    prompt,
    promptNormalized: normPrompt,
    model,
    response,
    tokensSaved: estimatedTokens,
    hitCount: 0,
    createdAt: new Date().toISOString(),
    lastAccessedAt: new Date().toISOString()
  };

  // 最大支持 200 条最热缓存，自动 FIFO 剔除
  if (cacheEntries.length >= 200) {
    cacheEntries.shift();
  }

  cacheEntries.push(entry);
  return entry;
}

/**
 * 智能 Context Token 裁剪器 (Smart Token Trimming)
 */
export function trimContextForTokens(
  vfsFiles: { path: string; content: string }[],
  userPrompt: string,
  maxTokenBudget = 2500
): { trimmedFiles: { path: string; content: string }[]; totalTokens: number; wasTrimmed: boolean } {
  let estimatedTotal = 0;
  const processed: { path: string; content: string }[] = [];
  let wasTrimmed = false;

  // 1. 寻找显式 `@` 关联的文件
  const promptLower = userPrompt.toLowerCase();

  // 按相关性排序
  const sorted = [...vfsFiles].sort((a, b) => {
    const aRef = promptLower.includes(a.path.toLowerCase());
    const bRef = promptLower.includes(b.path.toLowerCase());
    if (aRef && !bRef) return -1;
    if (!aRef && bRef) return 1;
    return b.content.length - a.content.length;
  });

  for (const file of sorted) {
    const tokens = Math.ceil(file.content.length / 3.5);

    if (estimatedTotal + tokens <= maxTokenBudget) {
      estimatedTotal += tokens;
      processed.push(file);
    } else {
      // 超过 Budget，进行段落切片或裁剪
      const remainingBudget = maxTokenBudget - estimatedTotal;
      if (remainingBudget > 150) {
        const allowedChars = Math.floor(remainingBudget * 3.5);
        const trimmedContent = file.content.slice(0, allowedChars) + "\n\n... [✂️ 已由智能 Token 裁剪器压缩超长段落]";
        processed.push({ path: file.path, content: trimmedContent });
        estimatedTotal += Math.ceil(trimmedContent.length / 3.5);
        wasTrimmed = true;
      } else {
        wasTrimmed = true;
      }
    }
  }

  return { trimmedFiles: processed, totalTokens: estimatedTotal, wasTrimmed };
}

/**
 * 获取缓存统计指标
 */
export function getCacheStats(): CacheStats {
  const hitRate = totalQueries > 0 ? ((cacheHits / totalQueries) * 100).toFixed(1) + "%" : "0.0%";
  return {
    totalQueries,
    cacheHits,
    cacheMisses,
    hitRate,
    totalTokensSaved,
    entryCount: cacheEntries.length
  };
}

/**
 * 清空或获取全量 Cache 列表
 */
export function getAllCacheEntries(): SemanticCacheEntry[] {
  return cacheEntries;
}

export function clearSemanticCache(): void {
  cacheEntries = [];
  cacheHits = 0;
  cacheMisses = 0;
  totalQueries = 0;
  totalTokensSaved = 0;
}
