import { Router } from "express";
import { runAgentBenchmarkSuite, getLastEvalResult, getEvalHistory } from "../agent/evalHarnessEngine.ts";

const router = Router();

// GET /api/eval/last - Retrieve latest evaluation report
router.get("/last", (req, res) => {
  const result = getLastEvalResult();
  if (!result) {
    return res.json({ status: "not_evaluated", message: "尚未运行 Agent 评估基准，请发起测试。" });
  }
  res.json({ status: "success", result });
});

// GET /api/eval/history - Retrieve historical run reports
router.get("/history", (req, res) => {
  res.json({ status: "success", history: getEvalHistory() });
});

// POST /api/eval/run - Trigger automated evaluation benchmark suite
router.post("/run", async (req, res) => {
  try {
    const report = await runAgentBenchmarkSuite();
    res.json({ status: "success", report });
  } catch (err: any) {
    res.status(500).json({ status: "error", error: err.message });
  }
});

export default router;
