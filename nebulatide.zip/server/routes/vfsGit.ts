import { Router } from "express";
import {
  initVFSGitTable,
  getCommitHistory,
  getCommitByHash,
  createCommit,
  computeLineDiff,
  rollbackToCommit
} from "../agent/vfsGitEngine.js";

const router = Router();

// GET /api/vfs/git/history?path=@文章/xxx.md
router.get("/history", (req, res) => {
  try {
    const filePath = req.query.path as string;
    const history = getCommitHistory(filePath);
    res.json({ count: history.length, filePath: filePath || "ALL", history });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

// GET /api/vfs/git/commit/:hash
router.get("/commit/:hash", (req, res) => {
  try {
    const hash = req.params.hash;
    const commit = getCommitByHash(hash);
    if (!commit) {
      return res.status(404).json({ error: `Commit [${hash}] not found` });
    }
    res.json(commit);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

// POST /api/vfs/git/diff - Compute Line-by-Line diff between two commits or custom texts
router.post("/diff", (req, res) => {
  try {
    const { oldHash, newHash, oldText, newText } = req.body;

    let textA = oldText || "";
    let textB = newText || "";

    if (oldHash) {
      const commitA = getCommitByHash(oldHash);
      if (commitA) textA = commitA.content;
    }

    if (newHash) {
      const commitB = getCommitByHash(newHash);
      if (commitB) textB = commitB.content;
    }

    const diffLines = computeLineDiff(textA, textB);
    res.json({
      lineCount: diffLines.length,
      additions: diffLines.filter(l => l.type === "added").length,
      deletions: diffLines.filter(l => l.type === "removed").length,
      diffLines
    });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

// POST /api/vfs/git/commit - Create a manual snapshot commit
router.post("/commit", (req, res) => {
  try {
    const { filePath, author, message, content, metadata } = req.body;
    if (!filePath || !content) {
      return res.status(400).json({ error: "Missing required fields: filePath and content" });
    }

    const newCommit = createCommit(
      filePath,
      author || "Niu (星云航行者)",
      message || "feat: 自动化手动系统快照",
      content,
      metadata || {}
    );

    res.json({ success: true, commit: newCommit });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

// POST /api/vfs/git/rollback - Rollback VFS node to specific commit
router.post("/rollback", (req, res) => {
  try {
    const { hash } = req.body;
    if (!hash) {
      return res.status(400).json({ error: "Missing commit hash" });
    }

    const result = rollbackToCommit(hash);
    if (!result.success) {
      return res.status(400).json(result);
    }

    res.json(result);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

export default router;
