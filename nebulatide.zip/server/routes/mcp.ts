import { Router } from "express";
import { handleMCPRPC, MCP_TOOLS, MCP_RESOURCES, MCP_PROMPTS } from "../mcp/mcpBridgeEngine.js";

const router = Router();

// Standard MCP JSON-RPC 2.0 Endpoint
router.post("/", async (req, res) => {
  try {
    const response = await handleMCPRPC(req.body);
    res.json(response);
  } catch (err: any) {
    res.status(500).json({
      jsonrpc: "2.0",
      id: req.body?.id || null,
      error: { code: -32603, message: err.message }
    });
  }
});

// GET /api/mcp/schema - Convenience Inspector Endpoint for UI
router.get("/schema", (req, res) => {
  res.json({
    protocol: "Anthropic MCP (Model Context Protocol) v2024-11-05",
    serverInfo: { name: "NebulaTide-MCP-Server", version: "1.0.0" },
    tools: MCP_TOOLS,
    resources: MCP_RESOURCES,
    prompts: MCP_PROMPTS
  });
});

export default router;
