import { Router } from "express";
import { getDb, saveDatabase } from "../db/index.js";

const router = Router();

// GET /api/mind-models
router.get("/", (req, res) => {
  try {
    const db = getDb();
    const stmt = db.prepare("SELECT * FROM mind_models");
    const list: any[] = [];
    while (stmt.step()) {
      list.push(stmt.getAsObject());
    }
    stmt.free();
    res.json(list);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/mind-models
router.post("/", (req, res) => {
  try {
    const db = getDb();
    const m = req.body;
    db.run(
      `INSERT OR REPLACE INTO mind_models (id, title, formula, description, icon)
       VALUES (?, ?, ?, ?, ?)`,
      [m.id, m.title, m.formula, m.description, m.icon]
    );
    saveDatabase();
    res.json({ success: true, model: m });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/mind-models/:id
router.delete("/:id", (req, res) => {
  try {
    const db = getDb();
    db.run("DELETE FROM mind_models WHERE id = ?", [req.params.id]);
    saveDatabase();
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
