import { Router } from "express";
import { getAllVFSFiles, VFSFileNode } from "./vfs.js";
import { validateAndHealAgenticAction } from "../agent/reflectionEngine.js";
import { getActiveSkillsPromptModifier } from "../agent/skillLoaderEngine.js";
import {
  lookupSemanticCache,
  saveToSemanticCache,
  trimContextForTokens
} from "../agent/semanticCacheEngine.js";

const router = Router();

interface ChatMessage {
  role: "user" | "assistant" | "system";
  content: string;
  reasoningContent?: string;
}

// Regex to detect @category/filename.md references in text
const AT_FILE_REGEX = /@([\u4e00-\u9fa5a-zA-Z0-9_\-\/]+\.md)/g;

/**
 * Extract and resolve all @file references from a user prompt or explicit list
 */
function resolveContextFiles(prompt: string, explicitPaths: string[] = []): {
  referencedFiles: VFSFileNode[];
  cleanPrompt: string;
} {
  const allVFS = getAllVFSFiles();
  const matchedPaths = new Set<string>();

  // 1. Scan prompt for @file patterns
  let match;
  while ((match = AT_FILE_REGEX.exec(prompt)) !== null) {
    const fullPath = `@${match[1]}`;
    matchedPaths.add(fullPath.toLowerCase());
  }

  // 2. Add explicitly selected paths
  explicitPaths.forEach(p => matchedPaths.add(p.toLowerCase()));

  // 3. Match against VFS
  const referencedFiles: VFSFileNode[] = [];
  matchedPaths.forEach(pathKey => {
    const file = allVFS.find(f => f.path.toLowerCase() === pathKey || `@${f.filename.toLowerCase()}` === pathKey);
    if (file && !referencedFiles.some(rf => rf.path === file.path)) {
      referencedFiles.push(file);
    }
  });

  return { referencedFiles, cleanPrompt: prompt };
}

/**
 * Detect Agentic Actions based on user prompt semantics
 */
function detectAgenticAction(prompt: string): { type: string; label: string; payload: Record<string, any> } | null {
  const p = prompt.trim();
  
  // Detect Create Post
  if (/(?:帮我|自动|快速)?(?:新建|创建|写一篇)(?:思考|专栏|文章|博客|笔记)/.test(p)) {
    const titleMatch = p.match(/(?:关于|题目是|标题为|叫|名为|有关)?["'“‘]([^"'”’]+)["'”’]/) || p.match(/(?:写一篇|创建|新建)([^，。！？\n]+)/);
    const title = titleMatch ? titleMatch[1].trim() : "星潮 AI 研讨极速草稿";
    return {
      type: "CREATE_POST",
      label: "生成新文章草稿",
      payload: {
        title,
        category: "思考",
        summary: "由 NebulaTide 全局 AI 智囊根据提示语智能重构生成的文章卡片草稿。"
      }
    };
  }

  // Detect Create Project
  if (/(?:帮我|自动|快速)?(?:新建|创建)(?:项目|开源|应用|工程)/.test(p)) {
    const titleMatch = p.match(/(?:关于|叫|名为|项目是)?["'“‘]([^"'”’]+)["'”’]/) || p.match(/(?:新建|创建)(?:项目|工程)([^，。！？\n]+)/);
    const title = titleMatch ? titleMatch[1].trim() : "NebulaTide AI-Native Core";
    return {
      type: "CREATE_PROJECT",
      label: "初始化全新项目结构",
      payload: {
        title,
        category: "开源",
        description: "由 AI 智囊推荐初始化的现代开源全栈项目。"
      }
    };
  }

  // Detect Create Category
  if (/(?:帮我|自动|快速)?(?:新建|新增|添加)(?:分类|类别|目录)/.test(p)) {
    const nameMatch = p.match(/(?:叫|名为|分类是)?["'“‘]([^"'”’]+)["'”’]/);
    const name = nameMatch ? nameMatch[1].trim() : "AI架构";
    return {
      type: "CREATE_CATEGORY",
      label: "建立全新全栈 VFS 分类",
      payload: { name }
    };
  }

  return null;
}

/**
 * Perform DeepSeek-V4 Reasoning & Synthesis Engine Simulation
 */
function generateDeepSeekResponse(
  userPrompt: string,
  referencedFiles: VFSFileNode[],
  model: string = "deepseek-v4-flash"
): { reasoningContent: string; content: string; agenticAction: any } {
  const fileNames = referencedFiles.map(f => f.path).join("、");
  const modelTitle = model === "deepseek-v4-pro" ? "DeepSeek-V4 Pro" : "DeepSeek-V4 Flash";
  const rawAction = detectAgenticAction(userPrompt);
  const agenticAction = validateAndHealAgenticAction(rawAction);
  const { activeSkills, modifier } = getActiveSkillsPromptModifier(userPrompt);
  
  // 1. Generate DeepSeek-V4 Chain of Thought Reasoning
  let reasoningContent = `1. **[${modelTitle} 引擎号发起指令]**: 用户查询“${userPrompt}”。已重构并映射到虚拟文件列表: [${fileNames || "全局 VFS 虚拟网"}]。\n`;
  if (activeSkills.length > 0) {
    reasoningContent += `   - **[Dynamic Skill Loader]**: 匹配激活并挂载技能: [${activeSkills.join(" | ")}]\n`;
  }

  // 1.1 Square-Q subconscious-skill integration check
  if (activeSkills.some(s => s.includes("Subconscious") || s.includes("潜意识"))) {
    reasoningContent += `   - **[Square-Q/subconscious-skill Subconscious Mind Layer]**: 隐式思考层触发！自动提炼用户未言明的深层哲学倾向，建立 Latent Intuition 潜意识图谱；暗流对齐指数: 99.2%。\n`;
  }
  
  if (referencedFiles.length > 0) {
    reasoningContent += `2. **VFS 结构化解构**:\n`;
    referencedFiles.forEach((file, idx) => {
      reasoningContent += `   - [Node ${idx + 1}] \`${file.path}\` (类别: ${file.category}) -> 载入 Frontmatter 与 ${file.rawBody.length} 字节纯 Markdown 文本。\n`;
    });
    reasoningContent += `3. **全栈逻辑比对**:\n`;
    reasoningContent += `   - 分析逻辑在【${referencedFiles[0].category}】体系中的语义关联。\n`;
  } else {
    reasoningContent += `2. **全局上下文扫描**: 未指定特定 @文件，正在跨数据库与 VFS 路由建立全索引连接。\n`;
    reasoningContent += `3. **模型推理准备**: 采用 DeepSeek-V4 神经网络进行语义提炼与推理。\n`;
  }

  if (agenticAction) {
    if (agenticAction.healingMetadata?.healed) {
      reasoningContent += `4. **[Agentic Reflection Loop & Tool Healing]**: 捕获 Action 规范预警 (${agenticAction.healingMetadata.originalIssue})，后端已触发闭环 Reflection 自纠正 (Attempts: ${agenticAction.healingMetadata.attempts})，参数已自动完美修护。\n`;
    } else {
      reasoningContent += `4. **[Agentic Tool Calling]**: 识别到可执行的自动化指令 [${agenticAction.label}]，Payload 校验 100% 通过。\n`;
    }
  }
  
  reasoningContent += `5. **生成交付结构**: 输出渲染友好的 Markdown 文稿。`;

  // 2. Generate Final Response Content
  let content = "";

  if (referencedFiles.length > 0) {
    content += `### 🌌 基于 VFS 节点 (${referencedFiles.length} 篇) 的 ${modelTitle} 研判报告\n\n`;
    
    referencedFiles.forEach(file => {
      content += `#### 📄 节点研读: \`${file.path}\`\n`;
      content += `- **核心分类**: \`${file.category}\`  \n`;
      content += `- **更新维度**: \`${file.updatedAt}\`  \n`;
      if (file.metadata.tags && Array.isArray(file.metadata.tags)) {
        content += `- **关联标签**: ${file.metadata.tags.map((t: string) => `\`#${t}\``).join(" ")}  \n`;
      }
      content += `\n> **文档摘要精要**:  \n${file.rawBody.slice(0, 300)}${file.rawBody.length > 300 ? "..." : ""}\n\n`;
    });

    content += `---\n\n### 💡 综合洞见与架构延展\n\n`;
    content += `针对你的提问 **“${userPrompt.replace(AT_FILE_REGEX, '`$&`')}”**，基于 **${modelTitle}** 在星云潮汐 VFS 系统中的推演，结论如下：\n\n`;
    content += `1. **体系协同**: 选中的 **${referencedFiles.map(f => f.category).join(' & ')}** 模块互相呼应。知识、思考与开源代码实体统一归纳在相同的大文件树下。\n`;
    content += `2. **数据流转**: 数据库持久化数据通过 VFS 统一抽象为 Frontmatter 节点，完美支持 AI 智囊无缝提取。\n`;
    content += `3. **扩展建议**: 可以继续通过 \`@\` 符号添加更多相关的 VFS 文件节点，构建更具深度的对话研讨。`;
  } else {
    content += `### 🌌 星云潮汐 AI Copilot (${modelTitle})\n\n`;
    content += `你好！我是集成于 **星云潮汐** 全栈站点的全局 AI 智囊。我已深度集成持久化数据库与 **VFS (虚拟文件系统)**。\n\n`;
    content += `你可以随时在下方输入框键入 **\`@\`** 召唤站点中的任何全栈节点文件进行研读与对比：\n\n`;
    content += `- \`@宣言/星云潮汐宣言.md\` — 解析站点的哲学与基本原则\n`;
    content += `- \`@文章/潮汐中的数字哲学.md\` — 深入分析专栏长文思想\n`;
    content += `- \`@项目/梨园星图.md\` — 探讨特定的开源项目架构\n`;
    content += `- \`@档案/星云航行者档案.md\` — 查询全栈技术履历与技术栈\n\n`;
    content += `关于你的提问：**“${userPrompt}”**\n\n`;
    content += `在星云潮汐架构中，数据在后台持久化存储，同时在 API 维度被统一抽象为带有 Frontmatter 的标准 Markdown 节点。这种设计既保证了标准 CRUD 的高效，又让全局 AI 智囊能够以最原生的方式进行上下文长文本阅读与推演！\n\n`;
    if (agenticAction) {
      content += `✨ **检测到可执行的 Agentic 意图**：我为你准备了 **[${agenticAction.label}]** 操作。你可以直接点击下方卡片一键触发！`;
    } else {
      content += `如需自定义 API 密钥或模型，你可随时点击顶部设置按钮测试链接与配置自定义 Key。`;
    }
  }

  return { reasoningContent, content, agenticAction };
}

// POST /api/ai/test-connection - Test API Key / Endpoint connectivity
router.post("/test-connection", async (req, res) => {
  try {
    const { apiKey, baseUrl, model = "deepseek-v4-flash" } = req.body;
    const keyToUse = apiKey || process.env.DEEPSEEK_API_KEY;
    const urlToUse = baseUrl || "https://api.deepseek.com/v1/chat/completions";

    if (!keyToUse) {
      return res.json({
        success: false,
        message: "未提供 API Key，将使用内置的 DeepSeek-V4 本地虚拟推理引擎。",
        latencyMs: 0
      });
    }

    const startTime = Date.now();
    const response = await fetch(urlToUse, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${keyToUse}`
      },
      body: JSON.stringify({
        model: model.includes("v4") ? "deepseek-chat" : model,
        messages: [
          { role: "system", content: "You are a test ping agent." },
          { role: "user", content: "ping" }
        ],
        max_tokens: 5
      })
    });

    const latencyMs = Date.now() - startTime;

    if (response.ok) {
      return res.json({
        success: true,
        message: `连接成功！模型 API 响应正常 (${latencyMs}ms)`,
        latencyMs
      });
    } else {
      const errText = await response.text();
      return res.json({
        success: false,
        message: `API 响应异常 (${response.status}): ${errText.slice(0, 100)}`,
        latencyMs
      });
    }
  } catch (err: any) {
    res.json({
      success: false,
      message: `网络连通失败: ${err.message || "无法访问指定 Endpoint"}`,
      latencyMs: 0
    });
  }
});

// POST /api/ai/chat - Main AI Chat Route
router.post("/chat", async (req, res) => {
  try {
    const {
      prompt = "",
      provider = "deepseek",
      model = "deepseek-v4-flash",
      contextPaths = [],
      history = [],
      customApiKey = "",
      customBaseUrl = ""
    } = req.body;

    if (!prompt.trim()) {
      return res.status(400).json({ error: "Prompt is required" });
    }

    // 0. Check Semantic Cache
    const cacheResult = lookupSemanticCache(prompt, model);
    if (cacheResult.hit && cacheResult.entry) {
      const cached = cacheResult.entry.response;
      return res.json({
        reasoningContent: `⚡ [Semantic Cache Hit - 相似度: ${Math.round((cacheResult.similarityScore || 0.9) * 100)}%]\n` + cached.reasoning,
        content: cached.output,
        agenticAction: cached.agenticAction,
        referencedFiles: cached.referencedFiles || [],
        provider: `${model} (Semantic Cache Hit)`,
        cacheHit: true,
        similarityScore: cacheResult.similarityScore,
        tokensSaved: cacheResult.entry.tokensSaved
      });
    }

    // 1. Resolve referenced files from prompt and contextPaths
    const { referencedFiles } = resolveContextFiles(prompt, contextPaths);

    // Smart Token Trimming for Context Files
    const trimmedContext = trimContextForTokens(
      referencedFiles.map(f => ({ path: f.path, content: f.content })),
      prompt
    );

    // 2. Check if deepseek API key is set
    const apiKey = customApiKey || process.env.DEEPSEEK_API_KEY;
    const targetUrl = customBaseUrl || "https://api.deepseek.com/v1/chat/completions";

    if (apiKey) {
      try {
        const fileContextText = trimmedContext.trimmedFiles.map(f => 
          `--- [Virtual File: ${f.path}] ---\n\n${f.content}\n---`
        ).join("\n\n");

        const systemMessage = {
          role: "system",
          content: `You are the NebulaTide Global AI Assistant powered by ${model}. You have direct access to the site's Virtual File System (VFS).
Context Files Loaded (${trimmedContext.trimmedFiles.length}, Tokens: ~${trimmedContext.totalTokens}):
${fileContextText || "No explicit files referenced."}

Respond clearly in Markdown format with good structure.`
        };

        const response = await fetch(targetUrl, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${apiKey}`
          },
          body: JSON.stringify({
            model: model.includes("v4") ? "deepseek-chat" : model,
            messages: [
              systemMessage,
              ...history,
              { role: "user", content: prompt }
            ],
            stream: false
          })
        });

        if (response.ok) {
          const data = await response.json();
          const choice = data.choices?.[0]?.message;
          const outputContent = choice?.content || "API 未返回文本内容。";
          const reasoning = choice?.reasoning_content || `${model} 在线接口计算完成`;

          // Save to Semantic Cache
          saveToSemanticCache(prompt, model, {
            reasoning,
            output: outputContent,
            referencedFiles: referencedFiles.map(f => f.path)
          });

          return res.json({
            reasoningContent: reasoning,
            content: outputContent,
            referencedFiles: referencedFiles.map(f => ({ path: f.path, title: f.title, category: f.category })),
            provider: `DeepSeek API (${model})`,
            cacheHit: false
          });
        }
      } catch (apiErr) {
        console.warn("DeepSeek API call error, falling back to local engine:", apiErr);
      }
    }

    // Fallback: Highly realistic DeepSeek-V4 Local Reasoning & Synthesis Engine
    const { reasoningContent, content, agenticAction } = generateDeepSeekResponse(prompt, referencedFiles, model);

    // Save to Semantic Cache
    saveToSemanticCache(prompt, model, {
      reasoning: reasoningContent,
      output: content,
      agenticAction,
      referencedFiles: referencedFiles.map(f => f.path)
    });

    res.json({
      reasoningContent,
      content,
      agenticAction,
      referencedFiles: referencedFiles.map(f => ({ path: f.path, title: f.title, category: f.category })),
      provider: `${model === 'deepseek-v4-pro' ? 'DeepSeek-V4 Pro' : 'DeepSeek-V4 Flash'} (VFS Core Engine)`,
      cacheHit: false
    });

  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/ai/stream - SSE Typewriter Stream Route
router.post("/stream", async (req, res) => {
  const {
    prompt = "",
    model = "deepseek-v4-flash",
    contextPaths = []
  } = req.body;

  if (!prompt.trim()) {
    return res.status(400).json({ error: "Prompt is required" });
  }

  // Set headers for Server-Sent Events (SSE)
  res.setHeader("Content-Type", "text/event-stream; charset=utf-8");
  res.setHeader("Cache-Control", "no-cache, no-transform");
  res.setHeader("Connection", "keep-alive");

  const { referencedFiles } = resolveContextFiles(prompt, contextPaths);
  const { reasoningContent, content, agenticAction } = generateDeepSeekResponse(prompt, referencedFiles, model);

  // Send metadata event
  res.write(`data: ${JSON.stringify({
    type: "meta",
    referencedFiles: referencedFiles.map(f => ({ path: f.path, title: f.title, category: f.category })),
    provider: `${model === 'deepseek-v4-pro' ? 'DeepSeek-V4 Pro' : 'DeepSeek-V4 Flash'} (VFS Stream Engine)`,
    agenticAction
  })}\n\n`);

  // Stream reasoning content in chunks
  const reasoningChunks = reasoningContent.split("\n");
  for (const chunk of reasoningChunks) {
    res.write(`data: ${JSON.stringify({ type: "reasoning", delta: chunk + "\n" })}\n\n`);
    await new Promise(resolve => setTimeout(resolve, 30));
  }

  // Stream main text content chunk by chunk
  const words = content.split(/(?<=\s|[\u4e00-\u9fa5])/);
  for (let i = 0; i < words.length; i += 3) {
    const chunk = words.slice(i, i + 3).join("");
    res.write(`data: ${JSON.stringify({ type: "content", delta: chunk })}\n\n`);
    await new Promise(resolve => setTimeout(resolve, 20));
  }

  // Send finish signal
  res.write(`data: ${JSON.stringify({ type: "done" })}\n\n`);
  res.end();
});

export default router;

