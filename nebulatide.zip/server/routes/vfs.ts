import { Router } from "express";
import { getDb } from "../db/index.js";

const router = Router();

export interface VFSFileNode {
  path: string;            // e.g. "@文章/潮汐中的数字哲学.md"
  category: string;        // e.g. "文章" | "火花" | "项目" | "沙盒" | "宣言" | "档案"
  title: string;           // Display title
  filename: string;        // e.g. "潮汐中的数字哲学.md"
  metadata: Record<string, any>; // Frontmatter metadata
  content: string;         // Markdown raw content (with frontmatter)
  rawBody: string;         // Pure Markdown body without frontmatter
  updatedAt: string;
}

// Static documents for 宣言 (Manifesto) and 档案 (About Archive)
const MANIFESTO_DOC: VFSFileNode = {
  path: "@宣言/星云潮汐宣言.md",
  category: "宣言",
  title: "星云潮汐·数字存在主义宣言",
  filename: "星云潮汐宣言.md",
  metadata: {
    version: "1.0.0",
    author: "Niu (星云航行者)",
    updatedAt: "2026-07-27",
    tags: ["数字存在主义", "开源哲学", "赛博静修"]
  },
  content: `---
title: 星云潮汐·数字存在主义宣言
author: Niu (星云航行者)
updatedAt: 2026-07-27
tags: [数字存在主义, 开源哲学, 赛博静修]
---

# 星云潮汐 · 数字存在主义宣言

在信息爆炸与喧嚣碎片构筑的数字纪元中，我们拒绝做无意识的数据流转节点。

## 核心理念 (Core Tenets)
1. **赛博静修 (Cyber Solitude)**: 在高频链接的时代，保持独立的精神锚点与深度思考场域。
2. **星云凝结 (Nebula Condensation)**: 零散的微小灵感（火花）终将凝结为深邃的体系（潮汐长文与代码沙盒）。
3. **开源共享 (Open-Source Soul)**: 代码是现代哲学的实体呈现，知识与工具应当如同潮汐般自由流动。

> "代码是现代哲学的实体呈现。" — 星云航行者
`,
  rawBody: `# 星云潮汐 · 数字存在主义宣言\n\n在信息爆炸与喧嚣碎片构筑的数字纪元中，我们拒绝做无意识的数据流转节点。\n\n## 核心理念 (Core Tenets)\n1. **赛博静修 (Cyber Solitude)**: 在高频链接的时代，保持独立的精神锚点与深度思考场域。\n2. **星云凝结 (Nebula Condensation)**: 零散的微小灵感（火花）终将凝结为深邃的体系（潮汐长文与代码沙盒）。\n3. **开源共享 (Open-Source Soul)**: 代码是现代哲学的实体呈现，知识与工具应当如同潮汐般自由流动。\n\n> "代码是现代哲学的实体呈现。" — 星云航行者`,
  updatedAt: "2026-07-27"
};

const ABOUT_DOC: VFSFileNode = {
  path: "@档案/星云航行者档案.md",
  category: "档案",
  title: "星云航行者·个人全景档案",
  filename: "星云航行者档案.md",
  metadata: {
    author: "Niu",
    role: "Full-Stack Architect & Digital Philosopher",
    location: "Cyber Space / Hangzhou",
    updatedAt: "2026-07-27",
    skills: ["TypeScript", "React", "Node.js", "Python", "Rust", "SQLite", "AI / LLM Integration"]
  },
  content: `---
title: 星云航行者·个人全景档案
role: Full-Stack Architect & Digital Philosopher
location: Cyber Space / Hangzhou
skills: [TypeScript, React, Node.js, Python, Rust, SQLite, AI Integration]
---

# 星云航行者 (Niu)

一位在代码架构与哲学静修之间游走的数字建造者。

## 探索领域
- **全栈系统架构**: 高性能 TypeScript / React / Node.js 全栈服务端与响应式前端。
- **AI 智能体与工具网**: 基于大语言模型的智能分析、RAG、VFS 虚拟文件系统与代码辅助。
- **赛博美学**: 结合深空星云、高对比度暗色/亮色视觉与流畅交互的界面设计。

## 联系方式
- GitHub: https://github.com/
- 个人空间: 星云潮汐全栈站
`,
  rawBody: `# 星云航行者 (Niu)\n\n一位在代码架构与哲学静修之间游走的数字建造者。\n\n## 探索领域\n- **全栈系统架构**: 高性能 TypeScript / React / Node.js 全栈服务端与响应式前端。\n- **AI 智能体与工具网**: 基于大语言模型的智能分析、RAG、VFS 虚拟文件系统与代码辅助。\n- **赛博美学**: 结合深空星云、高对比度暗色/亮色视觉与流畅交互的界面设计。\n\n## 联系方式\n- GitHub: https://github.com/\n- 个人空间: 星云潮汐全栈站`,
  updatedAt: "2026-07-27"
};

/**
  Helper to load all virtual files from SQLite database
 */
export function getAllVFSFiles(): VFSFileNode[] {
  const db = getDb();
  const files: VFSFileNode[] = [MANIFESTO_DOC, ABOUT_DOC];

  // 1. 【文章】 Posts
  try {
    const stmt = db.prepare("SELECT * FROM posts");
    while (stmt.step()) {
      const row = stmt.getAsObject();
      const tags = row.tags ? JSON.parse(row.tags as string) : [];
      const title = (row.title as string) || "未命名文章";
      const filename = `${title.replace(/[/\\?%*:|"<>]/g, "_")}.md`;
      const path = `@文章/${filename}`;
      const metadata = {
        id: row.id,
        title: row.title,
        subtitle: row.subtitle,
        category: row.category,
        tags,
        date: row.date,
        readTime: row.readTime,
        likes: row.likes
      };
      const rawBody = row.content ? (row.content as string) : (row.excerpt as string) || "";
      const frontmatter = `---
title: ${row.title}
subtitle: ${row.subtitle || ""}
category: ${row.category || "潮汐长文"}
date: ${row.date || ""}
readTime: ${row.readTime || ""}
tags: [${tags.join(", ")}]
likes: ${row.likes || 0}
---

`;
      files.push({
        path,
        category: "文章",
        title,
        filename,
        metadata,
        content: frontmatter + rawBody,
        rawBody,
        updatedAt: (row.date as string) || new Date().toISOString().split("T")[0]
      });
    }
    stmt.free();
  } catch (e) {
    console.error("VFS Post error:", e);
  }

  // 2. 【项目】 Projects
  try {
    const stmt = db.prepare("SELECT * FROM projects");
    while (stmt.step()) {
      const row = stmt.getAsObject();
      const tags = row.tags ? JSON.parse(row.tags as string) : [];
      const highlights = row.highlights ? JSON.parse(row.highlights as string) : [];
      const title = (row.title as string) || "未命名项目";
      const filename = `${title.replace(/[/\\?%*:|"<>]/g, "_")}.md`;
      const path = `@项目/${filename}`;
      const metadata = {
        id: row.id,
        title: row.title,
        subtitle: row.subtitle,
        category: row.category,
        period: row.period,
        tags,
        repoUrl: row.repoUrl,
        philosophicalLink: row.philosophicalLink
      };
      const rawBody = `# ${row.title}\n> ${row.subtitle || ""}\n\n**分类**: ${row.category} | **周期**: ${row.period}\n\n## 项目简介\n${row.description || ""}\n\n## 核心亮点\n${highlights.map((h: string) => `- ${h}`).join("\n")}\n\n**开源地址**: ${row.repoUrl || "保密 / 内部仓库"}`;
      const frontmatter = `---
title: ${row.title}
subtitle: ${row.subtitle || ""}
category: ${row.category || "项目"}
period: ${row.period || ""}
repoUrl: ${row.repoUrl || ""}
tags: [${tags.join(", ")}]
---

`;
      files.push({
        path,
        category: "项目",
        title,
        filename,
        metadata,
        content: frontmatter + rawBody,
        rawBody,
        updatedAt: "2026-07-27"
      });
    }
    stmt.free();
  } catch (e) {
    console.error("VFS Project error:", e);
  }

  // 3. 【火花】 Fragments
  try {
    const stmt = db.prepare("SELECT * FROM fragments ORDER BY createdAt DESC");
    while (stmt.step()) {
      const row = stmt.getAsObject();
      const dateStr = (row.createdAt as string) || new Date().toISOString().split("T")[0];
      const mood = (row.moodTag as string) || "随感";
      const idStr = row.id as string;
      const filename = `${dateStr}_${mood}_${idStr.slice(-4)}.md`;
      const path = `@火花/${filename}`;
      const rawBody = (row.content as string) || "";
      const metadata = {
        id: row.id,
        moodTag: row.moodTag,
        createdAt: row.createdAt,
        likes: row.likes,
        isStarred: Boolean(row.isStarred)
      };
      const frontmatter = `---
id: ${row.id}
moodTag: ${row.moodTag || "随笔"}
createdAt: ${row.createdAt}
likes: ${row.likes || 0}
isStarred: ${Boolean(row.isStarred)}
---

`;
      files.push({
        path,
        category: "火花",
        title: `${mood} (${dateStr})`,
        filename,
        metadata,
        content: frontmatter + rawBody,
        rawBody,
        updatedAt: dateStr
      });
    }
    stmt.free();
  } catch (e) {
    console.error("VFS Fragment error:", e);
  }

  // 4. 【沙盒】 Rituals & Mind Models
  try {
    const stmtRituals = db.prepare("SELECT * FROM rituals");
    while (stmtRituals.step()) {
      const row = stmtRituals.getAsObject();
      const title = (row.title as string) || "潮汐复盘";
      const filename = `潮汐复盘_${title.replace(/[/\\?%*:|"<>]/g, "_")}.md`;
      const path = `@沙盒/${filename}`;
      const wins = row.highTideWins ? JSON.parse(row.highTideWins as string) : [];
      const learnings = row.lowTideLearnings ? JSON.parse(row.lowTideLearnings as string) : [];
      const rawBody = `# ${row.title}\n**周期**: ${row.dateRange}\n\n## 🌊 涨潮高光 (High Tide Wins)\n${wins.map((w: string) => `- ${w}`).join("\n")}\n\n## 🥀 退潮反思 (Low Tide Learnings)\n${learnings.map((l: string) => `- ${l}`).join("\n")}\n\n## 🔮 珍珠洞见 (Insight Pearl)\n> ${row.insightPearl || ""}`;
      files.push({
        path,
        category: "沙盒",
        title: `潮汐复盘: ${title}`,
        filename,
        metadata: { id: row.id, dateRange: row.dateRange },
        content: rawBody,
        rawBody,
        updatedAt: (row.createdAt as string) || "2026-07-27"
      });
    }
    stmtRituals.free();

    const stmtModels = db.prepare("SELECT * FROM mind_models");
    while (stmtModels.step()) {
      const row = stmtModels.getAsObject();
      const title = (row.title as string) || "思维模型";
      const filename = `思维模型_${title.replace(/[/\\?%*:|"<>]/g, "_")}.md`;
      const path = `@沙盒/${filename}`;
      const rawBody = `# 思维模型: ${row.title}\n**公式/内核**: \`${row.formula}\` \n\n## 说明\n${row.description}`;
      files.push({
        path,
        category: "沙盒",
        title: `思维模型: ${title}`,
        filename,
        metadata: { id: row.id, formula: row.formula },
        content: rawBody,
        rawBody,
        updatedAt: "2026-07-27"
      });
    }
    stmtModels.free();
  } catch (e) {
    console.error("VFS Rituals/Models error:", e);
  }

  return files;
}

// GET /api/vfs/tree - Get tree of all categories and virtual files
router.get("/tree", (req, res) => {
  try {
    const files = getAllVFSFiles();
    // Group files by category
    const categories: Record<string, { count: number; files: { path: string; title: string; filename: string; updatedAt: string }[] }> = {
      "宣言": { count: 0, files: [] },
      "火花": { count: 0, files: [] },
      "文章": { count: 0, files: [] },
      "项目": { count: 0, files: [] },
      "沙盒": { count: 0, files: [] },
      "档案": { count: 0, files: [] }
    };

    files.forEach(f => {
      if (!categories[f.category]) {
        categories[f.category] = { count: 0, files: [] };
      }
      categories[f.category].files.push({
        path: f.path,
        title: f.title,
        filename: f.filename,
        updatedAt: f.updatedAt
      });
      categories[f.category].count++;
    });

    res.json({
      totalCount: files.length,
      categories
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/vfs/file?path=@文章/xxx.md - Get specific virtual file content
router.get("/file", (req, res) => {
  try {
    const targetPath = req.query.path as string;
    if (!targetPath) {
      return res.status(400).json({ error: "Missing path query parameter" });
    }

    const files = getAllVFSFiles();
    const found = files.find(f => f.path.trim().toLowerCase() === targetPath.trim().toLowerCase());

    if (!found) {
      return res.status(404).json({ error: `Virtual file '${targetPath}' not found` });
    }

    res.json(found);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/vfs/search?q=xxx - Search VFS contents
router.get("/search", (req, res) => {
  try {
    const query = ((req.query.q as string) || "").trim().toLowerCase();
    const files = getAllVFSFiles();

    if (!query) {
      return res.json(files.slice(0, 10));
    }

    const matches = files.filter(f =>
      f.title.toLowerCase().includes(query) ||
      f.path.toLowerCase().includes(query) ||
      f.rawBody.toLowerCase().includes(query) ||
      JSON.stringify(f.metadata).toLowerCase().includes(query)
    );

    res.json(matches);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
