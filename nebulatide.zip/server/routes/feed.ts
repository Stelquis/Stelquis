import { Router } from "express";
import { getDb } from "../db/index.js";
import { getAllVFSFiles } from "./vfs.js";

const router = Router();

/**
 * GET /api/feed.xml
 * Returns standard RSS 2.0 XML Feed for readers & AI summarizers
 */
router.get("/feed.xml", (req, res) => {
  const db = getDb();
  let posts: any[] = [];
  try {
    const stmt = db.prepare("SELECT * FROM posts ORDER BY id DESC LIMIT 20");
    while (stmt.step()) {
      posts.push(stmt.getAsObject());
    }
    stmt.free();
  } catch (e) {
    console.warn("Feed posts query error:", e);
  }

  const siteUrl = "https://nebula-tide.ai";
  const buildDate = new Date().toUTCString();

  const itemsXml = posts
    .map((post) => {
      const title = (post.title || "未命名文章").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
      const excerpt = (post.excerpt || post.summary || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
      const category = (post.category || "潮汐长文").replace(/&/g, "&amp;");
      const pubDate = new Date(post.date || Date.now()).toUTCString();

      return `
    <item>
      <title>${title}</title>
      <link>${siteUrl}/#post-${post.id}</link>
      <guid>${siteUrl}/post-${post.id}</guid>
      <pubDate>${pubDate}</pubDate>
      <category>${category}</category>
      <description>${excerpt}</description>
    </item>`;
    })
    .join("");

  const rssXml = `<?xml version="1.0" encoding="UTF-8" ?>
<rss version="2.0">
  <channel>
    <title>星云潮汐 · NebulaTide Digital Garden</title>
    <link>${siteUrl}</link>
    <description>星云潮汐——全栈 AI Agent 演化架构试炼场与赛博存在主义数字花园</description>
    <language>zh-CN</language>
    <lastBuildDate>${buildDate}</lastBuildDate>
    ${itemsXml}
  </channel>
</rss>`;

  res.header("Content-Type", "application/xml; charset=utf-8");
  res.send(rssXml);
});

/**
 * GET /api/export
 * Export full VFS file nodes and data portability JSON bundle
 */
router.get("/export", (req, res) => {
  try {
    const vfsNodes = getAllVFSFiles();
    const db = getDb();

    const postsStmt = db.prepare("SELECT * FROM posts");
    const posts: any[] = [];
    while (postsStmt.step()) posts.push(postsStmt.getAsObject());
    postsStmt.free();

    const fragsStmt = db.prepare("SELECT * FROM fragments");
    const fragments: any[] = [];
    while (fragsStmt.step()) fragments.push(fragsStmt.getAsObject());
    fragsStmt.free();

    const exportBundle = {
      app: "NebulaTide Fullstack Digital Garden",
      exportedAt: new Date().toISOString(),
      vfsNodeCount: vfsNodes.length,
      vfsNodes,
      database: {
        posts,
        fragments,
      },
    };

    res.header("Content-Type", "application/json");
    res.attachment(`NebulaTide_VFS_Export_${Date.now()}.json`);
    res.send(JSON.stringify(exportBundle, null, 2));
  } catch (err: any) {
    res.status(500).json({ status: "error", error: err.message });
  }
});

export default router;
