import { Router } from "express";
import { getDb, saveDatabase } from "../db/index.js";

const router = Router();

// GET /api/fragments
router.get("/", (req, res) => {
  try {
    const db = getDb();
    const stmt = db.prepare("SELECT * FROM fragments ORDER BY createdAt DESC");
    const list: any[] = [];
    while (stmt.step()) {
      const row = stmt.getAsObject();
      list.push({
        ...row,
        isStarred: Boolean(row.isStarred)
      });
    }
    stmt.free();
    res.json(list);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/fragments
router.post("/", (req, res) => {
  try {
    const db = getDb();
    const f = req.body;
    db.run(
      `INSERT OR REPLACE INTO fragments (id, content, createdAt, moodTag, likes, isStarred)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [f.id, f.content, f.createdAt, f.moodTag, f.likes || 0, f.isStarred ? 1 : 0]
    );
    saveDatabase();
    res.json({ success: true, fragment: f });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/fragments/:id
router.delete("/:id", (req, res) => {
  try {
    const db = getDb();
    db.run("DELETE FROM fragments WHERE id = ?", [req.params.id]);
    saveDatabase();
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
