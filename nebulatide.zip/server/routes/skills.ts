import { Router } from "express";
import { getAllSkills, toggleSkillEnabled } from "../agent/skillLoaderEngine.js";

const router = Router();

// GET /api/skills
router.get("/", (req, res) => {
  res.json({ count: getAllSkills().length, skills: getAllSkills() });
});

// POST /api/skills/:id/toggle
router.post("/:id/toggle", (req, res) => {
  const updated = toggleSkillEnabled(req.params.id);
  if (!updated) {
    return res.status(404).json({ error: "Skill not found" });
  }
  res.json({ success: true, skill: updated });
});

export default router;
