import { Router } from "express";
import { getDb, saveDatabase } from "../db/index.js";

const router = Router();

// GET /api/posts
router.get("/", (req, res) => {
  try {
    const db = getDb();
    const stmt = db.prepare("SELECT * FROM posts");
    const list: any[] = [];
    while (stmt.step()) {
      const row = stmt.getAsObject();
      list.push({
        ...row,
        tags: row.tags ? JSON.parse(row.tags as string) : [],
        featured: Boolean(row.featured),
        author: row.author ? JSON.parse(row.author as string) : { name: "Niu", avatar: "", role: "Author" }
      });
    }
    stmt.free();
    res.json(list);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/posts
router.post("/", (req, res) => {
  try {
    const db = getDb();
    const p = req.body;
    db.run(
      `INSERT OR REPLACE INTO posts (id, title, subtitle, excerpt, content, category, tags, date, readTime, coverImage, featured, likes, author)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        p.id,
        p.title,
        p.subtitle,
        p.excerpt,
        p.content,
        p.category,
        JSON.stringify(p.tags || []),
        p.date,
        p.readTime,
        p.coverImage,
        p.featured ? 1 : 0,
        p.likes || 0,
        JSON.stringify(p.author)
      ]
    );
    saveDatabase();
    res.json({ success: true, post: p });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/posts/:id
router.delete("/:id", (req, res) => {
  try {
    const db = getDb();
    db.run("DELETE FROM posts WHERE id = ?", [req.params.id]);
    saveDatabase();
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
