import { Router } from "express";
import { getDb, saveDatabase } from "../db/index.js";

const router = Router();

// GET /api/rituals
router.get("/", (req, res) => {
  try {
    const db = getDb();
    const stmt = db.prepare("SELECT * FROM rituals");
    const list: any[] = [];
    while (stmt.step()) {
      const row = stmt.getAsObject();
      list.push({
        ...row,
        highTideWins: row.highTideWins ? JSON.parse(row.highTideWins as string) : [],
        lowTideLearnings: row.lowTideLearnings ? JSON.parse(row.lowTideLearnings as string) : []
      });
    }
    stmt.free();
    res.json(list);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/rituals
router.post("/", (req, res) => {
  try {
    const db = getDb();
    const r = req.body;
    db.run(
      `INSERT OR REPLACE INTO rituals (id, title, dateRange, highTideWins, lowTideLearnings, insightPearl, createdAt)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [
        r.id,
        r.title,
        r.dateRange,
        JSON.stringify(r.highTideWins || []),
        JSON.stringify(r.lowTideLearnings || []),
        r.insightPearl,
        r.createdAt
      ]
    );
    saveDatabase();
    res.json({ success: true, ritual: r });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/rituals/:id
router.delete("/:id", (req, res) => {
  try {
    const db = getDb();
    db.run("DELETE FROM rituals WHERE id = ?", [req.params.id]);
    saveDatabase();
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
