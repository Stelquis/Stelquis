import { Router } from "express";
import {
  getCacheStats,
  getAllCacheEntries,
  clearSemanticCache
} from "../agent/semanticCacheEngine.js";

const router = Router();

// GET /api/cache/stats - 获取语义缓存统计指标
router.get("/stats", (req, res) => {
  res.json(getCacheStats());
});

// GET /api/cache/entries - 获取缓存快照与相似度记录列表
router.get("/entries", (req, res) => {
  res.json({
    stats: getCacheStats(),
    entries: getAllCacheEntries()
  });
});

// POST /api/cache/clear - 清空语义缓存
router.post("/clear", (req, res) => {
  clearSemanticCache();
  res.json({ success: true, message: "语义缓存已清空", stats: getCacheStats() });
});

export default router;
