import { Router } from "express";
import { getDb, saveDatabase } from "../db/index.js";

const router = Router();

// GET /api/projects
router.get("/", (req, res) => {
  try {
    const db = getDb();
    const stmt = db.prepare("SELECT * FROM projects");
    const list: any[] = [];
    while (stmt.step()) {
      const row = stmt.getAsObject();
      list.push({
        ...row,
        highlights: row.highlights ? JSON.parse(row.highlights as string) : [],
        tags: row.tags ? JSON.parse(row.tags as string) : []
      });
    }
    stmt.free();
    res.json(list);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/projects
router.post("/", (req, res) => {
  try {
    const db = getDb();
    const p = req.body;
    db.run(
      `INSERT OR REPLACE INTO projects (id, title, subtitle, category, period, description, highlights, tags, repoUrl, badgeUrl, iconName, philosophicalLink)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        p.id,
        p.title,
        p.subtitle,
        p.category,
        p.period,
        p.description,
        JSON.stringify(p.highlights || []),
        JSON.stringify(p.tags || []),
        p.repoUrl,
        p.badgeUrl || "",
        p.iconName,
        p.philosophicalLink
      ]
    );
    saveDatabase();
    res.json({ success: true, project: p });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/projects/:id
router.delete("/:id", (req, res) => {
  try {
    const db = getDb();
    db.run("DELETE FROM projects WHERE id = ?", [req.params.id]);
    saveDatabase();
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
