import fs from "fs";
import path from "path";
import initSqlJs, { Database } from "sql.js";
import {
  INITIAL_POSTS,
  INITIAL_THOUGHTS,
  INITIAL_REVIEWS,
  PROJECTS_DATA,
  MIND_MODELS
} from "../../src/data/initialData.js";

const DB_DIR = path.join(process.cwd(), "data");
const DB_FILE = path.join(DB_DIR, "nebulatide.sqlite");

let db: Database;

export async function initDatabase(): Promise<Database> {
  if (db) return db;

  const SQL = await initSqlJs();

  if (!fs.existsSync(DB_DIR)) {
    fs.mkdirSync(DB_DIR, { recursive: true });
  }

  if (fs.existsSync(DB_FILE)) {
    const filebuffer = fs.readFileSync(DB_FILE);
    db = new SQL.Database(filebuffer);
    console.log("[Database] Loaded existing SQLite database from disk.");
  } else {
    db = new SQL.Database();
    console.log("[Database] Initializing new SQLite database with schema and seed data...");

    // Create tables
    db.run(`
      CREATE TABLE IF NOT EXISTS projects (
        id TEXT PRIMARY KEY,
        title TEXT,
        subtitle TEXT,
        category TEXT,
        period TEXT,
        description TEXT,
        highlights TEXT,
        tags TEXT,
        repoUrl TEXT,
        badgeUrl TEXT,
        iconName TEXT,
        philosophicalLink TEXT
      );

      CREATE TABLE IF NOT EXISTS posts (
        id TEXT PRIMARY KEY,
        title TEXT,
        subtitle TEXT,
        excerpt TEXT,
        content TEXT,
        category TEXT,
        tags TEXT,
        date TEXT,
        readTime TEXT,
        coverImage TEXT,
        featured INTEGER,
        likes INTEGER,
        author TEXT
      );

      CREATE TABLE IF NOT EXISTS fragments (
        id TEXT PRIMARY KEY,
        content TEXT,
        createdAt TEXT,
        moodTag TEXT,
        likes INTEGER,
        isStarred INTEGER
      );

      CREATE TABLE IF NOT EXISTS rituals (
        id TEXT PRIMARY KEY,
        title TEXT,
        dateRange TEXT,
        highTideWins TEXT,
        lowTideLearnings TEXT,
        insightPearl TEXT,
        createdAt TEXT
      );

      CREATE TABLE IF NOT EXISTS mind_models (
        id TEXT PRIMARY KEY,
        title TEXT,
        formula TEXT,
        description TEXT,
        icon TEXT
      );
    `);

    // Seed default data
    PROJECTS_DATA.forEach((p) => {
      db.run(
        `INSERT INTO projects (id, title, subtitle, category, period, description, highlights, tags, repoUrl, badgeUrl, iconName, philosophicalLink)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          p.id,
          p.title,
          p.subtitle,
          p.category,
          p.period,
          p.description,
          JSON.stringify(p.highlights),
          JSON.stringify(p.tags),
          p.repoUrl,
          p.badgeUrl || "",
          p.iconName,
          p.philosophicalLink
        ]
      );
    });

    INITIAL_POSTS.forEach((p) => {
      db.run(
        `INSERT INTO posts (id, title, subtitle, excerpt, content, category, tags, date, readTime, coverImage, featured, likes, author)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          p.id,
          p.title,
          p.subtitle,
          p.excerpt,
          p.content,
          p.category,
          JSON.stringify(p.tags),
          p.date,
          p.readTime,
          p.coverImage,
          p.featured ? 1 : 0,
          p.likes,
          JSON.stringify(p.author)
        ]
      );
    });

    INITIAL_THOUGHTS.forEach((t) => {
      db.run(
        `INSERT INTO fragments (id, content, createdAt, moodTag, likes, isStarred)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [t.id, t.content, t.createdAt, t.moodTag, t.likes, t.isStarred ? 1 : 0]
      );
    });

    INITIAL_REVIEWS.forEach((r) => {
      db.run(
        `INSERT INTO rituals (id, title, dateRange, highTideWins, lowTideLearnings, insightPearl, createdAt)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [
          r.id,
          r.title,
          r.dateRange,
          JSON.stringify(r.highTideWins),
          JSON.stringify(r.lowTideLearnings),
          r.insightPearl,
          r.createdAt
        ]
      );
    });

    MIND_MODELS.forEach((m, idx) => {
      db.run(
        `INSERT INTO mind_models (id, title, formula, description, icon)
         VALUES (?, ?, ?, ?, ?)`,
        [`mm-${idx + 1}`, m.title, m.formula, m.description, m.icon]
      );
    });

    saveDatabase();
  }

  return db;
}

export function getDb(): Database {
  if (!db) {
    throw new Error("Database has not been initialized. Call initDatabase() first.");
  }
  return db;
}

export function saveDatabase(): void {
  if (db) {
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_FILE, buffer);
  }
}
