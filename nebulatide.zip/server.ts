import { startServer } from "./server/index.js";

startServer().catch((err) => {
  console.error("Fatal: Failed to start NebulaTide server:", err);
});
