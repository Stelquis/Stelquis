import { Post, ProjectItem, ThoughtFragment, TideReview, MindModel } from '../types';

/**
 * NebulaTide Client API Adapter
 * Standardized RESTful fetch methods to communicate with Express / SQLite backend
 */

export async function fetchProjects(): Promise<ProjectItem[]> {
  const res = await fetch('/api/projects');
  if (!res.ok) throw new Error('Failed to fetch projects');
  return res.json();
}

export async function saveProject(project: ProjectItem): Promise<{ success: boolean; project: ProjectItem }> {
  const res = await fetch('/api/projects', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(project)
  });
  if (!res.ok) throw new Error('Failed to save project');
  return res.json();
}

export async function deleteProject(id: string): Promise<{ success: boolean }> {
  const res = await fetch(`/api/projects/${id}`, { method: 'DELETE' });
  if (!res.ok) throw new Error('Failed to delete project');
  return res.json();
}

export async function fetchPosts(): Promise<Post[]> {
  const res = await fetch('/api/posts');
  if (!res.ok) throw new Error('Failed to fetch posts');
  return res.json();
}

export async function savePost(post: Post): Promise<{ success: boolean; post: Post }> {
  const res = await fetch('/api/posts', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(post)
  });
  if (!res.ok) throw new Error('Failed to save post');
  return res.json();
}

export async function deletePost(id: string): Promise<{ success: boolean }> {
  const res = await fetch(`/api/posts/${id}`, { method: 'DELETE' });
  if (!res.ok) throw new Error('Failed to delete post');
  return res.json();
}

export async function fetchFragments(): Promise<ThoughtFragment[]> {
  const res = await fetch('/api/fragments');
  if (!res.ok) throw new Error('Failed to fetch fragments');
  return res.json();
}

export async function saveFragment(fragment: ThoughtFragment): Promise<{ success: boolean; fragment: ThoughtFragment }> {
  const res = await fetch('/api/fragments', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(fragment)
  });
  if (!res.ok) throw new Error('Failed to save fragment');
  return res.json();
}

export async function deleteFragment(id: string): Promise<{ success: boolean }> {
  const res = await fetch(`/api/fragments/${id}`, { method: 'DELETE' });
  if (!res.ok) throw new Error('Failed to delete fragment');
  return res.json();
}

export async function fetchRituals(): Promise<TideReview[]> {
  const res = await fetch('/api/rituals');
  if (!res.ok) throw new Error('Failed to fetch rituals');
  return res.json();
}

export async function saveRitual(ritual: TideReview): Promise<{ success: boolean; ritual: TideReview }> {
  const res = await fetch('/api/rituals', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(ritual)
  });
  if (!res.ok) throw new Error('Failed to save ritual');
  return res.json();
}

export async function deleteRitual(id: string): Promise<{ success: boolean }> {
  const res = await fetch(`/api/rituals/${id}`, { method: 'DELETE' });
  if (!res.ok) throw new Error('Failed to delete ritual');
  return res.json();
}

export async function fetchMindModels(): Promise<MindModel[]> {
  const res = await fetch('/api/mind-models');
  if (!res.ok) throw new Error('Failed to fetch mind models');
  return res.json();
}
