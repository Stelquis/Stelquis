export interface Post {
  id: string;
  title: string;
  subtitle: string;
  excerpt: string;
  content: string;
  category: string;
  tags: string[];
  date: string;
  readTime: string;
  coverImage: string;
  featured?: boolean;
  likes: number;
  author: {
    name: string;
    avatar: string;
    role: string;
  };
}

export interface ThoughtFragment {
  id: string;
  content: string;
  createdAt: string;
  moodTag: '混沌' | '微光' | '潮汐' | '珍珠' | '暗流';
  likes: number;
  isStarred?: boolean;
}

export interface ShellItem {
  id: string;
  title: string;
  type: 'try' | 'learning' | 'pearl';
  description: string;
  date: string;
}

export interface TideReview {
  id: string;
  title: string;
  dateRange: string;
  highTideWins: string[]; // 涨潮收获
  lowTideLearnings: ShellItem[]; // 退潮捡到的贝壳
  insightPearl: string; // 凝结的珍珠/智慧
  createdAt: string;
}

export interface WeavingGoal {
  id: string;
  title: string;
  direction: string;
  flowLevel: '高能涨潮' | '静谧退潮' | '微光试探';
  status: 'planning' | 'in_flow' | 'completed';
  shellsLinked: string[];
}

export interface ProjectItem {
  id: string;
  title: string;
  subtitle: string;
  category: string;
  period: string;
  description: string;
  highlights: string[];
  tags: string[];
  repoUrl: string;
  badgeUrl?: string;
  iconName: string;
  philosophicalLink: string;
}

export interface MindModel {
  title: string;
  formula: string;
  description: string;
  icon: string;
}
