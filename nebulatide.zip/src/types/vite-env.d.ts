/// <reference types="vite/client" />

interface ImportMetaGlob {
  (pattern: string, options?: { query?: string; eager?: boolean }): Record<string, any>;
}

interface ImportMeta {
  readonly glob: ImportMetaGlob;
}
