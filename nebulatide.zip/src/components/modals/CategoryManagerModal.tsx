import React, { useState } from 'react';
import { X, Edit2, Trash2, Plus, Tag, Check } from 'lucide-react';

interface CategoryManagerModalProps {
  title?: string;
  categories: string[];
  getItemCount?: (catName: string) => number;
  itemLabel?: string;
  onClose: () => void;
  onAddCategory: (categoryName: string) => void;
  onRenameCategory: (oldName: string, newName: string) => void;
  onDeleteCategory: (categoryName: string) => void;
}

export const CategoryManagerModal: React.FC<CategoryManagerModalProps> = ({
  title = '分类与标签中心',
  categories,
  getItemCount,
  itemLabel = '项',
  onClose,
  onAddCategory,
  onRenameCategory,
  onDeleteCategory,
}) => {
  const [newCatInput, setNewCatInput] = useState('');
  const [editingCat, setEditingCat] = useState<string | null>(null);
  const [editCatInput, setEditCatInput] = useState('');

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatInput.trim()) return;
    onAddCategory(newCatInput.trim());
    setNewCatInput('');
  };

  const handleStartEdit = (cat: string) => {
    setEditingCat(cat);
    setEditCatInput(cat);
  };

  const handleSaveEdit = (oldCat: string) => {
    if (!editCatInput.trim() || editCatInput.trim() === oldCat) {
      setEditingCat(null);
      return;
    }
    onRenameCategory(oldCat, editCatInput.trim());
    setEditingCat(null);
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-900/40 dark:bg-slate-950/75 backdrop-blur-md sm:backdrop-blur-xl flex items-center justify-center p-3 sm:p-4 transition-all duration-200 animate-in fade-in overflow-y-auto"
      onClick={(e) => {
        e.stopPropagation();
        onClose();
      }}
    >
      <div
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800/90 rounded-3xl max-w-lg w-full p-4 sm:p-6 space-y-4 sm:space-y-6 shadow-2xl animate-in zoom-in-95 duration-200 max-h-[90vh] overflow-y-auto custom-scrollbar text-slate-900 dark:text-slate-100"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <Tag className="w-5 h-5 text-teal-600 dark:text-teal-400" />
            <h3 className="text-lg font-bold text-slate-900 dark:text-white font-serif">{title}</h3>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-900 dark:hover:text-white p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Add New Category */}
        <form onSubmit={handleAdd} className="space-y-2">
          <label className="text-xs text-slate-700 dark:text-slate-300 block font-medium">新增分类 / 标签模版</label>
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="输入分类名称..."
              value={newCatInput}
              onChange={(e) => setNewCatInput(e.target.value)}
              className="flex-1 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3.5 py-2 text-xs text-slate-900 dark:text-slate-200 focus:outline-none focus:border-teal-500"
            />
            <button
              type="submit"
              className="px-4 py-2 bg-teal-600 hover:bg-teal-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1 transition-all shadow-md shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>添加分类</span>
            </button>
          </div>
        </form>

        {/* Existing Categories List */}
        <div className="space-y-2">
          <div className="flex justify-between items-center text-xs text-slate-500 dark:text-slate-400 mb-1">
            <span>分类/标签列表 ({categories.filter((c) => c !== '全部' && c !== 'all').length} 个)</span>
            <span className="text-[11px] text-slate-400 dark:text-slate-500">双击或点击图标编辑名称</span>
          </div>

          <div className="max-h-72 overflow-y-auto space-y-2 pr-1 custom-scrollbar">
            {categories
              .filter((c) => c !== '全部' && c !== 'all')
              .map((cat) => {
                const count = getItemCount ? getItemCount(cat) : undefined;
                const isEditing = editingCat === cat;

                return (
                  <div
                    key={cat}
                    className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 dark:bg-slate-950/70 border border-slate-200 dark:border-slate-800/80 hover:border-slate-300 dark:hover:border-slate-700 transition-all"
                  >
                    {isEditing ? (
                      <div className="flex items-center gap-2 flex-1 mr-2">
                        <input
                          type="text"
                          value={editCatInput}
                          onChange={(e) => setEditCatInput(e.target.value)}
                          className="flex-1 bg-white dark:bg-slate-900 border border-teal-500 text-teal-800 dark:text-teal-200 text-xs px-3 py-1.5 rounded-lg focus:outline-none"
                          autoFocus
                        />
                        <button
                          onClick={() => handleSaveEdit(cat)}
                          className="p-1.5 bg-teal-600 text-white rounded-lg hover:bg-teal-500"
                          title="保存更改"
                        >
                          <Check className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2.5">
                        <span className="w-2 h-2 rounded-full bg-teal-500" />
                        <span className="text-xs font-medium text-slate-800 dark:text-slate-200 font-serif">{cat}</span>
                        {count !== undefined && (
                          <span className="text-[11px] font-mono text-slate-500 dark:text-slate-400 bg-white dark:bg-slate-900 px-2 py-0.5 rounded-full border border-slate-200 dark:border-slate-800">
                            {count} {itemLabel}
                          </span>
                        )}
                      </div>
                    )}

                    {!isEditing && (
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleStartEdit(cat)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-teal-600 dark:hover:text-teal-300 hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors"
                          title="重命名此分类"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => {
                            if (
                              window.confirm(
                                `确认要删除分类 “${cat}” 么？关联数据将归入默认分类。`
                              )
                            ) {
                              onDeleteCategory(cat);
                            }
                          }}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-500 hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors"
                          title="删除分类"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}
          </div>
        </div>

        <div className="pt-2 border-t border-slate-200 dark:border-slate-800 text-right">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
          >
            完成并关闭
          </button>
        </div>
      </div>
    </div>
  );
};
