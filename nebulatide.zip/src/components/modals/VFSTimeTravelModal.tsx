import React, { useState, useEffect } from "react";
import {
  GitCommit,
  GitBranch,
  History,
  RotateCcw,
  Sparkles,
  X,
  FileCode,
  CheckCircle2,
  AlertCircle,
  Eye,
  ArrowRight,
  User,
  Clock
} from "lucide-react";
import { vfsGitService, VFSCommit, DiffResult } from "../../services/vfsGitService";

interface VFSTimeTravelModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialFilePath?: string;
  onRollbackSuccess?: () => void;
}

export const VFSTimeTravelModal: React.FC<VFSTimeTravelModalProps> = ({
  isOpen,
  onClose,
  initialFilePath,
  onRollbackSuccess
}) => {
  const [selectedFilePath, setSelectedFilePath] = useState<string>(initialFilePath || "");
  const [commits, setCommits] = useState<VFSCommit[]>([]);
  const [selectedCommitHash, setSelectedCommitHash] = useState<string>("");
  const [compareCommitHash, setCompareCommitHash] = useState<string>("");
  const [diffResult, setDiffResult] = useState<DiffResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [rollingBack, setRollingBack] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ type: "success" | "error"; text: string } | null>(null);

  // Available VFS files to select
  const availableFiles = [
    { label: "全局全量 Commits", value: "" },
    { label: "@宣言/星云潮汐宣言.md", value: "@宣言/星云潮汐宣言.md" },
    { label: "@文章/潮汐中的数字哲学_从高频信息流到自我沉淀.md", value: "@文章/潮汐中的数字哲学_从高频信息流到自我沉淀.md" },
    { label: "@档案/星云航行者档案.md", value: "@档案/星云航行者档案.md" }
  ];

  useEffect(() => {
    if (isOpen) {
      loadHistory(selectedFilePath || initialFilePath || "");
    }
  }, [isOpen, selectedFilePath]);

  const loadHistory = async (filePath?: string) => {
    setLoading(true);
    setStatusMessage(null);
    try {
      const res = await vfsGitService.getHistory(filePath);
      setCommits(res.history);
      if (res.history.length > 0) {
        const latest = res.history[0];
        setSelectedCommitHash(latest.hash);
        if (latest.parentHash) {
          setCompareCommitHash(latest.parentHash);
          loadDiff(latest.parentHash, latest.hash);
        } else {
          loadDiff(undefined, latest.hash);
        }
      } else {
        setDiffResult(null);
      }
    } catch (err: any) {
      setStatusMessage({ type: "error", text: "加载 Commit 历史失败: " + err.message });
    } finally {
      setLoading(false);
    }
  };

  const loadDiff = async (oldHash?: string, newHash?: string) => {
    try {
      const result = await vfsGitService.computeDiff({ oldHash, newHash });
      setDiffResult(result);
    } catch (err: any) {
      console.error("Diff load error:", err);
    }
  };

  const handleSelectCommit = (hash: string) => {
    setSelectedCommitHash(hash);
    const target = commits.find(c => c.hash === hash);
    if (target && target.parentHash) {
      setCompareCommitHash(target.parentHash);
      loadDiff(target.parentHash, hash);
    } else {
      setCompareCommitHash("");
      loadDiff(undefined, hash);
    }
  };

  const handleRollback = async () => {
    if (!selectedCommitHash) return;
    setRollingBack(true);
    setStatusMessage(null);

    try {
      const res = await vfsGitService.rollback(selectedCommitHash);
      if (res.success) {
        setStatusMessage({ type: "success", text: res.message });
        await loadHistory(selectedFilePath);
        if (onRollbackSuccess) onRollbackSuccess();
      } else {
        setStatusMessage({ type: "error", text: res.message });
      }
    } catch (err: any) {
      setStatusMessage({ type: "error", text: "时光倒流失败: " + err.message });
    } finally {
      setRollingBack(false);
    }
  };

  if (!isOpen) return null;

  const currentCommit = commits.find(c => c.hash === selectedCommitHash);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-slate-950/70 backdrop-blur-md animate-in fade-in duration-200">
      <div
        onClick={e => e.stopPropagation()}
        className="w-full max-w-5xl h-[85vh] bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col animate-in zoom-in-95 duration-200"
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-teal-500/10 text-teal-600 dark:text-teal-400 border border-teal-500/20">
              <History className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  VFS Git 时光倒流与版本 Diff
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-teal-500/10 text-teal-600 dark:text-teal-300 border border-teal-500/20">
                  vfs-git-engine
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                记录全栈 Markdown 节点的版本快照，支持逐行对比与一键时光倒流还原
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Status Notification Banner */}
        {statusMessage && (
          <div
            className={`px-6 py-2.5 text-xs font-medium flex items-center justify-between ${
              statusMessage.type === "success"
                ? "bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border-b border-emerald-500/20"
                : "bg-rose-500/10 text-rose-700 dark:text-rose-300 border-b border-rose-500/20"
            }`}
          >
            <div className="flex items-center gap-2">
              {statusMessage.type === "success" ? (
                <CheckCircle2 className="w-4 h-4 shrink-0" />
              ) : (
                <AlertCircle className="w-4 h-4 shrink-0" />
              )}
              <span>{statusMessage.text}</span>
            </div>
            <button
              onClick={() => setStatusMessage(null)}
              className="text-[10px] underline hover:opacity-80"
            >
              忽略
            </button>
          </div>
        )}

        {/* Main Content Body */}
        <div className="flex-1 min-h-0 grid grid-cols-1 md:grid-cols-12 divide-y md:divide-y-0 md:divide-x divide-slate-200 dark:divide-slate-800">
          {/* Left Column: File Selector & Commit Timeline (4 cols) */}
          <div className="md:col-span-4 p-4 flex flex-col bg-slate-50/40 dark:bg-slate-950/30 overflow-y-auto custom-scrollbar">
            {/* File Filter Dropdown */}
            <div className="mb-4">
              <label className="block text-[11px] font-bold text-slate-500 dark:text-slate-400 mb-1.5 uppercase tracking-wider">
                目标 VFS 虚拟节点
              </label>
              <select
                value={selectedFilePath}
                onChange={e => setSelectedFilePath(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-teal-500/50"
              >
                {availableFiles.map(f => (
                  <option key={f.value} value={f.value}>
                    {f.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Commit List Timeline Header */}
            <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-200 dark:border-slate-800">
              <span className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                <GitCommit className="w-3.5 h-3.5 text-teal-500" />
                <span>版本提交记录 ({commits.length})</span>
              </span>
            </div>

            {/* Commit Cards */}
            {loading ? (
              <div className="py-12 text-center text-xs text-slate-400">加载版本快照中...</div>
            ) : commits.length === 0 ? (
              <div className="py-12 text-center text-xs text-slate-400">暂无版本 Commit 快照</div>
            ) : (
              <div className="space-y-2.5">
                {commits.map(c => {
                  const isSelected = c.hash === selectedCommitHash;
                  return (
                    <div
                      key={c.hash}
                      onClick={() => handleSelectCommit(c.hash)}
                      className={`p-3 rounded-xl border transition-all cursor-pointer text-left ${
                        isSelected
                          ? "border-teal-500 bg-teal-500/10 dark:bg-teal-950/40 shadow-sm"
                          : "border-slate-200 dark:border-slate-800/80 hover:border-slate-300 dark:hover:border-slate-700 bg-white dark:bg-slate-900/60"
                      }`}
                    >
                      <div className="flex items-center justify-between gap-1 mb-1">
                        <span className="px-1.5 py-0.5 rounded font-mono text-[10px] font-bold bg-slate-200 dark:bg-slate-800 text-teal-600 dark:text-teal-400">
                          {c.hash.slice(0, 7)}
                        </span>
                        <span className="text-[10px] font-mono text-slate-400 flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {c.createdAt}
                        </span>
                      </div>

                      <div className="text-xs font-bold text-slate-900 dark:text-slate-100 line-clamp-2 mb-1.5">
                        {c.message}
                      </div>

                      <div className="flex items-center justify-between text-[10px] text-slate-500 dark:text-slate-400 border-t border-slate-100 dark:border-slate-800/60 pt-1.5">
                        <span className="flex items-center gap-1 truncate max-w-[140px]">
                          <User className="w-3 h-3 text-slate-400 shrink-0" />
                          <span>{c.author}</span>
                        </span>
                        <span className="font-mono text-teal-600 dark:text-teal-400 truncate max-w-[120px]">
                          {c.filePath.split("/").pop()}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Right Column: Line-by-Line Diff Viewer (8 cols) */}
          <div className="md:col-span-8 p-4 flex flex-col h-full overflow-hidden bg-white dark:bg-slate-900">
            {currentCommit ? (
              <>
                {/* Diff Header Bar */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 mb-3 border-b border-slate-200 dark:border-slate-800">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-900 dark:text-slate-100">
                        Commit [{currentCommit.hash.slice(0, 7)}]
                      </span>
                      <span className="text-xs text-slate-500 dark:text-slate-400">
                        {currentCommit.message}
                      </span>
                    </div>
                    <div className="text-[11px] font-mono text-slate-400 mt-0.5">
                      目标: {currentCommit.filePath}
                    </div>
                  </div>

                  {diffResult && (
                    <div className="flex items-center gap-2 text-xs font-mono shrink-0">
                      <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
                        +{diffResult.additions} 行
                      </span>
                      <span className="px-2 py-0.5 rounded bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/20">
                        -{diffResult.deletions} 行
                      </span>
                    </div>
                  )}
                </div>

                {/* Diff Content Box */}
                <div className="flex-1 min-h-0 bg-slate-950 text-slate-200 rounded-xl border border-slate-800 p-3 overflow-y-auto font-mono text-xs custom-scrollbar">
                  {diffResult && diffResult.diffLines.length > 0 ? (
                    diffResult.diffLines.map((line, idx) => {
                      let bgColor = "hover:bg-slate-900/50";
                      let textColor = "text-slate-300";
                      let prefix = " ";

                      if (line.type === "added") {
                        bgColor = "bg-emerald-950/40 border-l-2 border-emerald-500";
                        textColor = "text-emerald-300";
                        prefix = "+";
                      } else if (line.type === "removed") {
                        bgColor = "bg-rose-950/40 border-l-2 border-rose-500 line-through opacity-70";
                        textColor = "text-rose-300";
                        prefix = "-";
                      }

                      return (
                        <div
                          key={idx}
                          className={`flex items-start gap-3 px-2 py-0.5 rounded transition-colors ${bgColor} ${textColor}`}
                        >
                          <span className="w-8 select-none text-[10px] text-slate-600 text-right shrink-0">
                            {line.newLineNumber || line.oldLineNumber || ""}
                          </span>
                          <span className="w-3 select-none text-slate-500 font-bold shrink-0">{prefix}</span>
                          <span className="whitespace-pre-wrap break-all flex-1">{line.text}</span>
                        </div>
                      );
                    })
                  ) : (
                    <div className="py-12 text-center text-slate-500">对比数据为空或完全无变动</div>
                  )}
                </div>
              </>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center text-slate-400 text-xs">
                <FileCode className="w-10 h-10 mb-2 opacity-40 text-teal-500" />
                <span>请在左侧选择一个 Commit 版本以预览 Line-by-Line Diff 变化</span>
              </div>
            )}
          </div>
        </div>

        {/* Modal Footer Controls */}
        <div className="px-6 py-3.5 border-t border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-950/60 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-teal-500" />
            <span className="text-xs text-slate-600 dark:text-slate-400">
              {currentCommit ? `选定 Commit: ${currentCommit.hash.slice(0, 7)}` : "尚未选定 Commit"}
            </span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-medium text-slate-600 dark:text-slate-300 bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 transition-colors"
            >
              关闭
            </button>

            <button
              onClick={handleRollback}
              disabled={!selectedCommitHash || rollingBack}
              className="px-4 py-2 rounded-xl text-xs font-medium text-white bg-teal-600 hover:bg-teal-500 active:scale-95 transition-all shadow-md flex items-center gap-1.5 disabled:opacity-50 disabled:pointer-events-none"
            >
              <RotateCcw className={`w-3.5 h-3.5 ${rollingBack ? "animate-spin" : ""}`} />
              <span>{rollingBack ? "正在时光倒流还原..." : "⏪ 一键恢复至此版本 (Rollback)"}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
