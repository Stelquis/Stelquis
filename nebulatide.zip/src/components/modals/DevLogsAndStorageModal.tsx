import React, { useState, useEffect } from 'react';
import { Database, X, Plus, Pencil, Trash2, Check, FileCode, HardDrive, ShieldCheck, Clock, Sparkles, Zap, RefreshCw, Gauge, Activity, Play, CheckCircle2, AlertTriangle, Terminal } from 'lucide-react';

export interface DevLogEntry {
  id: string;
  date: string;
  version: string;
  tag: '[FEAT]' | '[DB]' | '[UI]' | '[PERF]' | '[REFACTOR]' | '[RELEASE]';
  title: string;
  content: string;
}

interface DevLogsAndStorageModalProps {
  dbStatusText: string;
  onUpdateStatusText: (newText: string) => void;
  stats: {
    postsCount: number;
    fragmentsCount: number;
    reviewsCount: number;
    projectsCount: number;
  };
  onClose: () => void;
}

const initialDevLogs: DevLogEntry[] = [
  {
    id: 'log-v1.7.0',
    date: '2026-07-31',
    version: 'v1.7.0',
    tag: '[REFACTOR]',
    title: '结构化 Markdown 文章解耦与高可用内容服务',
    content: '全量将硬编码文章重构抽离至 /content/posts/*.md 独立 Markdown 文件；自研轻量级 Frontmatter 提取解析器与动态/静态双模加载服务 markdownService，实现代码与内容解耦，极大提升了内容拓展性与维护容错率。',
  },
  {
    id: 'log-v1.6.5',
    date: '2026-07-30',
    version: 'v1.6.5',
    tag: '[PERF]',
    title: '语义缓存 (Semantic Cache) 与 Agent 自动化评估阵列',
    content: '全局集成 AI 语义缓存逻辑与请求击中率统计，打造 Agent Evaluation Harness 15+ 项自动化测试用例，实时监控回答精准度、语义偏差与 Token 消耗。',
  },
  {
    id: 'log-v1.6.0',
    date: '2026-07-28',
    version: 'v1.6.0',
    tag: '[FEAT]',
    title: '全局 AI 助手与 MCP 技能枢纽 (MCPSkillHub) 上线',
    content: '新增 GlobalAIAssistant 交互控制台，联动 MCP (Model Context Protocol) 技能生态，支持在 Web 端直接进行自然语言深度检索、复盘总结与系统架构分析。',
  },
  {
    id: 'log-v1.5.0',
    date: '2026-07-25',
    version: 'v1.5.0',
    tag: '[UI]',
    title: '苹果玻璃美学与日夜双主题沉浸适配',
    content: '全站支持 Light / Dark 双模式无缝切换，引入 Apple 极简毛玻璃与柔和微光物理参数；深度适配多端移动与桌面自适应流式布局。',
  },
  {
    id: 'log-v1.4.0',
    date: '2026-07-23',
    version: 'v1.4.0',
    tag: '[UI]',
    title: '极致视觉平滑与数据状态监测中心',
    content: '重构页脚 Footer 为可交互开发日志与数据库监控看板，支持全站数据源状态诊断、本地/云端同步检查与手动缓存清理。',
  },
  {
    id: 'log-v1.3.0',
    date: '2026-07-22',
    version: 'v1.3.0',
    tag: '[FEAT]',
    title: '全站分类维度模板管理中心上线',
    content: '新增支持全站文章、项目工程、星云思绪与顺势织网方向的模版化动态分类管理组件 CategoryManagerModal，打破静态配置壁垒。',
  },
  {
    id: 'log-v1.2.0',
    date: '2026-07-20',
    version: 'v1.2.0',
    tag: '[DB]',
    title: 'SQLite / Express 全栈持久化引擎就绪',
    content: '接入 Node.js Express 后端持久化 REST API 接口，实现全站文章、碎片、复盘自动离线落盘与在线高可用实时同步。',
  },
  {
    id: 'log-v1.1.0',
    date: '2026-07-18',
    version: 'v1.1.0',
    tag: '[FEAT]',
    title: '顺势织网 (Weaving Network) 目标联动系统',
    content: '将“潮汐复盘”中沉淀的贝壳转化为具象的 OKR 目标卡片，实现“混沌 - 沉淀 - 织网 - 执行”的闭环心智流转。',
  },
  {
    id: 'log-v1.0.0',
    date: '2026-07-15',
    version: 'v1.0.0',
    tag: '[RELEASE]',
    title: 'NebulaTide 宇宙漫游系统正式版发布 🎉',
    content: '基于 Vite + React + Tailwind + Motion 构建微光风应用，整合硬核工程项目案例与《NebulaTide 哲学宣言》，确立“清晰是混沌的沉积物”核心愿景。',
  },
  {
    id: 'log-v0.8.0',
    date: '2026-07-05',
    version: 'v0.8.0',
    tag: '[PERF]',
    title: 'DeepAstraDraft 工业 CAD Agent 语义检索接入',
    content: '集成 DeepAstraDraft 成果，支持 DWG/DXF 123 项语义参数提取展示，实现工业图纸自然语言 Agent 索引问答。',
  },
  {
    id: 'log-v0.5.0',
    date: '2026-06-25',
    version: 'v0.5.0',
    tag: '[FEAT]',
    title: '潮汐复盘 (Tide Retrospectives) 周期看板',
    content: '引入周度/月度潮汐复盘看板，提供“捡拾贝壳”与“划掉沙砾”双向反思机制，配合四象限心智地图。',
  },
  {
    id: 'log-v0.3.0',
    date: '2026-06-15',
    version: 'v0.3.0',
    tag: '[FEAT]',
    title: '灵感星云碎片 (Thoughts Cloud) 实时草稿流',
    content: '支持无负担的碎片化思考录入，提供不强求标签与标题的“星云沙盒”空间，守护温热的灵感雏形。',
  },
  {
    id: 'log-v0.1.0',
    date: '2026-06-01',
    version: 'v0.1.0',
    tag: '[FEAT]',
    title: 'NebulaTide 哲学工程立项与原型搭建',
    content: '完成 Vite + React + TypeScript 基础架构铺设，确定“星云 (Nebula)”与“潮汐 (Tide)”双核心交织的产品哲学。',
  },
];

export const DevLogsAndStorageModal: React.FC<DevLogsAndStorageModalProps> = ({
  dbStatusText,
  onUpdateStatusText,
  stats,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'status' | 'logs' | 'cache' | 'eval'>('status');
  const [statusInput, setStatusInput] = useState(dbStatusText);
  const [logs, setLogs] = useState<DevLogEntry[]>(() => {
    const saved = localStorage.getItem('tide-dev-logs');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      } catch (e) {
        console.warn('Failed to parse saved dev logs:', e);
      }
    }
    return initialDevLogs;
  });

  useEffect(() => {
    localStorage.setItem('tide-dev-logs', JSON.stringify(logs));
  }, [logs]);
  const [isEditingStatus, setIsEditingStatus] = useState(false);

  // Agent Evaluation Harness stats
  const [evalReport, setEvalReport] = useState<any | null>(null);
  const [evalLoading, setEvalLoading] = useState(false);

  const loadEvalData = async () => {
    try {
      const res = await fetch('/api/eval/last');
      if (res.ok) {
        const data = await res.json();
        if (data && data.result) {
          setEvalReport(data.result);
        }
      }
    } catch (e) {
      console.warn('Failed to load eval last report:', e);
    }
  };

  const handleRunEvalSuite = async () => {
    setEvalLoading(true);
    try {
      const res = await fetch('/api/eval/run', { method: 'POST' });
      if (res.ok) {
        const data = await res.json();
        if (data && data.report) {
          setEvalReport(data.report);
        }
      }
    } catch (e) {
      console.warn('Run eval suite error:', e);
    } finally {
      setEvalLoading(false);
    }
  };

  // Semantic Cache stats
  const [cacheStats, setCacheStats] = useState<{
    totalQueries: number;
    cacheHits: number;
    cacheMisses: number;
    hitRate: string;
    totalTokensSaved: number;
    entryCount: number;
  }>({
    totalQueries: 0,
    cacheHits: 0,
    cacheMisses: 0,
    hitRate: '0.0%',
    totalTokensSaved: 0,
    entryCount: 0,
  });
  const [cacheEntries, setCacheEntries] = useState<any[]>([]);
  const [loadingCache, setLoadingCache] = useState(false);

  const loadCacheData = async () => {
    setLoadingCache(true);
    try {
      const res = await fetch('/api/cache/entries');
      if (res.ok) {
        const data = await res.json();
        if (data && data.stats) {
          setCacheStats(data.stats);
        }
        if (data && Array.isArray(data.entries)) {
          setCacheEntries(data.entries);
        }
      }
    } catch (e) {
      console.warn('Failed to fetch cache stats:', e);
    } finally {
      setLoadingCache(false);
    }
  };

  useEffect(() => {
    if (activeTab === 'cache') {
      loadCacheData();
    } else if (activeTab === 'eval') {
      loadEvalData();
    }
  }, [activeTab]);

  const handleClearCache = async () => {
    try {
      const res = await fetch('/api/cache/clear', { method: 'POST' });
      if (res.ok) {
        loadCacheData();
      }
    } catch (e) {
      console.warn('Clear cache failed:', e);
    }
  };

  // Dev log form
  const [showLogForm, setShowLogForm] = useState(false);
  const [editingLog, setEditingLog] = useState<DevLogEntry | null>(null);
  const [logVersion, setLogVersion] = useState('v1.6.0');
  const [logTag, setLogTag] = useState<DevLogEntry['tag']>('[FEAT]');
  const [logTitle, setLogTitle] = useState('');
  const [logContent, setLogContent] = useState('');

  const handleSaveStatus = (e: React.FormEvent) => {
    e.preventDefault();
    if (statusInput.trim()) {
      onUpdateStatusText(statusInput.trim());
      setIsEditingStatus(false);
    }
  };

  const handleOpenAddLog = () => {
    setEditingLog(null);
    setLogVersion(`v2.${logs.length + 2}.0`);
    setLogTag('[FEAT]');
    setLogTitle('');
    setLogContent('');
    setShowLogForm(true);
  };

  const handleOpenEditLog = (entry: DevLogEntry) => {
    setEditingLog(entry);
    setLogVersion(entry.version);
    setLogTag(entry.tag);
    setLogTitle(entry.title);
    setLogContent(entry.content);
    setShowLogForm(true);
  };

  const handleDeleteLog = (id: string) => {
    setLogs((prev) => prev.filter((l) => l.id !== id));
  };

  const handleSaveLog = (e: React.FormEvent) => {
    e.preventDefault();
    if (!logTitle.trim() || !logContent.trim()) return;

    if (editingLog) {
      setLogs((prev) =>
        prev.map((l) =>
          l.id === editingLog.id
            ? {
                ...l,
                version: logVersion.trim(),
                tag: logTag,
                title: logTitle.trim(),
                content: logContent.trim(),
              }
            : l
        )
      );
    } else {
      const newEntry: DevLogEntry = {
        id: `log-${Date.now()}`,
        date: new Date().toISOString().split('T')[0],
        version: logVersion.trim() || 'v2.6.0',
        tag: logTag,
        title: logTitle.trim(),
        content: logContent.trim(),
      };
      setLogs((prev) => [newEntry, ...prev]);
    }

    setShowLogForm(false);
  };

  const getTagStyle = (tag: DevLogEntry['tag']) => {
    switch (tag) {
      case '[FEAT]':
        return 'bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-300 border-teal-300 dark:border-teal-500/30';
      case '[DB]':
        return 'bg-indigo-100 dark:bg-indigo-950 text-indigo-800 dark:text-indigo-300 border-indigo-300 dark:border-indigo-500/30';
      case '[UI]':
        return 'bg-purple-100 dark:bg-purple-950 text-purple-800 dark:text-purple-300 border-purple-300 dark:border-purple-500/30';
      case '[PERF]':
        return 'bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 border-amber-300 dark:border-amber-500/30';
      case '[REFACTOR]':
        return 'bg-rose-100 dark:bg-rose-950 text-rose-800 dark:text-rose-300 border-rose-300 dark:border-rose-500/30';
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-900/40 dark:bg-slate-950/75 backdrop-blur-md sm:backdrop-blur-xl flex items-center justify-center p-3 sm:p-4 transition-all duration-200 animate-in fade-in overflow-y-auto"
      onClick={(e) => {
        e.stopPropagation();
        onClose();
      }}
    >
      <div
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800/90 rounded-3xl max-w-2xl w-full max-h-[85vh] flex flex-col shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200 text-slate-900 dark:text-slate-100"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Header */}
        <div className="p-6 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between shrink-0 bg-slate-50 dark:bg-slate-950/50">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-teal-100 dark:bg-teal-950 border border-teal-300 dark:border-teal-500/40 text-teal-700 dark:text-teal-400">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white font-serif">
                SQLite 数据库持久化 & 系统开发日志
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-mono">
                System Storage Engine & Developer Changelogs
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-2 px-6 pt-4 border-b border-slate-200 dark:border-slate-800/80 bg-white dark:bg-slate-900 shrink-0">
          <button
            onClick={() => setActiveTab('status')}
            className={`pb-3 text-xs font-mono font-medium border-b-2 transition-all flex items-center gap-2 ${
              activeTab === 'status'
                ? 'border-teal-500 text-teal-700 dark:text-teal-300 font-semibold'
                : 'border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            <HardDrive className="w-4 h-4" />
            <span>存储状态与引擎标语</span>
          </button>
          <button
            onClick={() => setActiveTab('logs')}
            className={`pb-3 text-xs font-mono font-medium border-b-2 transition-all flex items-center gap-2 ${
              activeTab === 'logs'
                ? 'border-teal-500 text-teal-700 dark:text-teal-300 font-semibold'
                : 'border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            <FileCode className="w-4 h-4" />
            <span>系统开发演化日志 ({logs.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('cache')}
            className={`pb-3 text-xs font-mono font-medium border-b-2 transition-all flex items-center gap-2 ${
              activeTab === 'cache'
                ? 'border-teal-500 text-teal-700 dark:text-teal-300 font-semibold'
                : 'border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            <Zap className="w-4 h-4 text-teal-500" />
            <span>语义缓存与 Token 剪裁 ({cacheStats.entryCount})</span>
          </button>

          <button
            onClick={() => setActiveTab('eval')}
            className={`pb-3 text-xs font-mono font-medium border-b-2 transition-all flex items-center gap-2 ${
              activeTab === 'eval'
                ? 'border-teal-500 text-teal-700 dark:text-teal-300 font-semibold'
                : 'border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            <Gauge className="w-4 h-4 text-amber-500" />
            <span>Agent 沙盒评估与测速 ({evalReport ? `${evalReport.overallScore}分` : '待评测'})</span>
          </button>
        </div>

        {/* Body Content */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 custom-scrollbar">
          
          {/* TAB 1: STATUS & SETTINGS */}
          {activeTab === 'status' && (
            <div className="space-y-6">
              
              {/* Editable Status Banner Box */}
              <div className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono text-teal-700 dark:text-teal-400 flex items-center gap-1.5 font-semibold">
                    <ShieldCheck className="w-4 h-4 text-teal-600 dark:text-teal-400" />
                    <span>顶部持久化提示标语配置</span>
                  </span>
                  {!isEditingStatus && (
                    <button
                      onClick={() => setIsEditingStatus(true)}
                      className="px-2.5 py-1 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 hover:border-teal-500 text-slate-700 dark:text-slate-300 hover:text-teal-600 dark:hover:text-teal-300 text-xs font-mono transition-all flex items-center gap-1 shadow-sm"
                    >
                      <Pencil className="w-3 h-3" />
                      <span>自定义修改标语</span>
                    </button>
                  )}
                </div>

                {isEditingStatus ? (
                  <form onSubmit={handleSaveStatus} className="space-y-3 pt-1">
                    <input
                      type="text"
                      value={statusInput}
                      onChange={(e) => setStatusInput(e.target.value)}
                      className="w-full bg-white dark:bg-slate-900 border border-teal-500/50 rounded-xl px-3 py-2 text-xs text-teal-800 dark:text-teal-200 font-mono focus:outline-none"
                    />
                    <div className="flex justify-end gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          setStatusInput(dbStatusText);
                          setIsEditingStatus(false);
                        }}
                        className="px-3 py-1.5 rounded-lg text-xs font-mono text-slate-600 dark:text-slate-400 bg-slate-200 dark:bg-slate-800"
                      >
                        取消
                      </button>
                      <button
                        type="submit"
                        className="px-3.5 py-1.5 rounded-lg text-xs font-mono text-white bg-teal-600 hover:bg-teal-500 shadow"
                      >
                        保存提示语
                      </button>
                    </div>
                  </form>
                ) : (
                  <p className="text-xs font-mono text-slate-800 dark:text-slate-200 bg-white dark:bg-slate-900/80 p-3 rounded-xl border border-slate-200 dark:border-slate-800/80">
                    {dbStatusText}
                  </p>
                )}
              </div>

              {/* Live Database Stats */}
              <div className="space-y-3">
                <h4 className="text-xs font-mono text-slate-500 dark:text-slate-400 uppercase tracking-wider font-semibold">
                  实时 SQLite 数据表持久化统计
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800 text-center">
                    <span className="text-lg font-bold text-teal-700 dark:text-teal-300 font-mono block">{stats.postsCount}</span>
                    <span className="text-[10px] text-slate-500 dark:text-slate-400 font-mono">articles (文章)</span>
                  </div>
                  <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800 text-center">
                    <span className="text-lg font-bold text-indigo-700 dark:text-indigo-300 font-mono block">{stats.fragmentsCount}</span>
                    <span className="text-[10px] text-slate-500 dark:text-slate-400 font-mono">fragments (碎片)</span>
                  </div>
                  <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800 text-center">
                    <span className="text-lg font-bold text-purple-700 dark:text-purple-300 font-mono block">{stats.reviewsCount}</span>
                    <span className="text-[10px] text-slate-500 dark:text-slate-400 font-mono">rituals (周复盘)</span>
                  </div>
                  <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800 text-center">
                    <span className="text-lg font-bold text-amber-700 dark:text-amber-300 font-mono block">{stats.projectsCount}</span>
                    <span className="text-[10px] text-slate-500 dark:text-slate-400 font-mono">projects (工程)</span>
                  </div>
                </div>
              </div>

              {/* DB Technical Specs */}
              <div className="p-4 bg-slate-50 dark:bg-slate-950/60 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-2 text-xs font-mono text-slate-600 dark:text-slate-400">
                <div className="flex items-center justify-between text-slate-800 dark:text-slate-300">
                  <span>存储引擎:</span>
                  <span className="text-teal-700 dark:text-teal-400 font-bold">Better-SQLite3 / SQLite File DB</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>状态机制:</span>
                  <span className="text-emerald-600 dark:text-emerald-400">Dual Sync (Client Memory + Express REST)</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>隔离级别:</span>
                  <span className="text-slate-500 dark:text-slate-400">WAL Mode (Write-Ahead Logging)</span>
                </div>
              </div>

            </div>
          )}

          {/* TAB 2: DEV LOGS */}
          {activeTab === 'logs' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono text-slate-500 dark:text-slate-400">
                  按时间倒序排列的系统迭代变更履历：
                </span>
                <button
                  onClick={handleOpenAddLog}
                  className="px-3 py-1.5 rounded-xl text-xs font-mono text-white bg-teal-600 hover:bg-teal-500 transition-all flex items-center gap-1 shadow-sm"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>添加开发日志</span>
                </button>
              </div>

              {/* Log Timeline List */}
              <div className="space-y-3">
                {logs.map((log) => (
                  <div
                    key={log.id}
                    className="p-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800/80 rounded-2xl hover:border-slate-300 dark:hover:border-slate-700 transition-all space-y-2 group"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full border ${getTagStyle(log.tag)}`}>
                          {log.tag}
                        </span>
                        <span className="text-xs font-mono text-slate-800 dark:text-slate-300 font-bold">
                          {log.version}
                        </span>
                        <span className="text-[11px] font-mono text-slate-400 dark:text-slate-500">
                          {log.date}
                        </span>
                      </div>

                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button
                          onClick={() => handleOpenEditLog(log)}
                          className="p-1 text-slate-400 hover:text-teal-600 dark:hover:text-teal-300 hover:bg-slate-200 dark:hover:bg-slate-900 rounded"
                          title="编辑日志"
                        >
                          <Pencil className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDeleteLog(log.id)}
                          className="p-1 text-slate-400 hover:text-rose-500 hover:bg-slate-200 dark:hover:bg-slate-900 rounded"
                          title="删除日志"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    <h5 className="text-sm font-bold text-slate-900 dark:text-slate-100 font-serif">
                      {log.title}
                    </h5>

                    <p className="text-xs text-slate-600 dark:text-slate-300 font-light leading-relaxed">
                      {log.content}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: SEMANTIC CACHE & TOKEN TRIMMING */}
          {activeTab === 'cache' && (
            <div className="space-y-6">
              
              {/* Stats overview cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3 bg-teal-500/10 border border-teal-500/20 rounded-xl text-center">
                  <span className="text-xl font-bold text-teal-600 dark:text-teal-400 font-mono block">
                    {cacheStats.hitRate}
                  </span>
                  <span className="text-[10px] text-teal-700 dark:text-teal-300/80 font-mono">语义缓存命中率</span>
                </div>
                <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-center">
                  <span className="text-xl font-bold text-emerald-600 dark:text-emerald-400 font-mono block">
                    {cacheStats.totalTokensSaved}
                  </span>
                  <span className="text-[10px] text-emerald-700 dark:text-emerald-300/80 font-mono">节省已计算 Token</span>
                </div>
                <div className="p-3 bg-indigo-500/10 border border-indigo-500/20 rounded-xl text-center">
                  <span className="text-xl font-bold text-indigo-600 dark:text-indigo-400 font-mono block">
                    {cacheStats.cacheHits} / {cacheStats.totalQueries}
                  </span>
                  <span className="text-[10px] text-indigo-700 dark:text-indigo-300/80 font-mono">命中次数 / 总查询</span>
                </div>
                <div className="p-3 bg-purple-500/10 border border-purple-500/20 rounded-xl text-center">
                  <span className="text-xl font-bold text-purple-600 dark:text-purple-400 font-mono block">
                    {cacheStats.entryCount}
                  </span>
                  <span className="text-[10px] text-purple-700 dark:text-purple-300/80 font-mono">活跃缓存条目</span>
                </div>
              </div>

              {/* Actions & Description */}
              <div className="bg-slate-50 dark:bg-slate-950 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono text-slate-700 dark:text-slate-300 font-semibold flex items-center gap-1.5">
                    <Zap className="w-4 h-4 text-teal-500" />
                    <span>智能 Jaccard + N-Gram 语义比对引擎</span>
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={loadCacheData}
                      className="px-2.5 py-1 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:text-teal-600 text-xs font-mono transition-all flex items-center gap-1"
                    >
                      <RefreshCw className={`w-3 h-3 ${loadingCache ? 'animate-spin' : ''}`} />
                      <span>刷新</span>
                    </button>
                    <button
                      onClick={handleClearCache}
                      className="px-2.5 py-1 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 text-rose-600 dark:text-rose-400 text-xs font-mono transition-all flex items-center gap-1"
                    >
                      <Trash2 className="w-3 h-3" />
                      <span>清空缓存</span>
                    </button>
                  </div>
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400 font-serif leading-relaxed">
                  系统对重复或高度相似的 AI 查询自动计算语义向量重合度。当相似度达到 82% 以上时直接命中本地高速缓存，大幅削减大模型 Token 消耗并实现毫秒级瞬间响应。
                </p>
              </div>

              {/* Cache Entry Items List */}
              <div className="space-y-3">
                <h4 className="text-xs font-mono text-slate-500 dark:text-slate-400 uppercase tracking-wider font-semibold">
                  缓存快照与相似度索引 ({cacheEntries.length})
                </h4>

                {cacheEntries.length === 0 ? (
                  <div className="p-8 text-center bg-slate-50 dark:bg-slate-950/50 rounded-2xl border border-dashed border-slate-200 dark:border-slate-800 text-xs text-slate-400 font-mono">
                    暂无缓存条目。在 AI 智囊对话框发起交互后将自动建立语义缓存。
                  </div>
                ) : (
                  <div className="space-y-2 max-h-[300px] overflow-y-auto custom-scrollbar pr-1">
                    {cacheEntries.map((entry: any) => (
                      <div
                        key={entry.id}
                        className="p-3 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800/80 rounded-xl space-y-1.5 hover:border-teal-500/40 transition-all"
                      >
                        <div className="flex items-center justify-between text-xs font-mono">
                          <span className="text-teal-600 dark:text-teal-400 font-bold truncate max-w-[240px]">
                            {entry.prompt}
                          </span>
                          <span className="bg-teal-500/10 text-teal-700 dark:text-teal-300 px-2 py-0.5 rounded-full text-[10px]">
                            Saved ~{entry.tokensSaved} tokens | Hits: {entry.hitCount}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-500 dark:text-slate-400 font-serif line-clamp-2 bg-white dark:bg-slate-900/60 p-2 rounded-lg border border-slate-200 dark:border-slate-800">
                          {entry.response?.output || entry.response?.reasoning}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 4: AGENT EVALUATION HARNESS */}
          {activeTab === 'eval' && (
            <div className="space-y-6">
              <div className="bg-gradient-to-r from-amber-500/10 via-teal-500/10 to-indigo-500/10 border border-amber-500/20 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-sm">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <Gauge className="w-5 h-5 text-amber-500" />
                    <h4 className="text-sm font-bold text-slate-900 dark:text-white font-mono">
                      Agent Evaluation Harness 沙盒评估与测速引擎
                    </h4>
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400 font-serif">
                    自动检测大模型在真机环境下的 Tool Calling 修复率、VFS 检索时延、语义缓存匹配精度与技能约束。
                  </p>
                </div>

                <button
                  onClick={handleRunEvalSuite}
                  disabled={evalLoading}
                  className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 disabled:opacity-50 text-slate-950 font-mono text-xs font-bold transition-all shadow-md flex items-center gap-2 shrink-0 cursor-pointer"
                >
                  <Play className={`w-3.5 h-3.5 fill-current ${evalLoading ? 'animate-spin' : ''}`} />
                  <span>{evalLoading ? '正在全面测速评测中...' : '发起全量自动化跑分评测'}</span>
                </button>
              </div>

              {/* Benchmark Overview Scoreboard */}
              {evalReport ? (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <div className="bg-slate-50 dark:bg-slate-950 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 text-center space-y-1">
                      <div className="text-[10px] font-mono text-slate-500 uppercase tracking-wider">综合评测得分</div>
                      <div className="text-2xl font-bold font-mono text-amber-500">{evalReport.overallScore} <span className="text-xs text-slate-400">/ 100</span></div>
                    </div>
                    <div className="bg-slate-50 dark:bg-slate-950 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 text-center space-y-1">
                      <div className="text-[10px] font-mono text-slate-500 uppercase tracking-wider">测试通过率</div>
                      <div className="text-2xl font-bold font-mono text-teal-500">{evalReport.passRate}%</div>
                    </div>
                    <div className="bg-slate-50 dark:bg-slate-950 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 text-center space-y-1">
                      <div className="text-[10px] font-mono text-slate-500 uppercase tracking-wider">测试项数</div>
                      <div className="text-2xl font-bold font-mono text-indigo-500">{evalReport.passedCount} / {evalReport.testCasesCount}</div>
                    </div>
                    <div className="bg-slate-50 dark:bg-slate-950 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 text-center space-y-1">
                      <div className="text-[10px] font-mono text-slate-500 uppercase tracking-wider">耗时 Latency</div>
                      <div className="text-2xl font-bold font-mono text-slate-700 dark:text-slate-200">{evalReport.totalDurationMs} <span className="text-xs text-slate-400">ms</span></div>
                    </div>
                  </div>

                  {/* Test Details List */}
                  <div className="space-y-3">
                    <h5 className="text-xs font-mono font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                      <Activity className="w-3.5 h-3.5 text-amber-500" />
                      <span>沙盒跑分细项清单 (Detailed Benchmark Items)</span>
                    </h5>

                    <div className="space-y-2">
                      {evalReport.details?.map((detail: any) => (
                        <div
                          key={detail.testId}
                          className="p-3.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800/90 rounded-xl space-y-2"
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              {detail.passed ? (
                                <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                              ) : (
                                <AlertTriangle className="w-4 h-4 text-rose-500 shrink-0" />
                              )}
                              <span className="text-xs font-bold text-slate-800 dark:text-slate-200 font-mono">
                                {detail.name}
                              </span>
                            </div>

                            <div className="flex items-center gap-2 font-mono text-[11px]">
                              <span className="px-2 py-0.5 rounded-full bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                                {detail.durationMs}ms
                              </span>
                              <span className={`px-2 py-0.5 rounded-full font-bold ${detail.passed ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400' : 'bg-rose-500/10 text-rose-500'}`}>
                                Score: {detail.score}
                              </span>
                            </div>
                          </div>

                          <p className="text-xs text-slate-600 dark:text-slate-400 font-serif pl-6">
                            {detail.message}
                          </p>

                          {detail.outputSample && (
                            <div className="ml-6 p-2 rounded-lg bg-slate-900 text-slate-300 font-mono text-[10px] overflow-x-auto truncate">
                              <span className="text-slate-500">$ output: </span>{detail.outputSample}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="p-10 text-center bg-slate-50 dark:bg-slate-950/50 rounded-2xl border border-dashed border-slate-200 dark:border-slate-800 space-y-3">
                  <Terminal className="w-8 h-8 text-slate-400 mx-auto" />
                  <div className="text-xs text-slate-400 font-mono">
                    尚未运行 Agent 自动化沙盒测试。点击右上角按钮开始真机性能评估。
                  </div>
                </div>
              )}
            </div>
          )}

        </div>

      </div>

      {/* Dev Log Edit/Create Sub-modal */}
      {showLogForm && (
        <div
          className="fixed inset-0 z-60 bg-slate-900/30 dark:bg-slate-950/75 backdrop-blur-md flex items-center justify-center p-4 transition-all duration-200 animate-in fade-in"
          onClick={() => setShowLogForm(false)}
        >
          <div
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800/90 rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl animate-in zoom-in-95 duration-200 text-slate-900 dark:text-slate-100"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-slate-800">
              <h4 className="text-sm font-bold text-slate-900 dark:text-white font-serif">
                {editingLog ? '编辑开发变更日志' : '新增开发变更日志'}
              </h4>
              <button onClick={() => setShowLogForm(false)} className="text-slate-400 hover:text-slate-900 dark:hover:text-white">✕</button>
            </div>

            <form onSubmit={handleSaveLog} className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-slate-600 dark:text-slate-300 block mb-1">版本号</label>
                  <input
                    type="text"
                    value={logVersion}
                    onChange={(e) => setLogVersion(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-1.5 text-xs text-slate-900 dark:text-slate-200 font-mono focus:outline-none focus:border-teal-500"
                    placeholder="如: v2.6.0"
                    required
                  />
                </div>

                <div>
                  <label className="text-xs text-slate-600 dark:text-slate-300 block mb-1">变更类型</label>
                  <select
                    value={logTag}
                    onChange={(e) => setLogTag(e.target.value as any)}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-1.5 text-xs text-slate-900 dark:text-slate-200 focus:outline-none focus:border-teal-500 font-mono"
                  >
                    <option value="[FEAT]">[FEAT] 新功能发布</option>
                    <option value="[DB]">[DB] 数据库/后端</option>
                    <option value="[UI]">[UI] 界面与体验</option>
                    <option value="[PERF]">[PERF] 性能优化</option>
                    <option value="[REFACTOR]">[REFACTOR] 代码重构</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs text-slate-600 dark:text-slate-300 block mb-1">日志标题 *</label>
                <input
                  type="text"
                  value={logTitle}
                  onChange={(e) => setLogTitle(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-1.5 text-xs text-slate-900 dark:text-slate-200 focus:outline-none focus:border-teal-500"
                  placeholder="如: 优化全站模版与标签分类样式"
                  required
                />
              </div>

              <div>
                <label className="text-xs text-slate-600 dark:text-slate-300 block mb-1">变更具体描述 *</label>
                <textarea
                  rows={3}
                  value={logContent}
                  onChange={(e) => setLogContent(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl p-3 text-xs text-slate-900 dark:text-slate-200 focus:outline-none focus:border-teal-500 resize-none font-serif"
                  placeholder="阐述本次更新的具体逻辑与工程变更..."
                  required
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowLogForm(false)}
                  className="px-3.5 py-1.5 rounded-xl text-xs font-mono text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-slate-800"
                >
                  取消
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-xl text-xs font-mono text-white bg-teal-600 hover:bg-teal-500 shadow"
                >
                  保存日志
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
