import React, { useState } from 'react';
import { Share2, Download, Copy, Check, Compass, Link as LinkIcon } from 'lucide-react';

interface ShareCardModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  quoteOrExcerpt: string;
  category?: string;
  date?: string;
}

export const ShareCardModal: React.FC<ShareCardModalProps> = ({
  isOpen,
  onClose,
  title,
  quoteOrExcerpt,
  category = '思绪潮汐',
  date = '2026.07.24',
}) => {
  const [copied, setCopied] = useState(false);
  const [themeStyle, setThemeStyle] = useState<'nebula' | 'deepsea' | 'twilight'>('nebula');

  if (!isOpen) return null;

  const cardTextToCopy = `🌌 【NebulaTide · 星云潮汐】\n\n“${quoteOrExcerpt}”\n\n— 选自 《${title}》 (${date})\n🔗 探索更多: https://cnb.cool/OrionDawn/NebulaTide`;

  const handleCopyText = () => {
    navigator.clipboard.writeText(cardTextToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const getThemeGradient = () => {
    switch (themeStyle) {
      case 'nebula':
        return 'from-slate-900 via-teal-950/90 to-indigo-950 border-teal-500/40 text-white';
      case 'deepsea':
        return 'from-slate-900 via-cyan-950/90 to-slate-950 border-cyan-500/40 text-white';
      case 'twilight':
        return 'from-slate-900 via-purple-950/80 to-indigo-950 border-purple-500/40 text-white';
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-900/40 dark:bg-slate-950/75 backdrop-blur-md sm:backdrop-blur-xl flex items-center justify-center p-3 sm:p-4 transition-all duration-200 animate-in fade-in overflow-y-auto"
      onClick={(e) => {
        e.stopPropagation();
        onClose();
      }}
    >
      <div
        className="bg-white dark:bg-slate-900/95 border border-slate-200 dark:border-slate-800/90 rounded-3xl max-w-lg w-full p-6 space-y-6 shadow-2xl relative animate-in zoom-in-95 duration-200 text-slate-900 dark:text-slate-100"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <Share2 className="w-4 h-4 text-teal-600 dark:text-teal-400" />
            <h3 className="text-base font-bold font-serif text-slate-900 dark:text-white">生成金句卡片与分享</h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-slate-900 dark:hover:text-white">✕</button>
        </div>

        {/* Theme Picker */}
        <div className="flex items-center justify-center gap-2 text-xs font-mono">
          <span className="text-slate-500 dark:text-slate-400">选择星图风格:</span>
          <button
            onClick={() => setThemeStyle('nebula')}
            className={`px-3 py-1 rounded-full border transition-all ${
              themeStyle === 'nebula' ? 'bg-teal-100 dark:bg-teal-950 border-teal-400 text-teal-800 dark:text-teal-300 font-semibold' : 'bg-slate-100 dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'
            }`}
          >
            🌌 星云特调
          </button>
          <button
            onClick={() => setThemeStyle('deepsea')}
            className={`px-3 py-1 rounded-full border transition-all ${
              themeStyle === 'deepsea' ? 'bg-cyan-100 dark:bg-cyan-950 border-cyan-400 text-cyan-800 dark:text-cyan-300 font-semibold' : 'bg-slate-100 dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'
            }`}
          >
            🌊 静谧海沟
          </button>
          <button
            onClick={() => setThemeStyle('twilight')}
            className={`px-3 py-1 rounded-full border transition-all ${
              themeStyle === 'twilight' ? 'bg-purple-100 dark:bg-purple-950 border-purple-400 text-purple-800 dark:text-purple-300 font-semibold' : 'bg-slate-100 dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'
            }`}
          >
            🔮 紫色余晖
          </button>
        </div>

        {/* Card Render Container */}
        <div className={`p-8 rounded-3xl border bg-gradient-to-br ${getThemeGradient()} shadow-2xl space-y-6 relative overflow-hidden`}>
          
          {/* Subtle Ambient Light */}
          <div className="absolute top-0 right-0 w-32 h-32 bg-teal-500/10 rounded-full blur-2xl pointer-events-none" />
          
          {/* Brand header */}
          <div className="flex items-center justify-between text-xs font-mono text-teal-300/80 pb-4 border-b border-slate-800/80">
            <span className="flex items-center gap-1.5 font-serif font-bold text-teal-200">
              <Compass className="w-4 h-4 text-teal-400" /> NebulaTide
            </span>
            <span className="bg-slate-950/80 px-2.5 py-0.5 rounded-full border border-teal-500/20 text-[10px]">
              {category} · {date}
            </span>
          </div>

          {/* Quote Body */}
          <div className="space-y-3">
            <span className="text-3xl font-serif text-teal-400/40 block leading-none">“</span>
            <p className="text-sm sm:text-base font-serif italic text-slate-100 leading-relaxed font-light px-2">
              {quoteOrExcerpt}
            </p>
            <span className="text-3xl font-serif text-teal-400/40 block text-right leading-none">”</span>
          </div>

          {/* Title and Author Footer */}
          <div className="pt-4 border-t border-slate-800/80 flex items-center justify-between">
            <div>
              <span className="text-xs font-bold font-serif text-teal-300 block">{title}</span>
              <span className="text-[10px] text-slate-400 font-mono block mt-0.5">作者: OrionDawn (Niu)</span>
            </div>
            
            {/* CNB QR/Link Badge */}
            <div className="p-2 rounded-xl bg-slate-950/90 border border-teal-500/30 text-center font-mono text-[9px] text-teal-300/80">
              <LinkIcon className="w-3.5 h-3.5 text-teal-400 mx-auto mb-0.5" />
              <span>cnb.cool/OrionDawn</span>
            </div>
          </div>

        </div>

        {/* Actions */}
        <div className="flex gap-3">
          <button
            onClick={handleCopyText}
            className="flex-1 py-2.5 rounded-xl text-xs font-semibold text-slate-700 dark:text-white bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 transition-all flex items-center justify-center gap-2 border border-slate-200 dark:border-slate-700"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? '已复制卡片文案' : '复制金句与卡片文案'}</span>
          </button>
          <button
            onClick={handleCopyText}
            className="flex-1 py-2.5 rounded-xl text-xs font-semibold text-white bg-teal-600 hover:bg-teal-500 transition-all flex items-center justify-center gap-2 shadow-md"
          >
            <Download className="w-4 h-4" />
            <span>保存/导出分享图</span>
          </button>
        </div>

      </div>
    </div>
  );
};
