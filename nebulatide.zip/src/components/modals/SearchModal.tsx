import React, { useState, useMemo } from 'react';
import { Search, X, BookOpen, Sparkles, FolderGit2, Compass, ArrowRight } from 'lucide-react';
import { Post, ThoughtFragment, ProjectItem, MindModel } from '../../types';
import { ModalOverlay } from '../common/ModalOverlay';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  posts: Post[];
  thoughts: ThoughtFragment[];
  projects: ProjectItem[];
  mindModels: MindModel[];
  setActiveTab: (tab: string) => void;
  onSelectPost?: (post: Post) => void;
}

type FilterCategory = 'all' | 'posts' | 'thoughts' | 'projects' | 'models';

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  posts,
  thoughts,
  projects,
  mindModels,
  setActiveTab,
  onSelectPost,
}) => {
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState<FilterCategory>('all');

  const filteredResults = useMemo(() => {
    const trimmed = (query || '').trim().toLowerCase();

    const postResults = (category === 'all' || category === 'posts')
      ? (Array.isArray(posts) ? posts : []).filter(
          (p) =>
            !p ? false :
            !trimmed ||
            (p.title && p.title.toLowerCase().includes(trimmed)) ||
            (p.excerpt && p.excerpt.toLowerCase().includes(trimmed)) ||
            (p.tags && Array.isArray(p.tags) && p.tags.some((t) => typeof t === 'string' && t.toLowerCase().includes(trimmed)))
        ).map((item) => ({ type: 'post' as const, item }))
      : [];

    const thoughtResults = (category === 'all' || category === 'thoughts')
      ? (Array.isArray(thoughts) ? thoughts : []).filter(
          (t) =>
            !t ? false :
            !trimmed ||
            (t.content && t.content.toLowerCase().includes(trimmed)) ||
            (t.moodTag && t.moodTag.toLowerCase().includes(trimmed))
        ).map((item) => ({ type: 'thought' as const, item }))
      : [];

    const projectResults = (category === 'all' || category === 'projects')
      ? (Array.isArray(projects) ? projects : []).filter(
          (p) =>
            !p ? false :
            !trimmed ||
            (p.title && p.title.toLowerCase().includes(trimmed)) ||
            (p.description && p.description.toLowerCase().includes(trimmed)) ||
            (p.tags && Array.isArray(p.tags) && p.tags.some((t) => typeof t === 'string' && t.toLowerCase().includes(trimmed)))
        ).map((item) => ({ type: 'project' as const, item }))
      : [];

    const modelResults = (category === 'all' || category === 'models')
      ? (Array.isArray(mindModels) ? mindModels : []).filter(
          (m) =>
            !m ? false :
            !trimmed ||
            (m.title && m.title.toLowerCase().includes(trimmed)) ||
            (m.description && m.description.toLowerCase().includes(trimmed)) ||
            (m.formula && m.formula.toLowerCase().includes(trimmed))
        ).map((item) => ({ type: 'model' as const, item }))
      : [];

    return [...postResults, ...thoughtResults, ...projectResults, ...modelResults];
  }, [query, category, posts, thoughts, projects, mindModels]);

  if (!isOpen) return null;

  return (
    <ModalOverlay isOpen={isOpen} onClose={onClose}>
      <div className="w-full max-w-2xl bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden my-4 sm:my-8 transition-all duration-300">
        {/* Header Search Input */}
        <div className="relative p-4 sm:p-5 border-b border-slate-100 dark:border-slate-800 flex items-center gap-3">
          <Search className="w-5 h-5 text-teal-600 dark:text-teal-400 shrink-0" />
          <input
            type="text"
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="搜索文章、火花碎片、项目工程或认知模型..."
            className="w-full text-sm sm:text-base bg-transparent border-none text-slate-800 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-0 font-sans"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              title="清空搜索"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title="关闭搜索"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Category Tabs */}
        <div className="px-4 sm:px-5 py-2.5 bg-slate-50/80 dark:bg-slate-900/50 border-b border-slate-100 dark:border-slate-800 flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          {[
            { id: 'all', label: '全部', icon: Search },
            { id: 'posts', label: '深邃长文', icon: BookOpen },
            { id: 'thoughts', label: '火花碎片', icon: Sparkles },
            { id: 'projects', label: '工程集锦', icon: FolderGit2 },
            { id: 'models', label: '认知模型', icon: Compass },
          ].map((cat) => {
            const Icon = cat.icon;
            const active = category === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setCategory(cat.id as FilterCategory)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-all ${
                  active
                    ? 'bg-teal-600 text-white shadow-sm dark:bg-teal-500'
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-200/60 dark:hover:bg-slate-800'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{cat.label}</span>
              </button>
            );
          })}
        </div>

        {/* Results Container */}
        <div className="max-h-[60vh] sm:max-h-[420px] overflow-y-auto p-4 sm:p-5 space-y-2.5 divide-y divide-slate-100 dark:divide-slate-800/60">
          {filteredResults.length === 0 ? (
            <div className="py-12 text-center text-slate-400 dark:text-slate-500">
              <Search className="w-8 h-8 mx-auto mb-2 opacity-40 text-slate-400" />
              <p className="text-sm">未找到与“{query}”匹配的内容</p>
            </div>
          ) : (
            filteredResults.map((res, index) => {
              if (res.type === 'post') {
                const post = res.item;
                return (
                  <div
                    key={`post-${post.id}-${index}`}
                    onClick={() => {
                      if (onSelectPost) onSelectPost(post);
                      setActiveTab('explore');
                      onClose();
                    }}
                    className="pt-2.5 first:pt-0 group cursor-pointer p-3 rounded-xl hover:bg-teal-50/50 dark:hover:bg-teal-950/20 transition-all border border-transparent hover:border-teal-500/20"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-teal-600 dark:text-teal-400 bg-teal-500/10 px-2 py-0.5 rounded-full">
                        <BookOpen className="w-3 h-3" /> 文章
                      </span>
                      <span className="text-[11px] text-slate-400">{post.date}</span>
                    </div>
                    <h4 className="text-sm font-semibold text-slate-800 dark:text-slate-100 group-hover:text-teal-600 dark:group-hover:text-teal-400 transition-colors flex items-center justify-between">
                      <span>{post.title}</span>
                      <ArrowRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity text-teal-500 shrink-0 ml-2" />
                    </h4>
                    <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2 mt-1">
                      {post.excerpt}
                    </p>
                  </div>
                );
              }

              if (res.type === 'thought') {
                const thought = res.item;
                return (
                  <div
                    key={`thought-${thought.id}-${index}`}
                    onClick={() => {
                      setActiveTab('fragments');
                      onClose();
                    }}
                    className="pt-2.5 first:pt-0 group cursor-pointer p-3 rounded-xl hover:bg-amber-50/50 dark:hover:bg-amber-950/20 transition-all border border-transparent hover:border-amber-500/20"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-amber-600 dark:text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-full">
                        <Sparkles className="w-3 h-3" /> 火花碎片 · {thought.moodTag}
                      </span>
                      <span className="text-[11px] text-slate-400">{thought.createdAt}</span>
                    </div>
                    <p className="text-xs text-slate-700 dark:text-slate-200 line-clamp-2 mt-1">
                      {thought.content}
                    </p>
                  </div>
                );
              }

              if (res.type === 'project') {
                const project = res.item;
                return (
                  <div
                    key={`project-${project.id}-${index}`}
                    onClick={() => {
                      setActiveTab('projects');
                      onClose();
                    }}
                    className="pt-2.5 first:pt-0 group cursor-pointer p-3 rounded-xl hover:bg-indigo-50/50 dark:hover:bg-indigo-950/20 transition-all border border-transparent hover:border-indigo-500/20"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-indigo-600 dark:text-indigo-400 bg-indigo-500/10 px-2 py-0.5 rounded-full">
                        <FolderGit2 className="w-3 h-3" /> 项目工程
                      </span>
                      <span className="text-[11px] text-slate-400">{project.period}</span>
                    </div>
                    <h4 className="text-sm font-semibold text-slate-800 dark:text-slate-100 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors flex items-center justify-between">
                      <span>{project.title}</span>
                      <ArrowRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity text-indigo-500 shrink-0 ml-2" />
                    </h4>
                    <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2 mt-1">
                      {project.description}
                    </p>
                  </div>
                );
              }

              if (res.type === 'model') {
                const model = res.item;
                return (
                  <div
                    key={`model-${model.title}-${index}`}
                    onClick={() => {
                      setActiveTab('explore');
                      onClose();
                    }}
                    className="pt-2.5 first:pt-0 group cursor-pointer p-3 rounded-xl hover:bg-emerald-50/50 dark:hover:bg-emerald-950/20 transition-all border border-transparent hover:border-emerald-500/20"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full">
                        <Compass className="w-3 h-3" /> 认知模型
                      </span>
                      <span className="text-[11px] font-mono text-emerald-600/80 dark:text-emerald-400/80">{model.formula}</span>
                    </div>
                    <h4 className="text-sm font-semibold text-slate-800 dark:text-slate-100 group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors flex items-center justify-between">
                      <span>{model.title}</span>
                      <ArrowRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity text-emerald-500 shrink-0 ml-2" />
                    </h4>
                    <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2 mt-1">
                      {model.description}
                    </p>
                  </div>
                );
              }

              return null;
            })
          )}
        </div>

        {/* Footer info */}
        <div className="p-3 px-5 bg-slate-50 dark:bg-slate-900/80 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
          <span>共找到 {filteredResults.length} 条检索结果</span>
          <span>多端自适应响应式弹窗卡片</span>
        </div>
      </div>
    </ModalOverlay>
  );
};
