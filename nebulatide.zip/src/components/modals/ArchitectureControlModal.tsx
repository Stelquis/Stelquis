import React, { useState, useEffect } from 'react';
import { ShieldCheck, Cpu, Layers, Activity, Zap, Server, RefreshCw, X, AlertTriangle, CheckCircle2, Sliders, Database, Network } from 'lucide-react';
import { systemHealthMonitor, ArchitectureMetrics } from '../../architecture/SystemHealthMonitor';
import { driverRegistry } from '../../architecture/DriverRegistry';
import { vfsService } from '../../services/vfsService';

interface ArchitectureControlModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ArchitectureControlModal: React.FC<ArchitectureControlModalProps> = ({ isOpen, onClose }) => {
  const [metrics, setMetrics] = useState<ArchitectureMetrics>(systemHealthMonitor.getMetrics());
  const [activeTab, setActiveTab] = useState<'ha' | 'hp' | 'extensibility'>('ha');
  const [isRefreshing, setIsRefreshing] = useState(false);

  useEffect(() => {
    if (!isOpen) return;
    const interval = setInterval(() => {
      setMetrics(systemHealthMonitor.getMetrics());
    }, 1000);
    return () => clearInterval(interval);
  }, [isOpen]);

  if (!isOpen) return null;

  const refreshMetrics = () => {
    setIsRefreshing(true);
    setMetrics(systemHealthMonitor.getMetrics());
    setTimeout(() => setIsRefreshing(false), 400);
  };

  const handleSwitchStorageDriver = (driverId: string) => {
    driverRegistry.setActiveStorageDriver(driverId);
    setMetrics(systemHealthMonitor.getMetrics());
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col animate-in zoom-in-95 duration-200 max-h-[90vh]"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20">
              <Server className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                分布式系统架构控制台
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-mono">
                High Availability, High Performance & Extensibility Engine
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={refreshMetrics}
              className={`p-2 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-500 hover:text-slate-900 dark:hover:text-white transition-all ${isRefreshing ? 'animate-spin' : ''}`}
              title="刷新实时指标"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Global Health Overview Bar */}
        <div className="px-6 py-3 border-b border-slate-200/80 dark:border-slate-800/80 bg-slate-100/40 dark:bg-slate-950/30 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-mono text-slate-500">综合健康分:</span>
              <span className="text-sm font-mono font-bold text-teal-600 dark:text-teal-400">
                {metrics.healthScore} / 100
              </span>
            </div>
            <span className="text-slate-300 dark:text-slate-700">•</span>
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-mono text-slate-500">HA 状态:</span>
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-bold ${
                metrics.haStatus === 'HEALTHY'
                  ? 'bg-teal-500/10 text-teal-600 dark:text-teal-400 border border-teal-500/20'
                  : 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20'
              }`}>
                {metrics.haStatus}
              </span>
            </div>
          </div>

          <div className="text-[11px] font-mono text-slate-400">
            运行时间: {metrics.uptimeSeconds}s
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="px-6 py-2.5 border-b border-slate-200/80 dark:border-slate-800/80 flex items-center gap-1 bg-slate-50/50 dark:bg-slate-950/20 font-mono text-xs">
          <button
            onClick={() => setActiveTab('ha')}
            className={`px-3.5 py-1.5 rounded-xl font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'ha'
                ? 'bg-teal-500/10 text-teal-600 dark:text-teal-400 border border-teal-500/30 shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>高可用 (HA & 断路器)</span>
          </button>

          <button
            onClick={() => setActiveTab('hp')}
            className={`px-3.5 py-1.5 rounded-xl font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'hp'
                ? 'bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/30 shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>高性能 (HP & LRU 缓存)</span>
          </button>

          <button
            onClick={() => setActiveTab('extensibility')}
            className={`px-3.5 py-1.5 rounded-xl font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'extensibility'
                ? 'bg-purple-500/10 text-purple-600 dark:text-purple-400 border border-purple-500/30 shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>可扩展 (Extensibility 驱动)</span>
          </button>
        </div>

        {/* Scrollable Content Body */}
        <div className="p-6 overflow-y-auto custom-scrollbar space-y-6 flex-1">
          {activeTab === 'ha' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-teal-500/5 dark:bg-teal-950/20 border border-teal-500/20 space-y-2">
                <h4 className="text-xs font-mono font-bold text-teal-600 dark:text-teal-400 flex items-center gap-1.5 uppercase">
                  <ShieldCheck className="w-4 h-4" />
                  <span>高可用容错机制与优雅降级策略</span>
                </h4>
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  系统集成了有限状态机 CircuitBreaker（CLOSED / OPEN / HALF_OPEN）。在网络抖动或后端挂掉时，会自动拦截并发故障并平滑降级至 LocalStorage 离线快照镜像，全站 0 崩塌风险。
                </p>
              </div>

              {/* Circuit Breakers Status List */}
              <div className="space-y-2">
                <label className="text-xs font-mono font-bold text-slate-500 uppercase">
                  注册的熔断断路器列表 (Circuit Breakers)
                </label>

                {metrics.circuitBreakers.map((cb) => (
                  <div
                    key={cb.name}
                    className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/40 flex items-center justify-between"
                  >
                    <div className="space-y-0.5">
                      <div className="text-xs font-bold text-slate-900 dark:text-white font-mono flex items-center gap-2">
                        <span>{cb.name}</span>
                        <span className="px-1.5 py-0.5 rounded text-[9px] font-mono bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                          Failure Threshold: 3
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-500 font-mono">
                        连续失败记录: {cb.failureCount} 次
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className={`px-2.5 py-1 rounded-xl text-xs font-mono font-bold flex items-center gap-1 ${
                        cb.state === 'CLOSED'
                          ? 'bg-teal-500/10 text-teal-600 dark:text-teal-400 border border-teal-500/30'
                          : 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/30'
                      }`}>
                        {cb.state === 'CLOSED' ? (
                          <CheckCircle2 className="w-3.5 h-3.5" />
                        ) : (
                          <AlertTriangle className="w-3.5 h-3.5" />
                        )}
                        <span>{cb.state}</span>
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'hp' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-indigo-500/5 dark:bg-indigo-950/20 border border-indigo-500/20 space-y-2">
                <h4 className="text-xs font-mono font-bold text-indigo-600 dark:text-indigo-400 flex items-center gap-1.5 uppercase">
                  <Zap className="w-4 h-4" />
                  <span>高性能 LRU 缓存 & 在途请求合并去重 (Request Coalescing)</span>
                </h4>
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  双向链表 + Hash Map O(1) 淘汰算法。内置在途请求去重池（Request Coalescing），当页面并发触发相同 VFS 读取请求时，全站自动合并为单一网络 IO，彻底解决缓存击穿问题。
                </p>
              </div>

              {/* HP Metrics Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 font-mono">
                <div className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/40">
                  <div className="text-[11px] text-slate-500">LRU 命中率 (Hit Rate)</div>
                  <div className="text-xl font-bold text-teal-600 dark:text-teal-400 mt-1">
                    {metrics.hpMetrics.hitRate}
                  </div>
                </div>

                <div className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/40">
                  <div className="text-[11px] text-slate-500">已合并并发请求 (Coalesced)</div>
                  <div className="text-xl font-bold text-indigo-600 dark:text-indigo-400 mt-1">
                    {metrics.hpMetrics.coalescedRequests} 次
                  </div>
                </div>

                <div className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/40">
                  <div className="text-[11px] text-slate-500">LRU 节点占用数 (Size)</div>
                  <div className="text-xl font-bold text-slate-900 dark:text-white mt-1">
                    {metrics.hpMetrics.cacheSize} / 200
                  </div>
                </div>
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  onClick={() => {
                    vfsService.clearCache();
                    refreshMetrics();
                  }}
                  className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-mono hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                >
                  手动清空 LRU 缓存
                </button>
              </div>
            </div>
          )}

          {activeTab === 'extensibility' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-purple-500/5 dark:bg-purple-950/20 border border-purple-500/20 space-y-2">
                <h4 className="text-xs font-mono font-bold text-purple-600 dark:text-purple-400 flex items-center gap-1.5 uppercase">
                  <Layers className="w-4 h-4" />
                  <span>驱动抽象层 (Driver Abstraction Architecture)</span>
                </h4>
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  底层屏蔽具体实现细节。存储引擎支持在 REST VFS Linux、IndexedDB、LocalStorage 或内存快照间随时热切换；AI 引擎支持第三方 Provider 灵活插件化拓展。
                </p>
              </div>

              {/* Storage Drivers Switcher */}
              <div className="space-y-2">
                <label className="text-xs font-mono font-bold text-slate-500 uppercase block">
                  存储驱动引擎插件 (Storage Driver Selection)
                </label>

                <div className="space-y-2">
                  {driverRegistry.getAllStorageDrivers().map((driver) => {
                    const isSelected = metrics.activeDrivers.storage === driver.name;
                    return (
                      <button
                        key={driver.id}
                        onClick={() => handleSwitchStorageDriver(driver.id)}
                        className={`w-full p-3.5 rounded-2xl border text-left transition-all flex items-center justify-between group ${
                          isSelected
                            ? 'border-purple-500 bg-purple-500/5 dark:bg-purple-950/30 ring-1 ring-purple-500/30'
                            : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-slate-50/50 dark:bg-slate-950/40'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div className="p-2 rounded-xl bg-purple-500/10 text-purple-500">
                            <Database className="w-4 h-4" />
                          </div>
                          <div>
                            <div className="text-xs font-bold text-slate-900 dark:text-white font-mono">
                              {driver.name}
                            </div>
                            <div className="text-[10px] text-slate-500 font-mono">
                              Type: {driver.type}
                            </div>
                          </div>
                        </div>

                        {isSelected ? (
                          <span className="px-2 py-1 rounded-lg text-[10px] font-mono font-bold bg-purple-600 text-white">
                            ACTIVE
                          </span>
                        ) : (
                          <span className="text-xs font-mono text-slate-400 group-hover:text-purple-500">
                            切换驱动
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Event Bus Status */}
              <div className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/40 flex items-center justify-between font-mono">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-900 dark:text-white">
                  <Network className="w-4 h-4 text-teal-500" />
                  <span>Event Bus 解耦通道</span>
                </div>
                <div className="text-xs font-bold text-teal-600 dark:text-teal-400">
                  {metrics.eventBusListenersCount} 个活跃监听事件类
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 flex items-center justify-between">
          <span className="text-[11px] font-mono text-slate-500">
            星云潮汐 · 分布式高可用与高性能驱动引擎 v2.5
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-indigo-600 text-white text-xs font-medium hover:bg-indigo-500 transition-colors shadow-sm font-mono"
          >
            完成关闭
          </button>
        </div>
      </div>
    </div>
  );
};
