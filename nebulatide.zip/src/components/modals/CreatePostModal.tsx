import React, { useState } from 'react';
import { Post } from '../../types';
import { X, Sparkles, Image, Tag, BookOpen, Send } from 'lucide-react';

interface CreatePostModalProps {
  onClose: () => void;
  onAddPost: (post: Omit<Post, 'id' | 'date' | 'likes'>) => void;
  categories?: string[];
}

export const CreatePostModal: React.FC<CreatePostModalProps> = ({
  onClose,
  onAddPost,
  categories = ['哲学宣言', '心智复盘', '潮汐随笔', '深度思考', '系统构建'],
}) => {
  const [title, setTitle] = useState('');
  const [subtitle, setSubtitle] = useState('');
  const [excerpt, setExcerpt] = useState('');
  const [content, setContent] = useState('');
  const [category, setCategory] = useState<string>('潮汐随笔');
  const [customCategory, setCustomCategory] = useState('');
  const [isCustomCategory, setIsCustomCategory] = useState(false);
  const [tagsInput, setTagsInput] = useState('NebulaTide, 深度思考');
  const [coverImage, setCoverImage] = useState(
    'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?q=80&w=1200&auto=format&fit=crop'
  );

  const presetCovers = [
    { label: '深空星云', url: 'https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?q=80&w=1200&auto=format&fit=crop' },
    { label: '静谧潮汐', url: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=1200&auto=format&fit=crop' },
    { label: '抽象微光', url: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?q=80&w=1200&auto=format&fit=crop' },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) return;

    const tags = tagsInput
      .split(/[,，]/)
      .map((t) => t.trim())
      .filter(Boolean);

    const finalCategory = isCustomCategory && customCategory.trim() ? customCategory.trim() : category;

    onAddPost({
      title: title.trim(),
      subtitle: subtitle.trim() || '源自 NebulaTide 潮汐思考',
      excerpt: excerpt.trim() || content.trim().slice(0, 100) + '...',
      content: content.trim(),
      category: finalCategory,
      tags: tags.length ? tags : ['NebulaTide'],
      readTime: `${Math.max(1, Math.ceil(content.length / 400))} 分钟`,
      coverImage,
      featured: false,
      author: {
        name: 'Stelquis',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=200&auto=format&fit=crop',
        role: 'NebulaTide 探索者',
      },
    });

    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-900/40 dark:bg-slate-950/75 backdrop-blur-md sm:backdrop-blur-xl flex items-center justify-center p-3 sm:p-4 transition-all duration-200 animate-in fade-in overflow-y-auto"
      onClick={(e) => {
        e.stopPropagation();
        onClose();
      }}
    >
      <div
        className="bg-white dark:bg-slate-900/95 border border-slate-200 dark:border-slate-800/90 rounded-3xl max-w-3xl w-full p-6 sm:p-8 space-y-6 shadow-2xl max-h-[92vh] overflow-y-auto custom-scrollbar animate-in zoom-in-95 duration-200 text-slate-900 dark:text-slate-100"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-teal-100 dark:bg-teal-500/10 text-teal-600 dark:text-teal-400">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white font-serif">撰写潮汐文章</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">沉淀深刻的逻辑与散文故事</p>
            </div>
          </div>
          <button id="close-post-modal" onClick={onClose} className="p-2 rounded-full text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-medium text-slate-700 dark:text-slate-300 block mb-1">文章标题 *</label>
              <input
                id="post-title-input"
                type="text"
                placeholder="例: 在星云深处重新认知注意力"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 dark:text-slate-200 focus:outline-none focus:border-teal-500"
                required
              />
            </div>

            <div>
              <label className="text-xs font-medium text-slate-700 dark:text-slate-300 block mb-1">副标题</label>
              <input
                id="post-subtitle-input"
                type="text"
                placeholder="例: 为什么我们总是太急着得出结论？"
                value={subtitle}
                onChange={(e) => setSubtitle(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 dark:text-slate-200 focus:outline-none focus:border-teal-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-medium text-slate-700 dark:text-slate-300">文章分类</label>
                <button
                  type="button"
                  onClick={() => setIsCustomCategory(!isCustomCategory)}
                  className="text-[10px] text-teal-600 dark:text-teal-400 hover:underline"
                >
                  {isCustomCategory ? '选择已有分类' : '+ 新增自定义分类'}
                </button>
              </div>
              {isCustomCategory ? (
                <input
                  type="text"
                  placeholder="输入新分类 (例: 前沿AI, 系统架构)"
                  value={customCategory}
                  onChange={(e) => setCustomCategory(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-teal-500/50 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 dark:text-slate-200 focus:outline-none"
                />
              ) : (
                <select
                  id="post-category-select"
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 dark:text-slate-200 focus:outline-none focus:border-teal-500"
                >
                  {categories.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              )}
            </div>

            <div>
              <label className="text-xs font-medium text-slate-700 dark:text-slate-300 block mb-1">标签 (逗号分隔)</label>
              <input
                id="post-tags-input"
                type="text"
                placeholder="NebulaTide, 深度思考, 潮汐复盘"
                value={tagsInput}
                onChange={(e) => setTagsInput(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 dark:text-slate-200 focus:outline-none focus:border-teal-500"
              />
            </div>
          </div>

          {/* Cover image preset selector */}
          <div>
            <label className="text-xs font-medium text-slate-700 dark:text-slate-300 block mb-1">封面图配图</label>
            <div className="flex flex-wrap gap-2 mb-2">
              {presetCovers.map((preset) => (
                <button
                  type="button"
                  key={preset.label}
                  onClick={() => setCoverImage(preset.url)}
                  className={`text-[11px] px-3 py-1 rounded-lg border transition-all ${
                    coverImage === preset.url
                      ? 'bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-300 border-teal-400 dark:border-teal-500/50 font-semibold'
                      : 'bg-slate-50 dark:bg-slate-950 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-800 hover:text-slate-900 dark:hover:text-slate-200'
                  }`}
                >
                  {preset.label}
                </button>
              ))}
            </div>
            <input
              id="post-cover-url"
              type="text"
              placeholder="或粘贴自定义 Image URL"
              value={coverImage}
              onChange={(e) => setCoverImage(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3.5 py-2 text-xs text-slate-800 dark:text-slate-300"
            />
          </div>

          {/* Content */}
          <div>
            <label className="text-xs font-medium text-slate-700 dark:text-slate-300 block mb-1">正文 Markdown 内容 *</label>
            <textarea
              id="post-content-input"
              rows={8}
              placeholder="在此编写文章正文... 支持 Markdown 语法 (标题 #, 列表 -, 引用 >, 粗体 **等)"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl p-4 text-xs text-slate-900 dark:text-slate-200 font-mono focus:outline-none focus:border-teal-500/80 resize-none"
              required
            />
          </div>

          <button
            id="publish-post-final-btn"
            type="submit"
            disabled={!title.trim() || !content.trim()}
            className="w-full py-3 rounded-xl text-xs font-semibold text-white bg-gradient-to-r from-teal-600 via-indigo-600 to-purple-600 hover:opacity-90 disabled:opacity-40 transition-all shadow-lg flex items-center justify-center gap-2"
          >
            <Send className="w-4 h-4" />
            <span>发布至 NebulaTide 博客</span>
          </button>
        </form>
      </div>
    </div>
  );
};
