import React, { useState } from 'react';
import { ProjectItem } from '../../types';
import { X, Sparkles, FolderGit2, Plus, Trash2, Send, Cpu, Layers, Code2, Check, Wand2 } from 'lucide-react';

interface CreateProjectModalProps {
  onClose: () => void;
  onAddProject: (project: ProjectItem) => void;
  existingProject?: ProjectItem | null;
  onUpdateProject?: (project: ProjectItem) => void;
}

// Preset Templates for Quick Creation
const PROJECT_TEMPLATES = [
  {
    name: '🤖 AI Agent / 大模型框架模版',
    title: 'NexusAgent：多模态分层推理与工具联动引擎',
    subtitle: '基于 ReAct 模式与向量数据库的生产级 CAD/图纸智能协同系统',
    category: 'AI Agent',
    period: '2026.06 - 至今',
    description: '针对复杂工业 CAD 与多模态图纸的语义理解与智能问答，基于向量索引（Chroma/FAISS）与 LLM 混合编排，实现百毫秒级精准特征提取与工具自动化调用。',
    highlights: [
      '设计双层记忆池机制，上下文召回准确率提升 +18.4%',
      '封装 12+ 工业级 CAD 图层解析 Plugin，实现端到端闭环',
      '支持多 Agent 协同与思考过程透明化 Web 实时可视化'
    ],
    tags: ['Python', 'LangChain', 'FastAPI', 'ChromaDB', 'React'],
    repoUrl: 'https://github.com/stelquis/nexus-agent-cad',
    iconName: 'robot',
    philosophicalLink: '机器是肉身的延伸，Agent 是思绪的降熵放大器。'
  },
  {
    name: '📊 可视化与数据分析模版',
    title: 'CosmicGraph：大规模复杂关联图谱交互探索平台',
    subtitle: '基于 WebGL 与 Force-Directed 物理引擎的十万级节点实时渲染',
    category: '可视化分析',
    period: '2026.04 - 2026.06',
    description: '解决大规模社会关系网络与知识图谱在前端卡顿的痛点，采用 Web Worker 异步物理计算与 Custom Shader 渲染，实现 60 FPS 流畅缩放与群体演化探索。',
    highlights: [
      '重构物理力导向算法，大规模图计算性能提升 +320%',
      '支持基于社群发现算法（Louvain）的动态聚类高亮',
      '在 ChinaVis 2026 展示并获得学术界关注'
    ],
    tags: ['TypeScript', 'WebGL', 'Three.js', 'D3.js', 'Rust'],
    repoUrl: 'https://github.com/stelquis/cosmic-graph-vis',
    iconName: 'theater',
    philosophicalLink: '散沙般的点线，经过算法交织成恢弘星图。'
  },
  {
    name: '☁️ 云原生与高并发系统模版',
    title: 'NebulaRPC：高吞吐低延迟分布式微服务网关',
    subtitle: '基于 Rust/Tokio 的云原生零拷贝协议栈与自适应限流引擎',
    category: '系统&安全',
    period: '2026.01 - 2026.03',
    description: '针对超大规模高并发服务调用的网关瓶颈，基于 Rust 编写零拷贝 HTTP/3 & gRPC 协议转换层，具备毫秒级熔断与动态权重负载均衡能力。',
    highlights: [
      '单机 QPS 突破 120,000，内存占用仅 18MB',
      '引入 BBR 拥塞控制思想的自适应限流算法，彻底杜绝雪崩',
      '完全兼容 Kubernetes CRD 与 Envoy Filter 规范'
    ],
    tags: ['Rust', 'Tokio', 'gRPC', 'Kubernetes', 'Docker'],
    repoUrl: 'https://github.com/stelquis/nebula-rpc-gateway',
    iconName: 'robot',
    philosophicalLink: '高并发如滚滚潮水，唯有精密的闸门能化混沌为动能。'
  },
  {
    name: '🧬 生物信息与深度图模型模版',
    title: 'BioGraphNet：蛋白质相互作用网络与小分子对接预测',
    subtitle: '基于 图神经网络 (GNN) 与 SE(3)-Equivariant 几何等变架构',
    category: '生物信息',
    period: '2025.09 - 2025.12',
    description: '针对复杂大分子三维几何拓扑性质，构建几何等变神经网络（Equivariant GNN），高效预测受体-配体结合亲和力（Kd）与异构位点。',
    highlights: [
      '在 PDBbind Benchmark 数据集中 MSE 降低 14.2%',
      '实现分布式 PyTorch Geometric 训练流水线',
      '结合 WebGL 3D 渲染蛋白口袋分子结构'
    ],
    tags: ['Python', 'PyTorch', 'PyG', 'RDKit', 'Next.js'],
    repoUrl: 'https://github.com/stelquis/biograph-net-docking',
    iconName: 'gene',
    philosophicalLink: '在无序的氨基酸长链中，拓扑形态孕育着生命的秩序。'
  }
];

export const CreateProjectModal: React.FC<CreateProjectModalProps> = ({
  onClose,
  onAddProject,
  existingProject,
  onUpdateProject,
}) => {
  const isEditing = !!existingProject;

  const [title, setTitle] = useState(existingProject?.title || '');
  const [subtitle, setSubtitle] = useState(existingProject?.subtitle || '');
  const [category, setCategory] = useState(existingProject?.category || 'AI Agent');
  const [customCategory, setCustomCategory] = useState('');
  const [isCustomCategory, setIsCustomCategory] = useState(false);

  const [period, setPeriod] = useState(existingProject?.period || '2026.06 - 至今');
  const [description, setDescription] = useState(existingProject?.description || '');
  
  const [highlightInput, setHighlightInput] = useState('');
  const [highlights, setHighlights] = useState<string[]>(existingProject?.highlights || []);

  const [tagsInput, setTagsInput] = useState(existingProject?.tags.join(', ') || '');
  const [repoUrl, setRepoUrl] = useState(existingProject?.repoUrl || 'https://github.com/stelquis/');
  const [iconName, setIconName] = useState<ProjectItem['iconName']>(existingProject?.iconName || 'robot');
  const [philosophicalLink, setPhilosophicalLink] = useState(
    existingProject?.philosophicalLink || '第一性原理的火花，交织成漫天星图。'
  );

  const handleApplyTemplate = (tmpl: typeof PROJECT_TEMPLATES[0]) => {
    setTitle(tmpl.title);
    setSubtitle(tmpl.subtitle);
    setCategory(tmpl.category);
    setIsCustomCategory(false);
    setPeriod(tmpl.period);
    setDescription(tmpl.description);
    setHighlights(tmpl.highlights);
    setTagsInput(tmpl.tags.join(', '));
    setRepoUrl(tmpl.repoUrl);
    setIconName(tmpl.iconName as ProjectItem['iconName']);
    setPhilosophicalLink(tmpl.philosophicalLink);
  };

  const handleAddHighlight = () => {
    if (highlightInput.trim()) {
      setHighlights([...highlights, highlightInput.trim()]);
      setHighlightInput('');
    }
  };

  const handleRemoveHighlight = (index: number) => {
    setHighlights(highlights.filter((_, i) => i !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !description.trim()) return;

    const finalCategory = isCustomCategory && customCategory.trim() ? customCategory.trim() : category;
    const tagsArray = tagsInput
      .split(/[,，]/)
      .map((t) => t.trim())
      .filter((t) => t.length > 0);

    const projectData: ProjectItem = {
      id: existingProject ? existingProject.id : `proj-${Date.now()}`,
      title: title.trim(),
      subtitle: subtitle.trim() || '工程项目与第一性原理探索',
      category: finalCategory,
      period: period.trim() || '至今',
      description: description.trim(),
      highlights: highlights.length > 0 ? highlights : ['构建了完善的流水线', '提升了架构健壮性'],
      tags: tagsArray.length > 0 ? tagsArray : ['React', 'TypeScript', 'AI'],
      repoUrl: repoUrl.trim() || 'https://github.com/stelquis/',
      iconName,
      philosophicalLink: philosophicalLink.trim() || '在技术演进中寻觅第一性原理。',
    };

    if (isEditing && onUpdateProject) {
      onUpdateProject(projectData);
    } else {
      onAddProject(projectData);
    }

    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/40 dark:bg-slate-950/75 backdrop-blur-md sm:backdrop-blur-xl animate-fadeIn overflow-y-auto"
      onClick={(e) => {
        e.stopPropagation();
        onClose();
      }}
    >
      <div
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-3xl w-full p-6 sm:p-8 space-y-6 relative shadow-2xl overflow-y-auto max-h-[92vh] custom-scrollbar text-slate-900 dark:text-slate-100"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <FolderGit2 className="w-5 h-5 text-teal-600 dark:text-teal-400" />
            <h2 className="text-xl font-bold font-serif text-slate-900 dark:text-white">
              {isEditing ? '编辑工程项目卡片' : '入驻新硬核工程项目'}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Templates Strip */}
        {!isEditing && (
          <div className="bg-slate-50 dark:bg-slate-950/80 border border-slate-200 dark:border-slate-800/80 rounded-2xl p-4 space-y-3">
            <div className="flex items-center gap-1.5 text-xs font-mono text-teal-700 dark:text-teal-300 font-semibold">
              <Wand2 className="w-4 h-4 text-teal-600 dark:text-teal-400" />
              <span>一键填充项目模版 (Quick Templates):</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {PROJECT_TEMPLATES.map((tmpl) => (
                <button
                  type="button"
                  key={tmpl.name}
                  onClick={() => handleApplyTemplate(tmpl)}
                  className="text-left p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-teal-500/50 hover:bg-slate-100 dark:hover:bg-slate-800/60 transition-all text-xs group shadow-sm"
                >
                  <div className="font-semibold text-slate-800 dark:text-slate-200 group-hover:text-teal-600 dark:group-hover:text-teal-300 flex items-center justify-between">
                    <span>{tmpl.name}</span>
                    <Sparkles className="w-3 h-3 text-teal-500 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate mt-0.5">{tmpl.title}</div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-medium text-slate-700 dark:text-slate-300 block mb-1">项目名称 *</label>
              <input
                type="text"
                placeholder="例如: StarEngine 算法引擎"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 dark:text-slate-200 focus:outline-none focus:border-teal-500 font-serif"
                required
              />
            </div>

            <div>
              <label className="text-xs font-medium text-slate-700 dark:text-slate-300 block mb-1">副标题 / 核心定位</label>
              <input
                type="text"
                placeholder="例如: 基于多模态 AI 的工业图纸分析平台"
                value={subtitle}
                onChange={(e) => setSubtitle(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 dark:text-slate-200 focus:outline-none focus:border-teal-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {/* Category selection & Custom input */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-medium text-slate-700 dark:text-slate-300">项目类别</label>
                <button
                  type="button"
                  onClick={() => setIsCustomCategory(!isCustomCategory)}
                  className="text-[10px] text-teal-600 dark:text-teal-400 hover:underline"
                >
                  {isCustomCategory ? '选择预设' : '+ 自定义类别'}
                </button>
              </div>

              {isCustomCategory ? (
                <input
                  type="text"
                  placeholder="例如: 边缘计算/量子计算"
                  value={customCategory}
                  onChange={(e) => setCustomCategory(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-teal-500/60 rounded-xl px-3.5 py-2 text-xs text-slate-900 dark:text-slate-200 focus:outline-none"
                />
              ) : (
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3.5 py-2 text-xs text-slate-900 dark:text-slate-200 focus:outline-none"
                >
                  <option value="AI Agent">AI Agent</option>
                  <option value="可视化分析">可视化分析</option>
                  <option value="算法&网络">算法&网络</option>
                  <option value="系统&安全">系统&安全</option>
                  <option value="分布式&爬虫">分布式&爬虫</option>
                  <option value="生物信息">生物信息</option>
                </select>
              )}
            </div>

            <div>
              <label className="text-xs font-medium text-slate-700 dark:text-slate-300 block mb-1">时间周期</label>
              <input
                type="text"
                placeholder="例如: 2026.05 - 至今"
                value={period}
                onChange={(e) => setPeriod(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3.5 py-2 text-xs text-slate-900 dark:text-slate-200 focus:outline-none focus:border-teal-500"
              />
            </div>

            <div>
              <label className="text-xs font-medium text-slate-700 dark:text-slate-300 block mb-1">标识图标</label>
              <select
                value={iconName}
                onChange={(e) => setIconName(e.target.value as ProjectItem['iconName'])}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3.5 py-2 text-xs text-slate-900 dark:text-slate-200 focus:outline-none"
              >
                <option value="robot">🤖 机器人 / AI Agent</option>
                <option value="theater">🎭 京剧 / 可视化</option>
                <option value="video">📹 同传 / 音视频</option>
                <option value="brain">🧠 算法 / 神经网络</option>
                <option value="spider">🕷️ 爬虫 / 分布式</option>
                <option value="gene">🧬 生物信息 / 基因图谱</option>
                <option value="bird">✨ 智能 / 闪耀</option>
              </select>
            </div>
          </div>

          <div>
            <label className="text-xs font-medium text-slate-700 dark:text-slate-300 block mb-1">项目核心描述 *</label>
            <textarea
              rows={3}
              placeholder="详细阐述项目背景、解决的痛点、架构设计思路以及第一性原理的应用..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl p-3.5 text-xs text-slate-900 dark:text-slate-200 focus:outline-none focus:border-teal-500 font-light resize-none"
              required
            />
          </div>

          {/* Highlights */}
          <div className="space-y-2">
            <label className="text-xs font-medium text-slate-700 dark:text-slate-300 block">成果亮点与突破数据</label>
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="例如: 算法召回率提升 +24.5%..."
                value={highlightInput}
                onChange={(e) => setHighlightInput(e.target.value)}
                className="flex-1 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3.5 py-2 text-xs text-slate-900 dark:text-slate-200 focus:outline-none focus:border-teal-500"
              />
              <button
                type="button"
                onClick={handleAddHighlight}
                className="px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-semibold text-xs transition-colors"
              >
                + 添加
              </button>
            </div>

            {highlights.length > 0 && (
              <div className="space-y-1.5 pt-1">
                {highlights.map((h, i) => (
                  <div key={i} className="flex items-center justify-between p-2 rounded-xl bg-slate-100 dark:bg-slate-950 text-xs border border-slate-200 dark:border-slate-800">
                    <span className="text-teal-700 dark:text-teal-300 flex items-center gap-1.5">
                      <Check className="w-3.5 h-3.5 text-teal-500" />
                      {h}
                    </span>
                    <button
                      type="button"
                      onClick={() => handleRemoveHighlight(i)}
                      className="text-slate-400 hover:text-rose-500 p-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-medium text-slate-700 dark:text-slate-300 block mb-1">技术栈标签 (逗号分隔)</label>
              <input
                type="text"
                placeholder="例如: Python, LangChain, PyTorch, React"
                value={tagsInput}
                onChange={(e) => setTagsInput(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3.5 py-2 text-xs text-slate-900 dark:text-slate-200 focus:outline-none focus:border-teal-500 font-mono"
              />
            </div>

            <div>
              <label className="text-xs font-medium text-slate-700 dark:text-slate-300 block mb-1">CNB / 源码仓库 URL</label>
              <input
                type="url"
                placeholder="https://cnb.cool/..."
                value={repoUrl}
                onChange={(e) => setRepoUrl(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3.5 py-2 text-xs text-slate-900 dark:text-slate-200 focus:outline-none focus:border-teal-500 font-mono"
              />
            </div>
          </div>

          <div>
            <label className="text-xs font-medium text-slate-700 dark:text-slate-300 block mb-1">🌊 NebulaTide 哲学印记</label>
            <input
              type="text"
              placeholder="例如: 散沙般的点线，经过算法交织成恢弘星图。"
              value={philosophicalLink}
              onChange={(e) => setPhilosophicalLink(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3.5 py-2 text-xs text-slate-900 dark:text-slate-200 focus:outline-none focus:border-teal-500 italic"
            />
          </div>

          {/* Submit */}
          <div className="pt-4 border-t border-slate-200 dark:border-slate-800 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 rounded-xl text-xs font-medium text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
            >
              取消
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl text-xs font-semibold text-white bg-gradient-to-r from-teal-600 to-indigo-600 hover:from-teal-500 hover:to-indigo-500 transition-all shadow-md flex items-center gap-1.5"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{isEditing ? '保存项目修改' : '立即入驻星云工程卡片'}</span>
            </button>
          </div>
        </form>

      </div>
    </div>
  );
};
