import React, { useState } from 'react';
import { Sparkles, Bot, RefreshCw, Copy, Check, Wand2, Tag, Compass, FileText, ArrowRight } from 'lucide-react';

interface AiAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialText?: string;
  onApplyText?: (text: string) => void;
}

export const AiAssistantModal: React.FC<AiAssistantModalProps> = ({
  isOpen,
  onClose,
  initialText = '',
  onApplyText,
}) => {
  const [inputContent, setInputContent] = useState(initialText);
  const [outputContent, setOutputContent] = useState('');
  const [activeTask, setActiveTask] = useState<'polish' | 'continue' | 'tags' | 'tide'>('polish');
  const [isLoading, setIsLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [generatedTags, setGeneratedTags] = useState<string[]>([]);
  const [perceivedTide, setPerceivedTide] = useState<{ energy: string; advice: string } | null>(null);

  if (!isOpen) return null;

  const handleProcessAi = (task: 'polish' | 'continue' | 'tags' | 'tide') => {
    setActiveTask(task);
    setIsLoading(true);
    setOutputContent('');
    setPerceivedTide(null);

    setTimeout(() => {
      setIsLoading(false);

      const text = inputContent.trim() || '混沌是创造的温床，我们不必急于在黑暗中开灯，而是让雾气停留一会儿。';

      if (task === 'polish') {
        setOutputContent(
          `【降熵与修辞润色】\n` +
          `“${text}”\n\n` +
          `✨ 优化语段：\n` +
          `“思绪在初始时弥漫无界，犹如浩瀚星云。不必急于厘清方向，混沌本就是灵感最原初的温床。退后一步，静候浪潮流向自然显影。”`
        );
      } else if (task === 'continue') {
        setOutputContent(
          `【 NebulaTide 哲学推演续写】\n` +
          `基于先前内容：“${text}”\n\n` +
          `🌊 续写流向：\n` +
          `“正如潮汐会在暗夜里静静涌向沙滩，所有的思绪也将在退潮的刻度里重新凝聚。当贝壳在湿润的沙滩上闪烁，我们终会发现，规划从来不是机械的考核，而是顺应内心能量起伏的优雅编织。下一次涨潮时，尽情奔涌；退潮时，安心归航。”`
        );
      } else if (task === 'tags') {
        const tags = ['#混沌与潮汐', '#心智降熵', '#顺势织网', '#思考深度', '#第一性原理', '#自我复盘'];
        setGeneratedTags(tags);
        setOutputContent(`🏷️ 已为你智能提炼 6 个契合星云潮汐主题的关键词标签：\n${tags.join(' ')}`);
      } else if (task === 'tide') {
        setPerceivedTide({
          energy: '🌊 高能涨潮 (High Tide Flow)',
          advice: '当前表达蕴含极强的探索欲望与碰撞动能。建议保持此状态，直接将想法投射为具体的工程原型或第一阶段创作。',
        });
        setOutputContent(`🧭 心智潮汐能级感测成功。你当前的思绪能量处于 【高能涨潮】 阶段。`);
      }
    }, 1200);
  };

  const handleCopy = () => {
    if (!outputContent) return;
    navigator.clipboard.writeText(outputContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-900/40 dark:bg-slate-950/75 backdrop-blur-md sm:backdrop-blur-xl flex items-center justify-center p-3 sm:p-4 animate-fadeIn overflow-y-auto"
      onClick={(e) => {
        e.stopPropagation();
        onClose();
      }}
    >
      <div
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-2xl w-full p-6 sm:p-8 space-y-6 relative shadow-2xl overflow-y-auto max-h-[90vh] custom-scrollbar text-slate-900 dark:text-slate-100"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-teal-100 dark:bg-teal-950/80 border border-teal-300 dark:border-teal-500/30">
              <Bot className="w-5 h-5 text-teal-600 dark:text-teal-400" />
            </div>
            <div>
              <h2 className="text-lg font-bold font-serif text-slate-900 dark:text-white flex items-center gap-2">
                <span>AI 降熵助手 (Nebula AI Agent)</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-300 border border-teal-300 dark:border-teal-500/30">
                  v2.5 DeepSeek & Gemini
                </span>
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-light">
                针对文字与思考提炼的语言降熵引擎，辅助润色、续写与主题标记
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-900 dark:hover:text-white p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Input TextArea */}
        <div className="space-y-2">
          <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center justify-between">
            <span>输入需降熵与加工的原始文本：</span>
            <span className="text-[11px] text-slate-400 font-mono">{inputContent.length} 字</span>
          </label>
          <textarea
            rows={3}
            placeholder="贴入任何未经整理的段落、日记随想或代码想法..."
            value={inputContent}
            onChange={(e) => setInputContent(e.target.value)}
            className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl p-3.5 text-xs text-slate-900 dark:text-slate-200 focus:outline-none focus:border-teal-500 font-light resize-none shadow-inner"
          />
        </div>

        {/* Task Buttons */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          <button
            onClick={() => handleProcessAi('polish')}
            className={`p-3 rounded-2xl border text-xs font-medium transition-all flex flex-col items-center justify-center gap-1.5 ${
              activeTask === 'polish'
                ? 'bg-teal-100 dark:bg-teal-950/80 border-teal-400 text-teal-800 dark:text-teal-300 font-semibold shadow-sm'
                : 'bg-slate-50 dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            <Wand2 className="w-4 h-4 text-teal-600 dark:text-teal-400" />
            <span>表达降熵润色</span>
          </button>

          <button
            onClick={() => handleProcessAi('continue')}
            className={`p-3 rounded-2xl border text-xs font-medium transition-all flex flex-col items-center justify-center gap-1.5 ${
              activeTask === 'continue'
                ? 'bg-indigo-100 dark:bg-indigo-950/80 border-indigo-400 text-indigo-800 dark:text-indigo-300 font-semibold shadow-sm'
                : 'bg-slate-50 dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            <Sparkles className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
            <span>哲学深度续写</span>
          </button>

          <button
            onClick={() => handleProcessAi('tags')}
            className={`p-3 rounded-2xl border text-xs font-medium transition-all flex flex-col items-center justify-center gap-1.5 ${
              activeTask === 'tags'
                ? 'bg-purple-100 dark:bg-purple-950/80 border-purple-400 text-purple-800 dark:text-purple-300 font-semibold shadow-sm'
                : 'bg-slate-50 dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            <Tag className="w-4 h-4 text-purple-600 dark:text-purple-400" />
            <span>智能标签提炼</span>
          </button>

          <button
            onClick={() => handleProcessAi('tide')}
            className={`p-3 rounded-2xl border text-xs font-medium transition-all flex flex-col items-center justify-center gap-1.5 ${
              activeTask === 'tide'
                ? 'bg-amber-100 dark:bg-amber-950/80 border-amber-400 text-amber-800 dark:text-amber-300 font-semibold shadow-sm'
                : 'bg-slate-50 dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            <Compass className="w-4 h-4 text-amber-600 dark:text-amber-400" />
            <span>心智潮汐感测</span>
          </button>
        </div>

        {/* AI Output Area */}
        <div className="space-y-3 pt-2 border-t border-slate-200 dark:border-slate-800">
          <div className="flex items-center justify-between text-xs font-semibold text-teal-700 dark:text-teal-300">
            <span className="flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-teal-600 dark:text-teal-400" />
              <span>AI Agent 生成与推演结果：</span>
            </span>
            {outputContent && (
              <button
                onClick={handleCopy}
                className="flex items-center gap-1 text-slate-500 hover:text-teal-600 dark:hover:text-teal-300 transition-colors"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? '已复制' : '复制成果'}</span>
              </button>
            )}
          </div>

          <div className="bg-slate-50 dark:bg-slate-950/80 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 min-h-[140px] text-xs font-serif leading-relaxed text-slate-800 dark:text-slate-200 relative">
            {isLoading ? (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 bg-white/60 dark:bg-slate-950/60 rounded-2xl backdrop-blur-sm">
                <RefreshCw className="w-6 h-6 text-teal-600 dark:text-teal-400 animate-spin" />
                <span className="text-xs font-mono text-teal-700 dark:text-teal-300">AI Agent 正在调配神经元推演...</span>
              </div>
            ) : outputContent ? (
              <div className="space-y-3 whitespace-pre-line">
                <p>{outputContent}</p>

                {perceivedTide && (
                  <div className="p-3 bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-500/30 rounded-xl space-y-1 mt-2">
                    <span className="font-bold text-amber-800 dark:text-amber-300 font-mono block">{perceivedTide.energy}</span>
                    <p className="text-slate-700 dark:text-slate-300 font-sans">{perceivedTide.advice}</p>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-slate-400 dark:text-slate-500 text-center py-10 font-sans">
                点击上方任意指令按钮，开启 AI 智能处理
              </div>
            )}
          </div>
        </div>

        {/* Apply Action Footer */}
        {outputContent && onApplyText && (
          <div className="pt-2 flex justify-end">
            <button
              onClick={() => {
                onApplyText(outputContent);
                onClose();
              }}
              className="px-5 py-2.5 rounded-xl text-xs font-semibold text-white bg-gradient-to-r from-teal-600 to-indigo-600 hover:from-teal-500 hover:to-indigo-500 transition-all shadow-md flex items-center gap-1.5"
            >
              <span>采纳并应用到文本输入框</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
