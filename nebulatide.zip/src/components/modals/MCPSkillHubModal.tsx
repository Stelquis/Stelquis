import React, { useState, useEffect } from "react";
import {
  Cpu,
  Puzzle,
  Terminal,
  Zap,
  CheckCircle2,
  XCircle,
  Play,
  X,
  Sparkles,
  BookOpen,
  Layers,
  Code2,
  Check,
  ToggleLeft,
  ToggleRight
} from "lucide-react";
import { mcpSkillService, MCPSchema, AgentSkill } from "../../services/mcpSkillService";

interface MCPSkillHubModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const MCPSkillHubModal: React.FC<MCPSkillHubModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<"skills" | "mcp-tools" | "mcp-resources">("skills");
  const [mcpSchema, setMcpSchema] = useState<MCPSchema | null>(null);
  const [skills, setSkills] = useState<AgentSkill[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedTool, setSelectedTool] = useState<string>("");
  const [testToolArgs, setTestToolArgs] = useState<string>("{}");
  const [testResult, setTestResult] = useState<string | null>(null);
  const [executingTool, setExecutingTool] = useState(false);

  useEffect(() => {
    if (isOpen) {
      loadData();
    }
  }, [isOpen]);

  const loadData = async () => {
    setLoading(true);
    try {
      const [schemaRes, skillsRes] = await Promise.all([
        mcpSkillService.getMCPSchema(),
        mcpSkillService.getSkills()
      ]);
      setMcpSchema(schemaRes);
      setSkills(skillsRes.skills);
      if (schemaRes.tools.length > 0) {
        setSelectedTool(schemaRes.tools[0].name);
      }
    } catch (err: any) {
      console.error("Load MCP/Skills data failed:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleToggleSkill = async (id: string) => {
    try {
      const res = await mcpSkillService.toggleSkill(id);
      if (res.success) {
        setSkills(prev => prev.map(s => (s.id === id ? res.skill : s)));
      }
    } catch (err) {
      console.error("Toggle skill error:", err);
    }
  };

  const handleRunMCPTool = async () => {
    if (!selectedTool) return;
    setExecutingTool(true);
    setTestResult(null);

    try {
      let parsedArgs = {};
      try {
        parsedArgs = JSON.parse(testToolArgs);
      } catch (e) {
        setTestResult("❌ JSON 参数解析语法错误，请检查输入的对象语法");
        setExecutingTool(false);
        return;
      }

      const res = await mcpSkillService.callMCPTool(selectedTool, parsedArgs);
      setTestResult(JSON.stringify(res, null, 2));
    } catch (err: any) {
      setTestResult(`❌ MCP Tool 执行报错: ${err.message}`);
    } finally {
      setExecutingTool(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-slate-950/70 backdrop-blur-md animate-in fade-in duration-200">
      <div
        onClick={e => e.stopPropagation()}
        className="w-full max-w-5xl h-[85vh] bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col animate-in zoom-in-95 duration-200"
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-teal-500/10 text-teal-600 dark:text-teal-400 border border-teal-500/20">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  MCP 协议桥接层 & 动态 Skill 插件中心
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-teal-500/10 text-teal-600 dark:text-teal-300 border border-teal-500/20">
                  Model Context Protocol v2024-11-05
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                将全栈 VFS 数据库与工具封装为 MCP 标准 schema，同时支持 SKILL.md 动态技能约束挂载
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 px-6 border-b border-slate-200 dark:border-slate-800 bg-slate-100/50 dark:bg-slate-950/40">
          <button
            onClick={() => setActiveTab("skills")}
            className={`px-4 py-3 text-xs font-bold border-b-2 flex items-center gap-2 transition-all ${
              activeTab === "skills"
                ? "border-teal-500 text-teal-600 dark:text-teal-400"
                : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
            }`}
          >
            <Puzzle className="w-4 h-4" />
            <span>动态 Skill 插件库 ({skills.length})</span>
          </button>

          <button
            onClick={() => setActiveTab("mcp-tools")}
            className={`px-4 py-3 text-xs font-bold border-b-2 flex items-center gap-2 transition-all ${
              activeTab === "mcp-tools"
                ? "border-teal-500 text-teal-600 dark:text-teal-400"
                : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
            }`}
          >
            <Terminal className="w-4 h-4" />
            <span>MCP Standard Tools ({mcpSchema?.tools.length || 0})</span>
          </button>

          <button
            onClick={() => setActiveTab("mcp-resources")}
            className={`px-4 py-3 text-xs font-bold border-b-2 flex items-center gap-2 transition-all ${
              activeTab === "mcp-resources"
                ? "border-teal-500 text-teal-600 dark:text-teal-400"
                : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>MCP Standard Resources ({mcpSchema?.resources.length || 0})</span>
          </button>
        </div>

        {/* Main Tab Content */}
        <div className="flex-1 min-h-0 overflow-y-auto p-6 custom-scrollbar bg-white dark:bg-slate-900">
          {loading ? (
            <div className="py-20 text-center text-xs text-slate-400">正在加载 MCP 架构 Schema...</div>
          ) : activeTab === "skills" ? (
            /* TAB 1: Dynamic Skills */
            <div className="space-y-4">
              <div className="p-3.5 rounded-xl bg-teal-500/10 border border-teal-500/20 text-xs text-teal-900 dark:text-teal-200 flex items-start gap-2.5">
                <Sparkles className="w-4 h-4 text-teal-500 shrink-0 mt-0.5" />
                <div>
                  <div className="font-bold mb-0.5">动态 Skill 规则注入说明</div>
                  <p className="text-[11px] text-teal-800 dark:text-teal-300 leading-relaxed">
                    借鉴标准 <code className="font-mono bg-teal-500/20 px-1 py-0.5 rounded">SKILL.md</code> 规范。激活的技能将根据用户的对话 Query 智能识别挂载，自动在后台追加约束指令，无缝调整 AI 智囊的语气、排版与推理视角。
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {skills.map(skill => (
                  <div
                    key={skill.id}
                    className={`p-4 rounded-xl border transition-all ${
                      skill.enabled
                        ? "border-teal-500/40 bg-teal-500/5 dark:bg-teal-950/20"
                        : "border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/30 opacity-70"
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3 mb-2">
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-teal-500/20 text-teal-600 dark:text-teal-300">
                          {skill.category}
                        </span>
                        <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                          {skill.name}
                        </h4>
                      </div>

                      <button
                        onClick={() => handleToggleSkill(skill.id)}
                        className="text-teal-600 dark:text-teal-400 hover:opacity-80 transition-opacity"
                        title={skill.enabled ? "点击停用" : "点击启用"}
                      >
                        {skill.enabled ? (
                          <ToggleRight className="w-6 h-6 text-teal-500" />
                        ) : (
                          <ToggleLeft className="w-6 h-6 text-slate-400" />
                        )}
                      </button>
                    </div>

                    <p className="text-xs text-slate-600 dark:text-slate-300 mb-3 leading-relaxed">
                      {skill.description}
                    </p>

                    <div className="space-y-1 bg-white dark:bg-slate-900 p-2.5 rounded-lg border border-slate-200 dark:border-slate-800/80">
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                        技能约束条款 (Rules)
                      </span>
                      {skill.rules.map((rule, idx) => (
                        <div key={idx} className="text-[11px] text-slate-700 dark:text-slate-300 flex items-start gap-1.5">
                          <Check className="w-3 h-3 text-teal-500 shrink-0 mt-0.5" />
                          <span>{rule}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : activeTab === "mcp-tools" ? (
            /* TAB 2: MCP Tools & Live Runner */
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 h-full">
              {/* Tool Schema List (5 cols) */}
              <div className="md:col-span-5 space-y-3">
                <h4 className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                  注册的 MCP JSON-RPC Tools
                </h4>
                {mcpSchema?.tools.map(tool => (
                  <div
                    key={tool.name}
                    onClick={() => {
                      setSelectedTool(tool.name);
                      setTestToolArgs(
                        tool.name === "nebulatide_read_vfs_file"
                          ? '{\n  "path": "@宣言/星云潮汐宣言.md"\n}'
                          : tool.name === "nebulatide_create_post"
                          ? '{\n  "title": "MCP Agent 赛博沉淀篇",\n  "content": "# MCP 测试\\n\\n由 MCP 接口远程调用生成。"\n}'
                          : "{}"
                      );
                    }}
                    className={`p-3 rounded-xl border transition-all cursor-pointer ${
                      selectedTool === tool.name
                        ? "border-teal-500 bg-teal-500/10 dark:bg-teal-950/40"
                        : "border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/30 hover:border-slate-300"
                    }`}
                  >
                    <div className="font-mono text-xs font-bold text-teal-600 dark:text-teal-300 mb-1">
                      {tool.name}
                    </div>
                    <div className="text-xs text-slate-600 dark:text-slate-400">
                      {tool.description}
                    </div>
                  </div>
                ))}
              </div>

              {/* Tool Execution Sandbox (7 cols) */}
              <div className="md:col-span-7 flex flex-col space-y-3 bg-slate-50/50 dark:bg-slate-950/30 p-4 rounded-xl border border-slate-200 dark:border-slate-800">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                    <Terminal className="w-4 h-4 text-teal-500" />
                    <span>MCP JSON-RPC 测试沙盒 ({selectedTool})</span>
                  </h4>
                  <button
                    onClick={handleRunMCPTool}
                    disabled={executingTool || !selectedTool}
                    className="px-3 py-1.5 rounded-lg text-xs font-medium text-white bg-teal-600 hover:bg-teal-500 active:scale-95 transition-all shadow flex items-center gap-1.5 disabled:opacity-50"
                  >
                    <Play className="w-3.5 h-3.5" />
                    <span>{executingTool ? "执行中..." : "触发 MCP Tool/Call"}</span>
                  </button>
                </div>

                <div>
                  <label className="block text-[10px] font-mono text-slate-500 dark:text-slate-400 mb-1">
                    Input Arguments (JSON Format):
                  </label>
                  <textarea
                    rows={4}
                    value={testToolArgs}
                    onChange={e => setTestToolArgs(e.target.value)}
                    className="w-full p-2.5 text-xs font-mono rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-teal-500/50"
                  />
                </div>

                <div className="flex-1 min-h-[160px]">
                  <label className="block text-[10px] font-mono text-slate-500 dark:text-slate-400 mb-1">
                    JSON-RPC Response Payload:
                  </label>
                  <pre className="p-3 text-xs font-mono rounded-lg border border-slate-800 bg-slate-950 text-emerald-400 overflow-x-auto min-h-[140px] max-h-[220px] custom-scrollbar">
                    {testResult || "// 点击右上角【触发 MCP Tool/Call】查看返回结果"}
                  </pre>
                </div>
              </div>
            </div>
          ) : (
            /* TAB 3: MCP Resources List */
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">
                标准 MCP Resources (URIs)
              </h4>
              <div className="space-y-3">
                {mcpSchema?.resources.map(res => (
                  <div
                    key={res.uri}
                    className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/30 flex items-start justify-between gap-4"
                  >
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="px-2 py-0.5 rounded font-mono text-[10px] font-bold bg-teal-500/20 text-teal-600 dark:text-teal-300">
                          {res.mimeType}
                        </span>
                        <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                          {res.name}
                        </h4>
                      </div>
                      <div className="text-xs font-mono text-teal-600 dark:text-teal-400 mb-1">
                        {res.uri}
                      </div>
                      <p className="text-xs text-slate-600 dark:text-slate-400">
                        {res.description}
                      </p>
                    </div>

                    <button
                      onClick={async () => {
                        try {
                          const data = await mcpSkillService.readMCPResource(res.uri);
                          alert(JSON.stringify(data, null, 2));
                        } catch (e: any) {
                          alert(`读取失败: ${e.message}`);
                        }
                      }}
                      className="px-3 py-1.5 rounded-lg text-xs font-medium text-teal-700 dark:text-teal-300 bg-teal-500/10 hover:bg-teal-500/20 transition-colors shrink-0"
                    >
                      读取 Resource
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer Controls */}
        <div className="px-6 py-3.5 border-t border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-950/60 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 font-mono">
            <Code2 className="w-4 h-4 text-teal-500" />
            <span>Endpoint: POST /api/mcp | JSON-RPC 2.0 Spec</span>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-medium text-white bg-teal-600 hover:bg-teal-500 transition-colors shadow"
          >
            完成并关闭
          </button>
        </div>
      </div>
    </div>
  );
};
