import React, { useState } from 'react';
import { Post } from '../../types';
import Markdown from 'react-markdown';
import { X, Heart, Clock, Sparkles, Share2, ArrowLeft, Bookmark, Type, Download } from 'lucide-react';
import { ShareCardModal } from './ShareCardModal';

interface ArticleDetailModalProps {
  post: Post;
  onClose: () => void;
  onLike: (postId: string) => void;
  onDeletePost?: (postId: string) => void;
}

export const ArticleDetailModal: React.FC<ArticleDetailModalProps> = ({
  post,
  onClose,
  onLike,
  onDeletePost,
}) => {
  const [fontSize, setFontSize] = useState<'normal' | 'large'>('normal');
  const [bookmarked, setBookmarked] = useState(false);
  const [copied, setCopied] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/40 dark:bg-slate-950/75 backdrop-blur-md sm:backdrop-blur-xl flex justify-center p-2 sm:p-4 md:p-6 transition-all duration-200 animate-in fade-in"
      onClick={(e) => {
        e.stopPropagation();
        onClose();
      }}
    >
      
      {/* Article Container */}
      <div
        className="bg-white dark:bg-slate-900/95 border border-slate-200 dark:border-slate-800/90 rounded-3xl max-w-4xl w-full my-auto shadow-2xl relative overflow-hidden flex flex-col max-h-[92vh] animate-in zoom-in-95 duration-200 text-slate-900 dark:text-slate-100"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Header Bar */}
        <div className="sticky top-0 z-30 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md px-6 py-4 border-b border-slate-200 dark:border-slate-800/80 flex items-center justify-between">
          <button
            id="modal-back-btn"
            onClick={onClose}
            className="flex items-center gap-2 text-xs font-medium text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition-colors"
          >
            <ArrowLeft className="w-4 h-4 text-teal-600 dark:text-teal-400" />
            <span>返回文章列表</span>
          </button>

          <div className="flex items-center gap-3">
            {onDeletePost && (
              <button
                onClick={() => {
                  if (window.confirm('确定要彻底删除此篇长文么？此操作不可撤销。')) {
                    onDeletePost(post.id);
                    onClose();
                  }
                }}
                className="p-2 rounded-lg text-slate-500 hover:text-rose-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                title="删除此长文"
              >
                <span className="text-xs">🗑️ 删除</span>
              </button>
            )}

            {/* Font Size Toggle */}
            <button
              id="font-size-toggle"
              onClick={() => setFontSize(fontSize === 'normal' ? 'large' : 'normal')}
              className="p-2 rounded-lg text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              title="调整字号"
            >
              <Type className="w-4 h-4" />
            </button>

            {/* Bookmark */}
            <button
              id="article-bookmark-toggle"
              onClick={() => setBookmarked(!bookmarked)}
              className={`p-2 rounded-lg transition-colors ${
                bookmarked ? 'text-amber-500 bg-amber-500/10' : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
              title="珍藏这篇文章"
            >
              <Bookmark className={`w-4 h-4 ${bookmarked ? 'fill-current' : ''}`} />
            </button>

            {/* Share & Generate Card */}
            <button
              id="article-share-btn"
              onClick={() => setShowShareModal(true)}
              className="px-3 py-1.5 rounded-lg bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-300 border border-teal-300 dark:border-teal-500/30 hover:bg-teal-200 dark:hover:bg-teal-900 text-xs font-mono transition-colors flex items-center gap-1.5 shadow-sm"
              title="生成分享卡片"
            >
              <Share2 className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
              <span>卡片导出</span>
            </button>

            <div className="h-4 w-[1px] bg-slate-200 dark:bg-slate-800" />

            {/* Close Button */}
            <button
              id="modal-close-btn"
              onClick={onClose}
              className="p-2 rounded-full text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div className="overflow-y-auto px-6 sm:px-12 py-8 space-y-8 flex-1 custom-scrollbar">
          
          {/* Category & Date */}
          <div className="space-y-4 text-center max-w-2xl mx-auto">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-100 dark:bg-teal-950/80 border border-teal-300 dark:border-teal-500/30 text-teal-800 dark:text-teal-300 text-xs font-mono">
              <Sparkles className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
              <span>{post.category}</span>
            </div>

            <h1 className="text-2xl sm:text-4xl font-bold font-serif text-slate-900 dark:text-white tracking-tight leading-snug">
              {post.title}
            </h1>

            <p className="text-sm sm:text-base text-slate-600 dark:text-slate-400 font-serif italic">
              {post.subtitle}
            </p>

            <div className="flex items-center justify-center gap-4 text-xs text-slate-500 dark:text-slate-400 font-mono pt-2 border-t border-slate-200 dark:border-slate-800/60 max-w-md mx-auto">
              <div className="flex items-center gap-2">
                <img src={post.author.avatar} alt={post.author.name} className="w-5 h-5 rounded-full object-cover" />
                <span className="text-slate-700 dark:text-slate-300">{post.author.name}</span>
              </div>
              <span>•</span>
              <span>{post.date}</span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-slate-400" />
                {post.readTime}
              </span>
            </div>
          </div>

          {/* Cover Hero Image */}
          {post.coverImage && (
            <div className="rounded-2xl overflow-hidden max-h-80 w-full relative shadow-xl border border-slate-200 dark:border-slate-800">
              <img src={post.coverImage} alt={post.title} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 via-transparent to-transparent" />
            </div>
          )}

          {/* Markdown Content */}
          <div className={`prose dark:prose-invert prose-teal max-w-none text-slate-800 dark:text-slate-200 font-light leading-relaxed ${
            fontSize === 'large' ? 'text-lg sm:text-xl space-y-6' : 'text-base sm:text-lg space-y-4'
          }`}>
            <Markdown>{post.content}</Markdown>
          </div>

          {/* Tags */}
          <div className="pt-8 border-t border-slate-200 dark:border-slate-800/80 flex flex-wrap gap-2">
            {post.tags.map((tag) => (
              <span key={tag} className="text-xs font-mono px-3 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                #{tag}
              </span>
            ))}
          </div>

          {/* Like & Appreciate Banner */}
          <div className="bg-slate-50 dark:bg-slate-950/80 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 text-center space-y-3">
            <h4 className="text-sm font-semibold text-slate-800 dark:text-slate-200">如果这段思考引起了你的共鸣...</h4>
            <p className="text-xs text-slate-500 dark:text-slate-400">在 NebulaTide，所有的碰撞都是向外涌出的微浪。</p>
            <div className="flex justify-center gap-3">
              <button
                id="modal-like-btn"
                onClick={() => onLike(post.id)}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-rose-50 dark:bg-rose-500/20 hover:bg-rose-100 dark:hover:bg-rose-500/30 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-500/40 text-xs font-semibold transition-all shadow-md"
              >
                <Heart className="w-4 h-4 fill-current text-rose-500 dark:text-rose-400" />
                <span>给此思想点赞 ({post.likes})</span>
              </button>
              <button
                onClick={() => setShowShareModal(true)}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-teal-50 dark:bg-teal-500/20 hover:bg-teal-100 dark:hover:bg-teal-500/30 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-500/40 text-xs font-semibold transition-all shadow-md"
              >
                <Share2 className="w-4 h-4 text-teal-600 dark:text-teal-400" />
                <span>生成金句卡片</span>
              </button>
            </div>
          </div>

        </div>
      </div>

      {/* Share Card Modal */}
      <ShareCardModal
        isOpen={showShareModal}
        onClose={() => setShowShareModal(false)}
        title={post.title}
        quoteOrExcerpt={post.subtitle || post.content.slice(0, 100)}
        category={post.category}
        date={post.date}
      />
    </div>
  );
};
