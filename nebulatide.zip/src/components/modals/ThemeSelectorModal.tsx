import React, { useState } from 'react';
import { Palette, Check, Moon, Sun, Sparkles, X, Type, Layers, RefreshCw, Sliders, CheckCircle2 } from 'lucide-react';
import { THEME_PRESETS, ThemePreset } from '../../config/theme';
import {
  ENGLISH_FONTS,
  CHINESE_FONTS,
  FONT_COMBO_PRESETS,
  FontComboPreset,
  applyFontPreference
} from '../../config/typography';

interface ThemeSelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentPresetId: string;
  onSelectPreset: (presetId: string) => void;
  currentEnFont: string;
  currentCnFont: string;
  onSelectFonts: (enFontId: string, cnFontId: string) => void;
  theme: 'dark' | 'light';
  onToggleTheme: (mode: 'dark' | 'light') => void;
}

export const ThemeSelectorModal: React.FC<ThemeSelectorModalProps> = ({
  isOpen,
  onClose,
  currentPresetId,
  onSelectPreset,
  currentEnFont,
  currentCnFont,
  onSelectFonts,
  theme,
  onToggleTheme,
}) => {
  const [activeTab, setActiveTab] = useState<'theme' | 'typography'>('typography');

  if (!isOpen) return null;

  // Find active font combo preset if any
  const currentCombo = FONT_COMBO_PRESETS.find(
    p => p.enFontId === currentEnFont && p.cnFontId === currentCnFont
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col animate-in zoom-in-95 duration-200 max-h-[90vh]"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-teal-500/10 text-teal-600 dark:text-teal-400 border border-teal-500/20">
              <Palette className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                外观与全站字体排版
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-mono">
                Appearance, Color Themes & Global Typography
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Quick Mode Switcher & Tab Switcher Bar */}
        <div className="px-6 py-3 border-b border-slate-200/80 dark:border-slate-800/80 bg-slate-100/50 dark:bg-slate-950/30 flex items-center justify-between gap-3">
          {/* Tabs */}
          <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-200/60 dark:bg-slate-800/80 text-xs font-mono">
            <button
              onClick={() => setActiveTab('typography')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1.5 ${
                activeTab === 'typography'
                  ? 'bg-white dark:bg-slate-900 text-teal-600 dark:text-teal-400 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Type className="w-3.5 h-3.5" />
              <span>中英文字体</span>
            </button>

            <button
              onClick={() => setActiveTab('theme')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1.5 ${
                activeTab === 'theme'
                  ? 'bg-white dark:bg-slate-900 text-teal-600 dark:text-teal-400 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Palette className="w-3.5 h-3.5" />
              <span>主题调色板</span>
            </button>
          </div>

          {/* Quick Sun/Moon Toggle */}
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-mono text-slate-400 hidden sm:inline">日/夜间</span>
            <button
              onClick={() => onToggleTheme(theme === 'dark' ? 'light' : 'dark')}
              className="px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-amber-500 dark:text-teal-300 hover:scale-105 active:scale-95 transition-all text-xs font-mono font-bold flex items-center gap-1.5 shadow-sm"
            >
              {theme === 'dark' ? (
                <>
                  <Moon className="w-3.5 h-3.5 text-teal-300" />
                  <span>暗色 Mode</span>
                </>
              ) : (
                <>
                  <Sun className="w-3.5 h-3.5 text-amber-500" />
                  <span>亮色 Mode</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-6 space-y-6 overflow-y-auto custom-scrollbar flex-1">
          {activeTab === 'typography' && (
            <div className="space-y-6">
              {/* Preset Combo Cards */}
              <div>
                <label className="text-xs font-mono font-bold text-slate-500 uppercase tracking-wider block mb-3 flex items-center justify-between">
                  <span>推荐字体组合预设 (Typography Presets)</span>
                  <span className="text-[10px] text-teal-600 dark:text-teal-400 font-normal">Claude 衬线为主推</span>
                </label>

                <div className="grid grid-cols-1 gap-2.5">
                  {FONT_COMBO_PRESETS.map((combo: FontComboPreset) => {
                    const isSelected = currentEnFont === combo.enFontId && currentCnFont === combo.cnFontId;
                    return (
                      <button
                        key={combo.id}
                        onClick={() => onSelectFonts(combo.enFontId, combo.cnFontId)}
                        className={`w-full p-3.5 rounded-2xl border text-left transition-all flex items-start justify-between group ${
                          isSelected
                            ? 'border-teal-500 bg-teal-500/5 dark:bg-teal-950/30 shadow-md ring-1 ring-teal-500/30'
                            : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-slate-50/50 dark:bg-slate-950/40'
                        }`}
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-bold text-slate-900 dark:text-white group-hover:text-teal-600 dark:group-hover:text-teal-300 transition-colors">
                              {combo.name}
                            </span>
                            <span className="px-1.5 py-0.5 rounded text-[9px] font-mono font-bold bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                              {combo.badge}
                            </span>
                          </div>
                          <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                            {combo.description}
                          </p>
                        </div>

                        {isSelected ? (
                          <div className="p-1 rounded-full bg-teal-600 text-white shadow shrink-0 mt-0.5">
                            <Check className="w-3.5 h-3.5" />
                          </div>
                        ) : (
                          <span className="text-xs font-mono text-slate-400 group-hover:text-teal-600 dark:group-hover:text-teal-300 shrink-0 mt-0.5">
                            应用
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Granular Selection for EN & CN */}
              <div className="pt-2 border-t border-slate-200/80 dark:border-slate-800/80 space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* English Font Picker */}
                  <div className="space-y-2">
                    <label className="text-xs font-mono font-bold text-slate-700 dark:text-slate-300 block">
                      英文字体 (English Font)
                    </label>
                    <select
                      value={currentEnFont}
                      onChange={(e) => onSelectFonts(e.target.value, currentCnFont)}
                      className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 text-slate-900 dark:text-white text-xs font-mono focus:ring-2 focus:ring-teal-500 focus:outline-none"
                    >
                      {ENGLISH_FONTS.map((font) => (
                        <option key={font.id} value={font.id}>
                          {font.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Chinese Font Picker */}
                  <div className="space-y-2">
                    <label className="text-xs font-mono font-bold text-slate-700 dark:text-slate-300 block">
                      中文字体 (Chinese Font)
                    </label>
                    <select
                      value={currentCnFont}
                      onChange={(e) => onSelectFonts(currentEnFont, e.target.value)}
                      className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 text-slate-900 dark:text-white text-xs font-mono focus:ring-2 focus:ring-teal-500 focus:outline-none"
                    >
                      {CHINESE_FONTS.map((font) => (
                        <option key={font.id} value={font.id}>
                          {font.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              {/* Realtime Live Preview Card */}
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800/80 space-y-2">
                <div className="flex items-center justify-between text-[11px] font-mono text-slate-400">
                  <span className="flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-teal-500" />
                    <span>字体实时渲染预览 (Live Typography Preview)</span>
                  </span>
                  <span className="text-teal-600 dark:text-teal-400 font-bold">
                    {currentCombo ? currentCombo.name : '自定义组合'}
                  </span>
                </div>

                <div className="pt-2 border-t border-slate-200/60 dark:border-slate-800/60 space-y-2">
                  <h4 className="text-lg font-bold text-slate-900 dark:text-white">
                    星云潮汐 · NebulaTide
                  </h4>
                  <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed font-serif">
                    “第一性原理 × 每日复利。潮起时航行，潮落时织网。”
                  </p>
                  <p className="text-xs text-slate-500 dark:text-slate-400 font-mono">
                    The quick brown fox jumps over the lazy dog. 1234567890
                  </p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'theme' && (
            <div className="space-y-4">
              <label className="text-xs font-mono font-bold text-slate-500 uppercase tracking-wider block">
                语义化配色预设 (Color Palette Presets)
              </label>

              <div className="space-y-3">
                {Object.values(THEME_PRESETS).map((preset: ThemePreset) => {
                  const isSelected = currentPresetId === preset.id;
                  return (
                    <button
                      key={preset.id}
                      onClick={() => onSelectPreset(preset.id)}
                      className={`w-full p-3.5 rounded-2xl border text-left transition-all flex items-center justify-between group ${
                        isSelected
                          ? 'border-teal-500 bg-teal-500/5 dark:bg-teal-950/30 shadow-md ring-1 ring-teal-500/30'
                          : 'border-slate-200 dark:border-slate-800/80 hover:border-slate-300 dark:hover:border-slate-700 bg-slate-50/50 dark:bg-slate-950/40'
                      }`}
                    >
                      <div className="flex items-center gap-3.5">
                        {/* Preview Color Badge */}
                        <div
                          className="w-10 h-10 rounded-2xl border border-slate-200 dark:border-slate-700 flex items-center justify-center relative overflow-hidden shadow-inner shrink-0"
                          style={{ backgroundColor: preset.previewBg }}
                        >
                          <div
                            className="w-4 h-4 rounded-full shadow-sm"
                            style={{ backgroundColor: preset.previewAccent }}
                          />
                        </div>

                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-slate-900 dark:text-slate-100 group-hover:text-teal-600 dark:group-hover:text-teal-300 transition-colors">
                              {preset.name}
                            </span>
                            {preset.mode === 'dark' ? (
                              <Moon className="w-3 h-3 text-teal-400 shrink-0" />
                            ) : (
                              <Sun className="w-3 h-3 text-amber-500 shrink-0" />
                            )}
                          </div>
                          <p className="text-[11px] text-slate-500 dark:text-slate-400">
                            色彩氛围: {preset.colorName}
                          </p>
                        </div>
                      </div>

                      {isSelected ? (
                        <div className="p-1 rounded-full bg-teal-600 text-white shadow">
                          <Check className="w-3.5 h-3.5" />
                        </div>
                      ) : (
                        <span className="text-[10px] font-mono text-slate-400 group-hover:text-teal-600 dark:group-hover:text-teal-300">
                          应用调色板
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 flex items-center justify-between">
          <span className="text-[11px] font-mono text-slate-500 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-teal-500" />
            <span>实时全局应用，已自动保存至 LocalStorage</span>
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-teal-600 text-white text-xs font-medium hover:bg-teal-500 transition-colors shadow-sm font-mono"
          >
            完成
          </button>
        </div>
      </div>
    </div>
  );
};
