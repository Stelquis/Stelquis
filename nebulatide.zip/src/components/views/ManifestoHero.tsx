import React, { useState } from 'react';
import { MANIFESTO_TEXT } from '../../data/initialData';
import { Cloud, Waves, Compass, Moon, Sparkles, ArrowRight, BookOpen, Anchor } from 'lucide-react';
import { TextScramble } from '../widgets/TextScramble';
import { SpotlightCard } from '../widgets/SpotlightCard';
import { AITaskFlowDashboardWidget } from '../widgets/AITaskFlowDashboardWidget';

interface ManifestoHeroProps {
  onNavigateToArticles: () => void;
  onNavigateToRituals: () => void;
  onNavigateToThoughts: () => void;
}

export const ManifestoHero: React.FC<ManifestoHeroProps> = ({
  onNavigateToArticles,
  onNavigateToRituals,
  onNavigateToThoughts,
}) => {
  const [activeTenetIndex, setActiveTenetIndex] = useState(0);

  const iconsMap = [Cloud, Waves, Compass, Moon];

  return (
    <section className="relative pt-8 pb-16 px-4 sm:px-6 lg:px-8 max-w-6xl xl:max-w-7xl 2xl:max-w-[1500px] mx-auto text-slate-900 dark:text-slate-100 transition-colors duration-300">
      
      {/* Decorative ambient gradient backdrop */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-gradient-to-tr from-teal-500/10 via-indigo-500/10 to-purple-500/10 blur-3xl rounded-full pointer-events-none" />

      {/* Main Header Banner */}
      <div className="text-center space-y-6 max-w-3xl mx-auto mb-16 relative z-10">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-teal-500/10 dark:bg-teal-950/60 border border-teal-500/30 text-teal-700 dark:text-teal-300 text-xs font-mono tracking-wider shadow-inner">
          <Sparkles className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400 animate-pulse" />
          <span>NEBULATIDE PHILOSOPHY · 混沌与潮汐宣言</span>
        </div>

        <h1 className="text-3xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-slate-900 dark:text-white font-serif leading-tight">
          NebulaTide <span className="bg-gradient-to-r from-teal-600 via-indigo-600 to-purple-600 dark:from-teal-300 dark:via-indigo-300 dark:to-purple-300 bg-clip-text text-transparent"><TextScramble text="哲学" /></span>
        </h1>

        <p className="text-base sm:text-xl text-slate-700 dark:text-slate-300 font-light leading-relaxed">
          一个关于混沌与潮汐的故事。
          <br className="hidden sm:inline" />
          <span className="italic text-teal-700 dark:text-teal-300/90 font-serif">“清晰不是混沌的对立面，而是混沌的沉积物。”</span>
        </p>

        {/* Action CTAs */}
        <div className="flex flex-wrap items-center justify-center gap-3 pt-4">
          <button
            id="manifesto-read-articles"
            onClick={onNavigateToArticles}
            className="px-5 py-2.5 rounded-full text-xs sm:text-sm font-semibold text-white bg-gradient-to-r from-teal-600 to-indigo-600 hover:from-teal-500 hover:to-indigo-500 transition-all shadow-md flex items-center gap-2 group"
          >
            <BookOpen className="w-4 h-4" />
            <span>探索潮汐长文</span>
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </button>
          <button
            id="manifesto-start-ritual"
            onClick={onNavigateToRituals}
            className="px-5 py-2.5 rounded-full text-xs sm:text-sm font-medium text-slate-700 dark:text-slate-200 bg-white/80 dark:bg-slate-900/80 hover:bg-white dark:hover:bg-slate-800 border border-slate-300 dark:border-slate-700/80 hover:border-teal-500/40 transition-all flex items-center gap-2 shadow-sm"
          >
            <Compass className="w-4 h-4 text-teal-600 dark:text-teal-400" />
            <span>开启退潮织网</span>
          </button>
        </div>
      </div>

      {/* Manifesto 4 Tenets Showcase Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start relative z-10">
        
        {/* Navigation Sidebar Cards */}
        <div className="lg:col-span-5 space-y-3">
          <h2 className="text-xs font-mono uppercase tracking-widest text-slate-500 dark:text-slate-400 px-1 mb-2">
            思想四大章节 / The Four Tenets
          </h2>
          {MANIFESTO_TEXT.sections.map((section, idx) => {
            const Icon = iconsMap[idx] || Sparkles;
            const isSelected = activeTenetIndex === idx;
            return (
              <button
                key={section.id}
                id={`tenet-tab-${section.id}`}
                onClick={() => setActiveTenetIndex(idx)}
                className={`w-full text-left p-4 rounded-2xl border transition-all duration-300 flex items-start gap-4 ${
                  isSelected
                    ? 'bg-white/90 dark:bg-slate-900 border-teal-500/50 shadow-md dark:shadow-xl dark:shadow-teal-950/30'
                    : 'bg-white/40 dark:bg-slate-900/60 border-slate-200/80 dark:border-slate-800 hover:bg-white/70 dark:hover:bg-slate-900'
                }`}
              >
                <div
                  className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 transition-colors ${
                    isSelected
                      ? 'bg-gradient-to-tr from-teal-500 to-indigo-600 text-white shadow-md'
                      : 'bg-slate-200 dark:bg-slate-800/80 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                </div>
                <div>
                  <h3 className={`text-sm font-bold ${isSelected ? 'text-teal-700 dark:text-teal-300' : 'text-slate-800 dark:text-slate-200'}`}>
                    {section.title}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 line-clamp-1 font-light">
                    {section.content.split('\n')[0]}
                  </p>
                </div>
              </button>
            );
          })}
        </div>

        {/* Selected Tenet Deep Read View with Apple Glass */}
        <SpotlightCard className="lg:col-span-7 bg-white/80 dark:bg-slate-900 backdrop-blur-xl border border-slate-200/80 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-sm dark:shadow-2xl relative overflow-hidden">
          
          {/* Subtle background glow icon */}
          <div className="absolute -bottom-10 -right-10 text-teal-500/5 pointer-events-none">
            {React.createElement(iconsMap[activeTenetIndex] || Sparkles, { className: 'w-64 h-64' })}
          </div>

          <div className="space-y-6 relative z-10">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
              <span className="text-xs font-mono text-teal-700 dark:text-teal-400 bg-teal-500/10 dark:bg-teal-950/60 px-3 py-1 rounded-full border border-teal-500/20">
                0{activeTenetIndex + 1} / 04 章节细读
              </span>
              <span className="text-xs text-slate-400 font-mono">NEBULATIDE READ</span>
            </div>

            <h2 className="text-2xl sm:text-3xl font-bold font-serif text-slate-900 dark:text-white tracking-tight">
              {MANIFESTO_TEXT.sections[activeTenetIndex].title}
            </h2>

            <div className="prose dark:prose-invert max-w-none text-slate-700 dark:text-slate-300 text-sm sm:text-base leading-relaxed whitespace-pre-line font-light">
              {MANIFESTO_TEXT.sections[activeTenetIndex].content}
            </div>

            {/* Quick action link inside tenet */}
            <div className="pt-6 border-t border-slate-200 dark:border-slate-800/80 flex items-center justify-between">
              <span className="text-xs text-slate-500 dark:text-slate-400">
                觉得有共鸣？可以在混沌沙盒里倾泻当前思绪。
              </span>
              <button
                id="tenet-dump-thought-btn"
                onClick={onNavigateToThoughts}
                className="text-xs font-semibold text-teal-600 dark:text-teal-400 hover:text-teal-500 flex items-center gap-1 group"
              >
                <span>倾泻混沌思绪</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          </div>
        </SpotlightCard>
      </div>

      {/* Cyber Glassmorphism AI Task Flow & 3D Node Stream Workspace Widget */}
      <div className="mt-12">
        <AITaskFlowDashboardWidget />
      </div>

      {/* Quote Banner with Apple Glass */}
      <div className="mt-16 bg-white/70 dark:bg-gradient-to-r dark:from-teal-950/50 dark:via-slate-900/90 dark:to-indigo-950/50 border border-teal-500/30 rounded-3xl p-8 text-center relative overflow-hidden shadow-sm dark:shadow-2xl backdrop-blur-xl">
        <div className="max-w-2xl mx-auto space-y-4">
          <Anchor className="w-8 h-8 text-teal-600 dark:text-teal-400/80 mx-auto animate-bounce" />
          <p className="text-xl sm:text-2xl font-serif italic text-teal-800 dark:text-teal-200 font-medium">
            “{MANIFESTO_TEXT.quote}”
          </p>
          <p className="text-xs font-mono text-slate-500 dark:text-slate-400">
            NebulaTide · 保持感受流向的能力
          </p>
        </div>
      </div>

      {/* Three Pillars Summary Cards with Apple Glass */}
      <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-6">
        <SpotlightCard className="p-6 rounded-2xl bg-white/70 dark:bg-slate-900 backdrop-blur-xl border border-slate-200/80 dark:border-slate-800 hover:border-teal-500/30 transition-all space-y-3 shadow-sm">
          <div className="w-10 h-10 rounded-xl bg-teal-500/10 text-teal-600 dark:text-teal-400 flex items-center justify-center font-bold">
            🌌
          </div>
          <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">清晰是混沌的沉积物</h3>
          <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
            不强求立竿见影的条理。给思想留出雾气沉淀的空间，最深刻的洞察往往在不经意间结晶。
          </p>
        </SpotlightCard>

        <SpotlightCard className="p-6 rounded-2xl bg-white/70 dark:bg-slate-900 backdrop-blur-xl border border-slate-200/80 dark:border-slate-800 hover:border-indigo-500/30 transition-all space-y-3 shadow-sm">
          <div className="w-10 h-10 rounded-xl bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold">
            🌊
          </div>
          <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">复盘是自然的呼吸</h3>
          <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
            涨潮时试错碰撞，退潮时拾贝沉淀。告别痛苦的自我清算，将复盘看作生命体舒张呼吸的节律。
          </p>
        </SpotlightCard>

        <SpotlightCard className="p-6 rounded-2xl bg-white/70 dark:bg-slate-900 backdrop-blur-xl border border-slate-200/80 dark:border-slate-800 hover:border-purple-500/30 transition-all space-y-3 shadow-sm">
          <div className="w-10 h-10 rounded-xl bg-purple-500/10 text-purple-600 dark:text-purple-400 flex items-center justify-center font-bold">
            🧭
          </div>
          <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">规划是顺势的编织</h3>
          <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
            不执念于僵硬的五年计划。将复盘所得的贝壳连成罗盘，与不确定的暗流优雅共舞。
          </p>
        </SpotlightCard>
      </div>

    </section>
  );
};

