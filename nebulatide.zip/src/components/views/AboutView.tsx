import React, { useState, useRef } from 'react';
import { USER_PROFILE, MIND_MODELS } from '../../data/initialData';
import { TechStackMatrix } from '../widgets/TechStackMatrix';
import { SpotlightCard } from '../widgets/SpotlightCard';
import { PhotoTimelineGallery } from '../widgets/PhotoTimelineGallery';
import {
  Waves,
  Sparkles,
  Send,
  Mail,
  GraduationCap,
  Atom,
  Network,
  GitBranch,
  TrendingUp,
  Flame,
  Copy,
  Check,
  Anchor,
  Camera,
  Upload,
  X,
  RotateCcw,
  Crop,
  Image as ImageIcon,
  Plus,
} from 'lucide-react';

interface AboutViewProps {
  stats: {
    postsCount: number;
    fragmentsCount: number;
    reviewsCount: number;
  };
  onNavigateToProjects?: () => void;
  mindModels?: any[];
  onAddMindModel?: (model: any) => void;
  onDeleteMindModel?: (idOrTitle: string) => void;
}

export const AboutView: React.FC<AboutViewProps> = ({
  stats,
  onNavigateToProjects,
  mindModels = MIND_MODELS,
  onAddMindModel,
  onDeleteMindModel,
}) => {
  const [message, setMessage] = useState('');
  const [sent, setSent] = useState(false);
  const [copiedEmail, setCopiedEmail] = useState<string | null>(null);

  // Avatar Upload & 1:1 Crop States
  const [avatar, setAvatar] = useState<string>(() => {
    return localStorage.getItem('tide_user_avatar') || USER_PROFILE.avatar;
  });
  const [showAvatarModal, setShowAvatarModal] = useState(false);
  const [tempAvatar, setTempAvatar] = useState<string>(avatar);
  const [urlInput, setUrlInput] = useState<string>('');
  const [isDragOver, setIsDragOver] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Modal for creating Mind Model
  const [showModelModal, setShowModelModal] = useState(false);
  const [modelTitle, setModelTitle] = useState('');
  const [modelFormula, setModelFormula] = useState('');
  const [modelDesc, setModelDesc] = useState('');
  const [modelIcon, setModelIcon] = useState('Atom');

  // Process uploaded image to 1:1 ratio square JPEG via HTML5 Canvas
  const processImageToOneToOne = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      setIsProcessing(true);
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          const size = Math.min(img.width, img.height);
          const canvas = document.createElement('canvas');
          canvas.width = 400;
          canvas.height = 400;
          const ctx = canvas.getContext('2d');
          if (!ctx) {
            setIsProcessing(false);
            return resolve(e.target?.result as string);
          }
          const sx = (img.width - size) / 2;
          const sy = (img.height - size) / 2;
          ctx.drawImage(img, sx, sy, size, size, 0, 0, 400, 400);
          const dataUrl = canvas.toDataURL('image/jpeg', 0.92);
          setIsProcessing(false);
          resolve(dataUrl);
        };
        img.onerror = (err) => {
          setIsProcessing(false);
          reject(err);
        };
        img.src = e.target?.result as string;
      };
      reader.onerror = (err) => {
        setIsProcessing(false);
        reject(err);
      };
      reader.readAsDataURL(file);
    });
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      try {
        const croppedBase64 = await processImageToOneToOne(file);
        setTempAvatar(croppedBase64);
      } catch (error) {
        console.error('Avatar processing error:', error);
      }
    }
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file && file.type.startsWith('image/')) {
      try {
        const croppedBase64 = await processImageToOneToOne(file);
        setTempAvatar(croppedBase64);
      } catch (error) {
        console.error('Avatar drop processing error:', error);
      }
    }
  };

  const handleSaveAvatar = () => {
    setAvatar(tempAvatar);
    localStorage.setItem('tide_user_avatar', tempAvatar);
    setShowAvatarModal(false);
  };

  const handleResetAvatar = () => {
    setTempAvatar(USER_PROFILE.avatar);
    setAvatar(USER_PROFILE.avatar);
    localStorage.removeItem('tide_user_avatar');
    setShowAvatarModal(false);
  };

  const handleSendContact = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;
    setSent(true);
    setTimeout(() => {
      setMessage('');
      setSent(false);
    }, 3000);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedEmail(text);
    setTimeout(() => setCopiedEmail(null), 2000);
  };

  const getModelIcon = (iconName: string) => {
    switch (iconName) {
      case 'Atom':
        return <Atom className="w-5 h-5 text-teal-600 dark:text-teal-400" />;
      case 'Network':
        return <Network className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />;
      case 'GitBranch':
        return <GitBranch className="w-5 h-5 text-purple-600 dark:text-purple-400" />;
      case 'TrendingUp':
        return <TrendingUp className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />;
      case 'Sparkles':
        return <Sparkles className="w-5 h-5 text-amber-500 dark:text-amber-400" />;
      case 'Flame':
        return <Flame className="w-5 h-5 text-rose-600 dark:text-rose-400" />;
      default:
        return <Sparkles className="w-5 h-5 text-teal-600 dark:text-teal-400" />;
    }
  };

  return (
    <div className="max-w-5xl xl:max-w-6xl 2xl:max-w-[1500px] mx-auto px-4 sm:px-6 py-10 space-y-12 text-slate-800 dark:text-slate-200 animate-fadeIn transition-colors duration-300">
      
      {/* Personal Hero Card with Apple Glass */}
      <div className="bg-white/80 dark:bg-slate-900 border border-white/80 dark:border-slate-800 rounded-3xl p-6 sm:p-10 shadow-sm dark:shadow-2xl backdrop-blur-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-bl from-teal-500/10 via-indigo-500/10 to-purple-600/10 blur-3xl pointer-events-none" />

        <div className="flex flex-col md:flex-row items-center md:items-start gap-8 relative z-10 text-center md:text-left">
          
          {/* Avatar & Badges */}
          <div className="flex flex-col items-center gap-3 shrink-0">
            <div className="relative group cursor-pointer" onClick={() => { setTempAvatar(avatar); setShowAvatarModal(true); }}>
              <div className="w-28 h-28 sm:w-32 sm:h-32 rounded-3xl overflow-hidden ring-2 ring-teal-500/40 shadow-xl group-hover:scale-105 group-hover:ring-teal-400 transition-all duration-300 relative">
                <img
                  src={avatar}
                  alt={USER_PROFILE.name}
                  className="w-full h-full object-cover aspect-square"
                />
                {/* Overlay hover prompt for upload */}
                <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-[2px] opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center text-white gap-1 p-2 text-center">
                  <Camera className="w-6 h-6 text-teal-400 animate-bounce" />
                  <span className="text-[10px] font-medium tracking-wider">更换头像 (1:1)</span>
                </div>
              </div>

              <button
                type="button"
                onClick={(e) => { e.stopPropagation(); setTempAvatar(avatar); setShowAvatarModal(true); }}
                className="absolute -bottom-2 -right-2 bg-gradient-to-r from-teal-500 to-indigo-600 hover:from-teal-400 hover:to-indigo-500 text-white p-2 rounded-2xl border border-white/40 dark:border-slate-800 shadow-lg hover:scale-110 active:scale-95 transition-all"
                title="更换 1:1 个人头像"
              >
                <Camera className="w-4 h-4" />
              </button>
            </div>

            <span className="text-[11px] font-mono text-teal-800 dark:text-teal-300 bg-teal-100 dark:bg-teal-950/80 px-3 py-1 rounded-full border border-teal-300 dark:border-teal-500/30">
              @{USER_PROFILE.handle}
            </span>
          </div>

          {/* User Meta */}
          <div className="space-y-4 flex-1">
            <div className="space-y-1">
              <div className="flex flex-wrap items-center justify-center md:justify-start gap-3">
                <h1 className="text-3xl sm:text-4xl font-bold font-serif text-slate-900 dark:text-white tracking-tight">
                  👋 Hi, I'm {USER_PROFILE.name}
                </h1>
                <span className="px-3 py-1 rounded-full bg-slate-100 dark:bg-slate-950 text-indigo-800 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-500/30 text-xs font-mono flex items-center gap-1.5">
                  <GraduationCap className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                  {USER_PROFILE.university}
                </span>
              </div>

              <div className="flex flex-wrap items-center justify-center md:justify-start gap-2 pt-1 font-mono text-xs text-teal-700 dark:text-teal-400">
                {USER_PROFILE.fields.map((f, i) => (
                  <span key={f} className="flex items-center gap-1">
                    {i > 0 && <span className="text-slate-400 dark:text-slate-600">•</span>}
                    {f}
                  </span>
                ))}
              </div>
            </div>

            {/* Motto */}
            <div className="p-3 bg-slate-50 dark:bg-slate-950/60 rounded-xl border border-slate-200 dark:border-slate-800/80 italic text-xs sm:text-sm text-slate-700 dark:text-slate-300 font-light border-l-2 border-l-teal-500">
              “{USER_PROFILE.motto}”
            </div>

            <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-300 font-light leading-relaxed">
              {USER_PROFILE.bio}
            </p>

            {/* Social Links Shields Badges */}
            <div className="flex flex-wrap items-center justify-center md:justify-start gap-2.5 pt-2">
              <a
                href={USER_PROFILE.socials.github.url}
                target="_blank"
                rel="noopener noreferrer"
                className="hover:scale-105 transition-transform"
                title="GitHub @Stelquis"
              >
                <img
                  src="https://img.shields.io/badge/GitHub-Stelquis-181717?logo=github&logoColor=white"
                  alt="GitHub"
                  referrerPolicy="no-referrer"
                  className="h-6 rounded shadow"
                />
              </a>

              <a
                href={USER_PROFILE.socials.cnb.url}
                target="_blank"
                rel="noopener noreferrer"
                className="hover:scale-105 transition-transform"
                title="CNB 镜像仓库 @Stelquis"
              >
                <img
                  src="https://img.shields.io/badge/CNB-Stelquis-0052D9?logo=codeberg&logoColor=white"
                  alt="CNB"
                  referrerPolicy="no-referrer"
                  className="h-6 rounded shadow"
                />
              </a>

              <a
                href={USER_PROFILE.socials.gitee.url}
                target="_blank"
                rel="noopener noreferrer"
                className="hover:scale-105 transition-transform"
                title="Gitee @star-n"
              >
                <img
                  src="https://img.shields.io/badge/Gitee-star--n-C71D23?logo=gitee&logoColor=white"
                  alt="Gitee"
                  referrerPolicy="no-referrer"
                  className="h-6 rounded shadow"
                />
              </a>

              <a
                href={USER_PROFILE.socials.linkedin.url}
                target="_blank"
                rel="noopener noreferrer"
                className="hover:scale-105 transition-transform"
                title="LinkedIn @Chenxun Niu"
              >
                <img
                  src="https://img.shields.io/badge/LinkedIn-0A66C2?logo=linkedin&logoColor=white"
                  alt="LinkedIn"
                  referrerPolicy="no-referrer"
                  className="h-6 rounded shadow"
                />
              </a>
            </div>
          </div>
        </div>

        {/* Dynamic Stats Row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-8 mt-8 border-t border-slate-200 dark:border-slate-800/80 text-center">
          <div className="p-3 bg-slate-50 dark:bg-slate-950/50 rounded-xl border border-slate-200 dark:border-slate-800">
            <span className="text-xl sm:text-2xl font-bold text-teal-700 dark:text-teal-300 font-serif block">{stats.postsCount}</span>
            <span className="text-[11px] text-slate-500 dark:text-slate-400 font-mono">潮汐文章</span>
          </div>
          <div className="p-3 bg-slate-50 dark:bg-slate-950/50 rounded-xl border border-slate-200 dark:border-slate-800">
            <span className="text-xl sm:text-2xl font-bold text-indigo-700 dark:text-indigo-300 font-serif block">{stats.fragmentsCount}</span>
            <span className="text-[11px] text-slate-500 dark:text-slate-400 font-mono">星云碎片</span>
          </div>
          <div className="p-3 bg-slate-50 dark:bg-slate-950/50 rounded-xl border border-slate-200 dark:border-slate-800">
            <span className="text-xl sm:text-2xl font-bold text-purple-700 dark:text-purple-300 font-serif block">{stats.reviewsCount}</span>
            <span className="text-[11px] text-slate-500 dark:text-slate-400 font-mono">周度复盘</span>
          </div>
          <div
            onClick={onNavigateToProjects}
            className="p-3 bg-gradient-to-br from-teal-50 dark:from-teal-950/40 to-slate-50 dark:to-slate-950 rounded-xl border border-teal-300 dark:border-teal-500/30 cursor-pointer hover:border-teal-400/60 transition-all group"
          >
            <span className="text-xl sm:text-2xl font-bold text-teal-700 dark:text-teal-400 font-serif block group-hover:scale-105 transition-transform">7 大</span>
            <span className="text-[11px] text-teal-800 dark:text-teal-300 font-mono">硬核项目 →</span>
          </div>
        </div>
      </div>

      {/* Tech Stack Matrix Section */}
      <TechStackMatrix />

      {/* Photo Timeline Gallery Section */}
      <PhotoTimelineGallery />

      {/* Mind Models Grid */}
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <span className="text-xs font-mono text-teal-600 dark:text-teal-400 uppercase tracking-widest block font-semibold">
              MIND MODELS · 思维模型
            </span>
            <h2 className="text-2xl font-bold font-serif text-slate-900 dark:text-white">
              第一性原理与心智矩阵
            </h2>
          </div>

          <button
            onClick={() => setShowModelModal(true)}
            className="px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-800 dark:text-white bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 hover:border-teal-500/50 transition-all flex items-center gap-1.5 shadow-sm"
          >
            <span>+ 新增思维模型</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {mindModels.map((model: any) => (
            <SpotlightCard
              key={model.id || model.title}
              className="p-5 bg-white/80 dark:bg-slate-900 backdrop-blur-xl border border-slate-200/80 dark:border-slate-800 rounded-2xl hover:border-teal-500/40 transition-all space-y-3 group relative shadow-sm"
              spotlightColor="rgba(20, 184, 166, 0.15)"
            >
              <div className="flex items-center justify-between">
                <div className="p-2 rounded-xl bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 group-hover:border-teal-500/30 transition-colors">
                  {getModelIcon(model.icon)}
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-950 text-teal-800 dark:text-teal-300 border border-slate-200 dark:border-slate-800">
                    {model.formula}
                  </span>
                  {onDeleteMindModel && (
                    <button
                      onClick={() => onDeleteMindModel(model.id || model.title)}
                      className="text-slate-400 hover:text-rose-500 p-1 rounded hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                      title="删除思维模型"
                    >
                      <span className="text-xs">🗑️</span>
                    </button>
                  )}
                </div>
              </div>

              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white font-serif group-hover:text-teal-600 dark:group-hover:text-teal-300 transition-colors">
                  {model.title}
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-300 font-light leading-relaxed mt-1">
                  {model.description}
                </p>
              </div>
            </SpotlightCard>
          ))}
        </div>
      </div>

      {/* Mind Model Creation Modal */}
      {showModelModal && (
        <div
          className="fixed inset-0 z-50 bg-slate-900/20 dark:bg-slate-950/70 backdrop-blur-md flex items-center justify-center p-4 transition-all duration-200 animate-in fade-in"
          onClick={() => setShowModelModal(false)}
        >
          <div
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-md w-full p-6 space-y-5 shadow-2xl text-slate-900 dark:text-slate-100"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="text-base font-bold text-slate-900 dark:text-white font-serif">新增第一性原理 / 思维模型</h3>
              <button onClick={() => setShowModelModal(false)} className="text-slate-400 hover:text-slate-900 dark:hover:text-white">✕</button>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (!modelTitle.trim() || !modelDesc.trim()) return;
                if (onAddMindModel) {
                  onAddMindModel({
                    id: `mm-${Date.now()}`,
                    title: modelTitle.trim(),
                    formula: modelFormula.trim() || '输入 → 输出',
                    description: modelDesc.trim(),
                    icon: modelIcon
                  });
                }
                setModelTitle('');
                setModelFormula('');
                setModelDesc('');
                setShowModelModal(false);
              }}
              className="space-y-4"
            >
              <div>
                <label className="text-xs text-slate-600 dark:text-slate-300 block mb-1">模型名称 *</label>
                <input
                  type="text"
                  placeholder="如: 奥卡姆剃刀原理"
                  value={modelTitle}
                  onChange={(e) => setModelTitle(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-slate-200 focus:outline-none focus:border-teal-500"
                  required
                />
              </div>

              <div>
                <label className="text-xs text-slate-600 dark:text-slate-300 block mb-1">公式 / 简短规则</label>
                <input
                  type="text"
                  placeholder="如: 如无必要，勿增实体"
                  value={modelFormula}
                  onChange={(e) => setModelFormula(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-slate-200 focus:outline-none focus:border-teal-500 font-mono"
                />
              </div>

              <div>
                <label className="text-xs text-slate-600 dark:text-slate-300 block mb-1">模型图标</label>
                <select
                  value={modelIcon}
                  onChange={(e) => setModelIcon(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-slate-200 focus:outline-none"
                >
                  <option value="Atom">⚛️ 原子/第一性</option>
                  <option value="Network">🕸️ 图谱/网络</option>
                  <option value="GitBranch">🌿 分支/演化</option>
                  <option value="TrendingUp">📈 增长/复利</option>
                  <option value="Sparkles">✨ 灵感/熵减</option>
                  <option value="Flame">🔥 火焰/反脆弱</option>
                </select>
              </div>

              <div>
                <label className="text-xs text-slate-600 dark:text-slate-300 block mb-1">详细思考诠释 *</label>
                <textarea
                  rows={3}
                  placeholder="描述该思维模型如何指导具体的工程实践或心智演化..."
                  value={modelDesc}
                  onChange={(e) => setModelDesc(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl p-3 text-xs text-slate-900 dark:text-slate-200 focus:outline-none focus:border-teal-500 resize-none font-serif"
                  required
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl text-xs font-semibold text-white bg-teal-600 hover:bg-teal-500 transition-all shadow-md"
              >
                加入心智矩阵
              </button>
            </form>
          </div>
        </div>
      )}

      {/* NebulaTide Philosophy Statement */}
      <div className="bg-white/80 dark:bg-slate-900 backdrop-blur-xl border border-white/80 dark:border-slate-800/90 rounded-3xl p-6 sm:p-8 space-y-6 shadow-sm">
        <div className="flex items-center gap-2">
          <Anchor className="w-5 h-5 text-teal-600 dark:text-teal-400" />
          <h2 className="text-xl font-bold font-serif text-slate-900 dark:text-white">
            🌊 NebulaTide 哲学体系
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs sm:text-sm text-slate-700 dark:text-slate-300 font-light leading-relaxed">
          <div className="p-4 bg-slate-50 dark:bg-slate-950/60 rounded-2xl border border-slate-200 dark:border-slate-800/80 space-y-2">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white font-serif flex items-center gap-2 text-teal-700 dark:text-teal-300">
              <span>🌌 混沌是创造的温床</span>
            </h3>
            <p>
              思绪初生时从来不是条理分明的，它像星云弥漫、缠绕、没有边界。习惯急着整理，却忘了混沌本身就是创造的温床。不急着开灯，在星云的暗处，有些东西正在缓慢发光。
            </p>
          </div>

          <div className="p-4 bg-slate-50 dark:bg-slate-950/60 rounded-2xl border border-slate-200 dark:border-slate-800/80 space-y-2">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white font-serif flex items-center gap-2 text-indigo-700 dark:text-indigo-300">
              <span>🌊 潮汐是自然的呼吸</span>
            </h3>
            <p>
              涨潮时向外奔涌，执行、碰撞、试错；退潮时弯腰捡拾，那些散落的贝壳开始显形。复盘不是自责的仪式，不是 KPI 的清算，它是呼吸——吸气时扩张，呼气时沉淀。没有对错，只有节律。
            </p>
          </div>

          <div className="p-4 bg-slate-50 dark:bg-slate-950/60 rounded-2xl border border-slate-200 dark:border-slate-800/80 space-y-2">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white font-serif flex items-center gap-2 text-purple-700 dark:text-purple-300">
              <span>🧭 编织是顺势的方向</span>
            </h3>
            <p>
              当贝壳足够多，你会看见隐形的线。不是强行画一条“正确道路”，而是让方向自然浮现。不预测遥远的未来，只感知此刻的流向，把复盘得到的珍珠串成下一程的罗盘。
            </p>
          </div>

          <div className="p-4 bg-slate-50 dark:bg-slate-950/60 rounded-2xl border border-slate-200 dark:border-slate-800/80 space-y-2">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white font-serif flex items-center gap-2 text-amber-700 dark:text-amber-300">
              <span>⏳ 节奏是不快，但别停</span>
            </h3>
            <p>
              每个 commit 都微小到几乎看不见，但在时间的杠杆下，它会自己滚起来。每天 × 365 = 37× 的复利逻辑，天然适用于编码与心智成长。
            </p>
          </div>
        </div>
      </div>

      {/* Email Contacts Badges Section */}
      <div className="bg-white/80 dark:bg-slate-900 backdrop-blur-xl border border-white/80 dark:border-slate-800 rounded-3xl p-6 sm:p-8 space-y-4 shadow-sm">
        <div className="flex items-center gap-2">
          <Mail className="w-5 h-5 text-teal-600 dark:text-teal-400" />
          <h2 className="text-xl font-bold text-slate-900 dark:text-white font-serif">📫 邮箱与直接联系</h2>
        </div>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          点击下方电子邮箱卡片即可直接复制地址或在邮件客户端开启通信：
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
          {USER_PROFILE.socials.emails.map((email) => (
            <div
              key={email.type}
              onClick={() => copyToClipboard(email.address)}
              className={`p-4 rounded-2xl bg-slate-50 dark:bg-slate-950/80 border ${email.borderColor} hover:bg-slate-100 dark:hover:bg-slate-900/90 transition-all cursor-pointer flex items-center justify-between group shadow-sm`}
            >
              <div className="space-y-1 overflow-hidden">
                <span className="text-[10px] font-mono uppercase tracking-wider text-teal-700 dark:text-teal-400 block font-semibold">
                  {email.type}
                </span>
                <span className="text-xs text-slate-800 dark:text-slate-200 font-mono truncate block group-hover:text-slate-900 dark:group-hover:text-white">
                  {email.address}
                </span>
              </div>
              <div className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-400 group-hover:text-teal-600 dark:group-hover:text-teal-300 shrink-0">
                {copiedEmail === email.address ? (
                  <Check className="w-4 h-4 text-emerald-500" />
                ) : (
                  <Copy className="w-4 h-4" />
                )}
              </div>
            </div>
          ))}
        </div>

        {copiedEmail && (
          <p className="text-xs text-emerald-600 dark:text-emerald-400 text-center animate-fadeIn font-mono">
            已复制邮箱地址到剪贴板：{copiedEmail}
          </p>
        )}
      </div>

      {/* Contact Form */}
      <div className="bg-white/80 dark:bg-slate-900 backdrop-blur-xl border border-white/80 dark:border-slate-800 rounded-3xl p-6 sm:p-8 space-y-4 shadow-sm dark:shadow-xl">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-teal-600 dark:text-teal-400" />
          <h3 className="text-base font-bold text-slate-900 dark:text-white font-serif">找到暗流中的同频者</h3>
        </div>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          如果你对 NebulaTide 哲学、第一性原理拆解或我们的开源项目有所共鸣，欢迎给我留言：
        </p>

        <form onSubmit={handleSendContact} className="space-y-3">
          <textarea
            rows={3}
            placeholder="写下你想对 Niu (Stelquis) 说的话..."
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 text-xs text-slate-900 dark:text-slate-200 placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:border-teal-500 resize-none font-light shadow-inner"
          />
          <div className="flex justify-end">
            <button
              type="submit"
              disabled={!message.trim()}
              className="px-5 py-2.5 rounded-xl text-xs font-semibold text-white bg-gradient-to-r from-teal-600 to-indigo-600 hover:from-teal-500 hover:to-indigo-500 disabled:opacity-40 transition-all flex items-center gap-1.5 shadow-md"
            >
              <Send className="w-3.5 h-3.5" />
              <span>发送共鸣信笺</span>
            </button>
          </div>
          {sent && (
            <p className="text-xs text-teal-600 dark:text-teal-400 text-center animate-fadeIn font-mono">
              ✨ 信笺已借由星云风暴寄出！期待与同频者的思想碰撞。
            </p>
          )}
        </form>
      </div>

      {/* 1:1 Avatar Upload Modal */}
      {showAvatarModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-md animate-fadeIn">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-lg w-full p-6 sm:p-8 space-y-6 shadow-2xl overflow-hidden relative animate-in zoom-in-95 duration-200">
            
            {/* Header */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-teal-100 dark:bg-teal-950/80 text-teal-600 dark:text-teal-400">
                  <Crop className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold font-serif text-slate-900 dark:text-white">
                    更换档案个人头像
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 font-mono">
                    自动剪裁处理为 1:1 完美正方形比例
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowAvatarModal(false)}
                className="p-2 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* 1:1 Live Preview & Upload Zone */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 items-center">
              
              {/* Preview Box */}
              <div className="flex flex-col items-center space-y-2">
                <div className="relative w-36 h-36 sm:w-40 sm:h-40 rounded-2xl overflow-hidden border-2 border-dashed border-teal-500/50 dark:border-teal-500/40 p-1 bg-slate-100 dark:bg-slate-950 shadow-inner group">
                  <img
                    src={tempAvatar}
                    alt="1:1 Avatar Preview"
                    className="w-full h-full object-cover rounded-xl aspect-square"
                  />
                  {isProcessing && (
                    <div className="absolute inset-0 bg-slate-950/80 flex flex-col items-center justify-center text-teal-400 text-xs font-mono gap-2 backdrop-blur-sm">
                      <div className="w-6 h-6 border-2 border-teal-400 border-t-transparent rounded-full animate-spin" />
                      <span>1:1 裁切处理中...</span>
                    </div>
                  )}
                  <span className="absolute top-2 right-2 bg-slate-900/80 text-teal-300 font-mono text-[10px] px-2 py-0.5 rounded-full border border-teal-500/30">
                    1 : 1
                  </span>
                </div>
                <span className="text-[11px] text-slate-500 dark:text-slate-400 font-mono">
                  1:1 正方形预览
                </span>
              </div>

              {/* Upload Drop Zone & Actions */}
              <div className="space-y-4">
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  accept="image/*"
                  className="hidden"
                />

                {/* Drop target button */}
                <div
                  onDragOver={(e) => { e.preventDefault(); setIsDragOver(true); }}
                  onDragLeave={() => setIsDragOver(false)}
                  onDrop={handleDrop}
                  onClick={() => fileInputRef.current?.click()}
                  className={`p-4 rounded-2xl border-2 border-dashed transition-all text-center cursor-pointer flex flex-col items-center gap-2 ${
                    isDragOver
                      ? 'border-teal-500 bg-teal-50 dark:bg-teal-950/40 scale-102'
                      : 'border-slate-300 dark:border-slate-700 hover:border-teal-500/70 hover:bg-slate-50 dark:hover:bg-slate-800/50'
                  }`}
                >
                  <Upload className="w-6 h-6 text-teal-600 dark:text-teal-400 animate-bounce" />
                  <div className="space-y-0.5">
                    <p className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                      点击选择本地图片
                    </p>
                    <p className="text-[10px] text-slate-500 dark:text-slate-400">
                      或将图片文件拖拽至此处
                    </p>
                  </div>
                  <span className="text-[9px] font-mono text-teal-600 dark:text-teal-400 bg-teal-100 dark:bg-teal-950 px-2 py-0.5 rounded-full">
                    PNG / JPG / WEBP / GIF
                  </span>
                </div>

                {/* Direct Image URL input */}
                <div className="space-y-1">
                  <label className="text-[11px] font-medium text-slate-600 dark:text-slate-400">
                    或粘贴图片网络 URL:
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="url"
                      placeholder="https://..."
                      value={urlInput}
                      onChange={(e) => setUrlInput(e.target.value)}
                      className="flex-1 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-1.5 text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:border-teal-500"
                    />
                    <button
                      onClick={() => {
                        if (urlInput.trim()) {
                          setTempAvatar(urlInput.trim());
                          setUrlInput('');
                        }
                      }}
                      disabled={!urlInput.trim()}
                      className="px-3 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-500 disabled:opacity-40 text-white text-xs font-medium transition-all"
                    >
                      使用
                    </button>
                  </div>
                </div>

              </div>
            </div>

            {/* Presets */}
            <div className="space-y-2 pt-2 border-t border-slate-200 dark:border-slate-800">
              <p className="text-[11px] font-mono text-slate-500 dark:text-slate-400">推荐 1:1 风格预设头像：</p>
              <div className="flex items-center gap-3 overflow-x-auto custom-scrollbar py-1">
                {[
                  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=300&auto=format&fit=crop',
                  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=300&auto=format&fit=crop',
                  'https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=300&auto=format&fit=crop',
                  'https://images.unsplash.com/photo-1517841905240-472988babdf9?q=80&w=300&auto=format&fit=crop',
                  'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?q=80&w=300&auto=format&fit=crop',
                ].map((presetUrl, idx) => (
                  <button
                    key={idx}
                    onClick={() => setTempAvatar(presetUrl)}
                    className={`w-10 h-10 rounded-xl overflow-hidden border-2 shrink-0 transition-transform hover:scale-110 ${
                      tempAvatar === presetUrl
                        ? 'border-teal-500 ring-2 ring-teal-500/50'
                        : 'border-slate-200 dark:border-slate-800'
                    }`}
                  >
                    <img src={presetUrl} alt="preset" className="w-full h-full object-cover aspect-square" />
                  </button>
                ))}
              </div>
            </div>

            {/* Modal Actions */}
            <div className="flex items-center justify-between pt-4 border-t border-slate-200 dark:border-slate-800">
              <button
                type="button"
                onClick={handleResetAvatar}
                className="px-4 py-2 rounded-xl text-xs font-mono text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors flex items-center gap-1.5"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>恢复默认头像</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setShowAvatarModal(false)}
                  className="px-4 py-2 rounded-xl text-xs text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                >
                  取消
                </button>
                <button
                  type="button"
                  onClick={handleSaveAvatar}
                  className="px-5 py-2 rounded-xl text-xs font-semibold text-white bg-gradient-to-r from-teal-600 to-indigo-600 hover:from-teal-500 hover:to-indigo-500 shadow-md transition-all flex items-center gap-1.5"
                >
                  <Check className="w-4 h-4" />
                  <span>保存为新头像</span>
                </button>
              </div>
            </div>

          </div>
        </div>
      )}
    </div>
  );
};
