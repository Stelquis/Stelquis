import React, { useState } from 'react';
import { ProjectItem } from '../../types';
import { CreateProjectModal } from '../modals/CreateProjectModal';
import { CategoryManagerModal } from '../modals/CategoryManagerModal';
import { SpotlightCard } from '../widgets/SpotlightCard';
import {
  FolderGit2,
  ExternalLink,
  Sparkles,
  Search,
  Filter,
  Layers,
  Cpu,
  Brain,
  Bot,
  Video,
  Clapperboard,
  CheckCircle2,
  Clock,
  Code2,
  X,
  Plus,
  Edit2,
  Trash2,
  Dna,
  Bug,
} from 'lucide-react';

interface ProjectsViewProps {
  projects: ProjectItem[];
  onAddProject?: (project: ProjectItem) => void;
  onUpdateProject?: (project: ProjectItem) => void;
  onDeleteProject?: (projectId: string) => void;
}

export const ProjectsView: React.FC<ProjectsViewProps> = ({
  projects,
  onAddProject,
  onUpdateProject,
  onDeleteProject,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('全部');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeProject, setActiveProject] = useState<ProjectItem | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showCategoryManagerModal, setShowCategoryManagerModal] = useState(false);
  const [editingProject, setEditingProject] = useState<ProjectItem | null>(null);

  const [projectCategoriesList, setProjectCategoriesList] = useState<string[]>([
    'AI Agent',
    '可视化分析',
    '算法&网络',
    '系统&安全',
    '分布式&爬虫',
    '生物信息',
  ]);

  const existingProjCats = projects.map((p) => p.category);
  const categories = Array.from(new Set(['全部', ...projectCategoriesList, ...existingProjCats]));

  const handleAddProjectCategory = (newCat: string) => {
    if (!projectCategoriesList.includes(newCat)) {
      setProjectCategoriesList((prev) => [...prev, newCat]);
    }
  };

  const handleRenameProjectCategory = (oldName: string, newName: string) => {
    setProjectCategoriesList((prev) => prev.map((c) => (c === oldName ? newName : c)));
    if (selectedCategory === oldName) setSelectedCategory(newName);
    projects.forEach((p) => {
      if (p.category === oldName && onUpdateProject) {
        onUpdateProject({ ...p, category: newName });
      }
    });
  };

  const handleDeleteProjectCategory = (catName: string) => {
    setProjectCategoriesList((prev) => prev.filter((c) => c !== catName));
    if (selectedCategory === catName) setSelectedCategory('全部');
    projects.forEach((p) => {
      if (p.category === catName && onUpdateProject) {
        onUpdateProject({ ...p, category: 'AI Agent' });
      }
    });
  };

  const getIconComponent = (iconName: ProjectItem['iconName']) => {
    switch (iconName) {
      case 'theater':
        return <Clapperboard className="w-5 h-5 text-amber-500 dark:text-amber-400" />;
      case 'video':
        return <Video className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />;
      case 'robot':
        return <Bot className="w-5 h-5 text-teal-600 dark:text-teal-400" />;
      case 'bird':
        return <Sparkles className="w-5 h-5 text-sky-600 dark:text-sky-400" />;
      case 'brain':
        return <Brain className="w-5 h-5 text-purple-600 dark:text-purple-400" />;
      case 'spider':
        return <Bug className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />;
      case 'gene':
        return <Dna className="w-5 h-5 text-rose-600 dark:text-rose-400" />;
      default:
        return <Cpu className="w-5 h-5 text-teal-600 dark:text-teal-400" />;
    }
  };

  const filteredProjects = (Array.isArray(projects) ? projects : []).filter((proj) => {
    if (!proj) return false;
    const matchesCategory =
      selectedCategory === '全部' || proj.category === selectedCategory;
    const matchesSearch =
      !searchQuery ||
      searchQuery.trim() === '' ||
      (proj.title && proj.title.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (proj.subtitle && proj.subtitle.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (proj.description && proj.description.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (proj.tags && Array.isArray(proj.tags) && proj.tags.some((t) => typeof t === 'string' && t.toLowerCase().includes(searchQuery.toLowerCase())));

    return matchesCategory && matchesSearch;
  });

  return (
    <div className="max-w-7xl xl:max-w-[1440px] 2xl:max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10 animate-fadeIn transition-colors duration-300">
      
      {/* Header Banner with Apple Glass */}
      <div className="relative bg-white/80 dark:bg-slate-900/90 backdrop-blur-xl border border-white/80 dark:border-slate-800/90 rounded-3xl p-6 sm:p-10 shadow-sm dark:shadow-2xl overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-teal-500/10 via-indigo-500/10 to-purple-600/10 blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-4 max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-500/10 dark:bg-teal-950/80 border border-teal-500/40 text-teal-700 dark:text-teal-300 text-xs font-mono">
              <FolderGit2 className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
              <span>NEBULATIDE LABS · 星星之火与工程矩阵</span>
            </div>

            <h1 className="text-3xl sm:text-4xl font-bold font-serif text-slate-900 dark:text-white tracking-tight leading-tight">
              星星之火：从第一性原理到星图交织
            </h1>

            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 font-light leading-relaxed">
              涵盖京剧剧本可视化（ChinaVis 2026）、ACM MM 算法挑战赛、生产级 CAD 问答 Agent、AI 同传、系统安全 Agent、分布式高并发爬虫与生物信息学深度图模型。支持使用快捷模版自由追加/修改您的工程项目。
            </p>

            {/* Key Metrics Strip */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4 border-t border-slate-200 dark:border-slate-800/80 font-mono text-xs">
              <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800/80">
                <span className="text-teal-600 dark:text-teal-400 font-bold block text-base">{projects.length} 个</span>
                <span className="text-slate-500 dark:text-slate-400 text-[11px]">硬核工程项目</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800/80">
                <span className="text-indigo-600 dark:text-indigo-400 font-bold block text-base">+45%</span>
                <span className="text-slate-500 dark:text-slate-400 text-[11px]">ACM竞赛得分</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800/80">
                <span className="text-purple-600 dark:text-purple-400 font-bold block text-base">93.1%</span>
                <span className="text-slate-500 dark:text-slate-400 text-[11px]">CAD问答准确率</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800/80">
                <span className="text-emerald-600 dark:text-emerald-400 font-bold block text-base">160,000+</span>
                <span className="text-slate-500 dark:text-slate-400 text-[11px]">分布式网页抓取</span>
              </div>
            </div>
          </div>

          {/* Add Project Button */}
          <div className="shrink-0">
            <button
              id="open-add-project-btn"
              onClick={() => {
                setEditingProject(null);
                setShowCreateModal(true);
              }}
              className="px-5 py-3 rounded-2xl font-semibold text-xs text-white bg-gradient-to-r from-teal-600 via-indigo-600 to-purple-600 hover:from-teal-500 hover:to-purple-500 transition-all shadow-md flex items-center gap-2 group hover:scale-[1.02]"
            >
              <Plus className="w-4 h-4 text-teal-200 group-hover:rotate-90 transition-transform" />
              <span>入驻新项目卡片 (含模版)</span>
            </button>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 pb-2 border-b border-slate-200 dark:border-slate-800/80">
        
        {/* Filter Badges */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-2 custom-scrollbar">
          <button
            onClick={() => setShowCategoryManagerModal(true)}
            className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-teal-500/60 hover:bg-slate-100 dark:hover:bg-slate-800 text-teal-600 dark:text-teal-400 shrink-0 transition-all flex items-center justify-center group shadow-sm mr-1"
            title="管理与编辑项目维度分类模版"
          >
            <Filter className="w-4 h-4 text-teal-600 dark:text-teal-400 group-hover:rotate-12 transition-transform" />
          </button>
          {categories.map((cat) => {
            const count = cat === '全部' ? projects.length : projects.filter((p) => p.category === cat).length;
            return (
              <button
                key={cat}
                id={`proj-cat-${cat}`}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3.5 py-1.5 rounded-full text-xs font-medium shrink-0 transition-all flex items-center gap-1.5 ${
                  selectedCategory === cat
                    ? 'bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-300 border border-teal-300 dark:border-teal-500/40 font-semibold shadow-sm'
                    : 'bg-white dark:bg-slate-900/60 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 border border-slate-200 dark:border-slate-800'
                }`}
              >
                <span>{cat}</span>
                <span
                  className={`text-[10px] font-mono px-1.5 py-0.2 rounded-full ${
                    selectedCategory === cat ? 'bg-teal-200 dark:bg-teal-900/80 text-teal-900 dark:text-teal-200' : 'bg-slate-200 dark:bg-slate-800 text-slate-500'
                  }`}
                >
                  {count}
                </span>
              </button>
            );
          })}
        </div>

        {/* Search Input */}
        <div className="relative shrink-0 w-full md:w-64">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            id="projects-search-input"
            type="text"
            placeholder="搜索项目名称、技术栈..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-white dark:bg-slate-900/80 border border-slate-200 dark:border-slate-800 rounded-full pl-9 pr-4 py-1.5 text-xs text-slate-900 dark:text-slate-200 placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:border-teal-500/60 shadow-inner"
          />
        </div>
      </div>

      {/* Projects Grid */}
      {filteredProjects.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4 gap-4 sm:gap-6">
          {filteredProjects.map((proj) => (
            <SpotlightCard
              key={proj.id}
              className="bg-white/80 dark:bg-slate-900 backdrop-blur-xl border border-slate-200/80 dark:border-slate-800 hover:border-teal-500/40 rounded-2xl p-6 transition-all duration-300 shadow-sm dark:shadow-md hover:shadow-xl dark:hover:shadow-teal-950/30 flex flex-col justify-between group relative overflow-hidden"
              spotlightColor="rgba(20, 184, 166, 0.15)"
            >
              {/* Top Subtle Gradient */}
              <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-teal-500 via-indigo-500 to-purple-500 opacity-0 group-hover:opacity-100 transition-opacity" />

              <div className="space-y-4">
                {/* Category & Time */}
                <div className="flex items-center justify-between text-xs">
                  <span className="px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 font-mono text-[11px]">
                    {proj.category}
                  </span>
                  <span className="flex items-center gap-1 text-slate-500 dark:text-slate-400 font-mono text-[11px]">
                    <Clock className="w-3 h-3 text-slate-400 dark:text-slate-500" />
                    {proj.period}
                  </span>
                </div>

                {/* Title and Icon */}
                <div className="flex items-start gap-3">
                  <div className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800/80 shrink-0 group-hover:border-teal-500/30 transition-colors">
                    {getIconComponent(proj.iconName)}
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-slate-900 dark:text-white group-hover:text-teal-600 dark:group-hover:text-teal-300 transition-colors font-serif">
                      {proj.title}
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 font-light mt-0.5">
                      {proj.subtitle}
                    </p>
                  </div>
                </div>

                {/* Description */}
                <p className="text-xs text-slate-700 dark:text-slate-300 font-light leading-relaxed line-clamp-3">
                  {proj.description}
                </p>

                {/* Key Highlights */}
                <div className="space-y-1.5 pt-2 border-t border-slate-200 dark:border-slate-800/60">
                  <span className="text-[10px] text-slate-400 font-mono uppercase tracking-wider block">
                    成果亮点
                  </span>
                  {proj.highlights.map((h, i) => (
                    <div key={i} className="flex items-center gap-1.5 text-xs text-teal-700 dark:text-teal-300/90">
                      <CheckCircle2 className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400 shrink-0" />
                      <span>{h}</span>
                    </div>
                  ))}
                </div>

                {/* Tags */}
                <div className="flex flex-wrap gap-1.5 pt-2">
                  {proj.tags.map((t) => (
                    <span
                      key={t}
                      className="px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-950 text-slate-600 dark:text-slate-400 text-[10px] font-mono border border-slate-200 dark:border-slate-800/60"
                    >
                      #{t}
                    </span>
                  ))}
                </div>
              </div>

              {/* Actions Footer */}
              <div className="pt-5 mt-5 border-t border-slate-200 dark:border-slate-800/80 flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <button
                    id={`view-details-${proj.id}`}
                    onClick={() => setActiveProject(proj)}
                    className="text-xs font-medium text-slate-700 dark:text-slate-300 hover:text-teal-600 dark:hover:text-teal-300 transition-colors flex items-center gap-1"
                  >
                    <Code2 className="w-3.5 h-3.5" />
                    <span>架构详情</span>
                  </button>

                  <button
                    title="编辑此项目"
                    onClick={() => {
                      setEditingProject(proj);
                      setShowCreateModal(true);
                    }}
                    className="p-1 rounded-lg text-slate-500 hover:text-teal-600 dark:hover:text-teal-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>

                  {onDeleteProject && (
                    <button
                      title="删除此项目"
                      onClick={() => onDeleteProject(proj.id)}
                      className="p-1 rounded-lg text-slate-500 hover:text-rose-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                <a
                  href={proj.repoUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3 py-1.5 rounded-xl text-xs font-semibold text-teal-800 dark:text-white bg-teal-50 dark:bg-slate-800 border border-teal-200 dark:border-slate-700 hover:bg-teal-600 hover:text-white dark:hover:bg-teal-600 transition-all flex items-center gap-1.5 shadow-sm"
                >
                  <span>访问 CNB / 源码</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </SpotlightCard>
          ))}
        </div>
      ) : (
        <div className="text-center py-16 bg-white/50 dark:bg-slate-900/40 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3">
          <Layers className="w-8 h-8 text-slate-400 dark:text-slate-600 mx-auto" />
          <p className="text-sm text-slate-500 dark:text-slate-400 font-light">未搜索到匹配的项目信息</p>
          <button
            onClick={() => {
              setSelectedCategory('全部');
              setSearchQuery('');
            }}
            className="text-xs text-teal-600 dark:text-teal-400 hover:underline"
          >
            重置项目筛选
          </button>
        </div>
      )}

      {/* Project Detail Modal */}
      {activeProject && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/20 dark:bg-slate-950/70 backdrop-blur-md animate-fadeIn transition-all"
          onClick={() => setActiveProject(null)}
        >
          <div
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-2xl w-full p-6 sm:p-8 space-y-6 relative shadow-2xl overflow-y-auto max-h-[90vh] custom-scrollbar text-slate-900 dark:text-slate-100"
            onClick={(e) => e.stopPropagation()}
          >
            
            {/* Close Button */}
            <button
              id="close-proj-modal"
              onClick={() => setActiveProject(null)}
              className="absolute top-5 right-5 p-2 rounded-full text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Modal Header */}
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <span className="px-3 py-1 rounded-full bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-300 border border-teal-300 dark:border-teal-500/30 text-xs font-mono">
                  {activeProject.category}
                </span>
                <span className="text-xs text-slate-500 dark:text-slate-400 font-mono">
                  {activeProject.period}
                </span>
              </div>
              <h2 className="text-2xl font-bold font-serif text-slate-900 dark:text-white flex items-center gap-2">
                {activeProject.title}
              </h2>
              <p className="text-sm text-teal-700 dark:text-teal-400 font-light">
                {activeProject.subtitle}
              </p>
            </div>

            {/* Content Section */}
            <div className="space-y-4 text-xs sm:text-sm text-slate-700 dark:text-slate-300 font-light leading-relaxed">
              <div className="p-4 bg-slate-50 dark:bg-slate-950/60 rounded-2xl border border-slate-200 dark:border-slate-800/80 space-y-2">
                <h4 className="font-semibold text-slate-900 dark:text-white font-serif flex items-center gap-1.5 text-xs text-teal-700 dark:text-teal-300">
                  <Sparkles className="w-4 h-4" /> 项目核心描述
                </h4>
                <p>{activeProject.description}</p>
              </div>

              {/* Highlights */}
              <div className="space-y-2">
                <h4 className="font-semibold text-slate-900 dark:text-white font-serif text-xs uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  核心战绩与数据突破
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {activeProject.highlights.map((item, idx) => (
                    <div key={idx} className="p-3 bg-slate-50 dark:bg-slate-950/80 rounded-xl border border-slate-200 dark:border-slate-800 text-xs flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-teal-600 dark:text-teal-400 shrink-0" />
                      <span className="text-slate-800 dark:text-slate-200">{item}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Philosophical Linkage */}
              <div className="p-4 bg-gradient-to-r from-teal-50 dark:from-teal-950/30 to-indigo-50 dark:to-indigo-950/30 border border-teal-300 dark:border-teal-500/30 rounded-2xl space-y-1">
                <span className="text-[11px] font-mono text-teal-700 dark:text-teal-400 block uppercase tracking-wider">
                  🌊 NebulaTide 哲学印记
                </span>
                <p className="text-xs italic text-slate-700 dark:text-slate-300">
                  “{activeProject.philosophicalLink}”
                </p>
              </div>

              {/* Tags */}
              <div className="flex flex-wrap gap-1.5 pt-2">
                {activeProject.tags.map((t) => (
                  <span key={t} className="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-950 text-slate-700 dark:text-slate-300 text-xs font-mono border border-slate-200 dark:border-slate-800">
                    #{t}
                  </span>
                ))}
              </div>
            </div>

            {/* Modal Footer */}
            <div className="pt-4 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <span className="text-xs text-slate-500 font-mono">
                代码仓库托管在 CNB Cool 平台的开源架构中
              </span>

              <a
                href={activeProject.repoUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="px-5 py-2 rounded-xl text-xs font-semibold text-white bg-gradient-to-r from-teal-600 to-indigo-600 hover:from-teal-500 hover:to-indigo-500 transition-all shadow-md flex items-center gap-1.5"
              >
                <span>前往 CNB 项目主页</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>

          </div>
        </div>
      )}

      {/* Create / Edit Project Modal */}
      {showCreateModal && (
        <CreateProjectModal
          onClose={() => {
            setShowCreateModal(false);
            setEditingProject(null);
          }}
          onAddProject={(newProj) => {
            if (onAddProject) onAddProject(newProj);
          }}
          existingProject={editingProject}
          onUpdateProject={(updated) => {
            if (onUpdateProject) onUpdateProject(updated);
          }}
        />
      )}

      {/* Category / Dimension Manager Modal */}
      {showCategoryManagerModal && (
        <CategoryManagerModal
          title="项目分类与工程维度模版"
          itemLabel="个工程项目"
          getItemCount={(catName) => projects.filter((p) => p.category === catName).length}
          categories={categories}
          onClose={() => setShowCategoryManagerModal(false)}
          onAddCategory={handleAddProjectCategory}
          onRenameCategory={handleRenameProjectCategory}
          onDeleteCategory={handleDeleteProjectCategory}
        />
      )}

    </div>
  );
};
