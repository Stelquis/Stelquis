import React, { useState } from 'react';
import { ThoughtFragment } from '../../types';
import { Sparkles, Heart, Star, Send, Cloud, Waves, Plus, Filter, Bot, Share2, Compass, Tag } from 'lucide-react';
import { AiAssistantModal } from '../modals/AiAssistantModal';
import { ShareCardModal } from '../modals/ShareCardModal';
import { CategoryManagerModal } from '../modals/CategoryManagerModal';
import { SpotlightCard } from '../widgets/SpotlightCard';

interface FragmentStreamProps {
  fragments: ThoughtFragment[];
  onAddFragment: (content: string, moodTag: ThoughtFragment['moodTag']) => void;
  onDeleteFragment?: (id: string) => void;
  onLikeFragment: (id: string) => void;
  onStarFragment: (id: string) => void;
}

export const FragmentStream: React.FC<FragmentStreamProps> = ({
  fragments,
  onAddFragment,
  onDeleteFragment,
  onLikeFragment,
  onStarFragment,
}) => {
  const [newContent, setNewContent] = useState('');
  const [selectedMood, setSelectedMood] = useState<string>('混沌');
  const [customMoodInput, setCustomMoodInput] = useState('');
  const [isCustomMood, setIsCustomMood] = useState(false);
  const [filterMood, setFilterMood] = useState<string>('all');
  const [showCategoryManagerModal, setShowCategoryManagerModal] = useState(false);

  const [customMoodTags, setCustomMoodTags] = useState<string[]>([
    '混沌',
    '微光',
    '潮汐',
    '珍珠',
    '暗流',
  ]);

  // AI & Share Modals
  const [isAiOpen, setIsAiOpen] = useState(false);
  const [shareData, setShareData] = useState<{ title: string; quote: string } | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newContent.trim()) return;
    const finalTag = (isCustomMood && customMoodInput.trim() ? customMoodInput.trim() : selectedMood) as ThoughtFragment['moodTag'];
    onAddFragment(newContent.trim(), finalTag);
    setNewContent('');
  };

  const handleAddMoodTag = (newTag: string) => {
    if (!customMoodTags.includes(newTag)) {
      setCustomMoodTags((prev) => [...prev, newTag]);
    }
  };

  const handleRenameMoodTag = (oldTag: string, newTag: string) => {
    setCustomMoodTags((prev) => prev.map((t) => (t === oldTag ? newTag : t)));
    if (filterMood === oldTag) setFilterMood(newTag);
    if (selectedMood === oldTag) setSelectedMood(newTag);
  };

  const handleDeleteMoodTag = (tagToDelete: string) => {
    setCustomMoodTags((prev) => prev.filter((t) => t !== tagToDelete));
    if (filterMood === tagToDelete) setFilterMood('all');
    if (selectedMood === tagToDelete) setSelectedMood('混沌');
  };

  const moodBadges: { tag: ThoughtFragment['moodTag']; color: string; icon: string }[] = [
    { tag: '混沌', color: 'bg-purple-100 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 border-purple-300 dark:border-purple-500/30', icon: '☁️' },
    { tag: '微光', color: 'bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border-amber-300 dark:border-amber-500/30', icon: '✨' },
    { tag: '潮汐', color: 'bg-teal-100 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 border-teal-300 dark:border-teal-500/30', icon: '🌊' },
    { tag: '珍珠', color: 'bg-indigo-100 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 border-indigo-300 dark:border-indigo-500/30', icon: '🐚' },
    { tag: '暗流', color: 'bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-300 dark:border-slate-600', icon: '🧭' },
  ];

  const filteredFragments = filterMood === 'all'
    ? fragments
    : fragments.filter((f) => f.moodTag === filterMood);

  return (
    <div className="max-w-4xl xl:max-w-5xl 2xl:max-w-6xl mx-auto px-4 sm:px-6 py-8 space-y-10 transition-colors duration-300">
      
      {/* Intro Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-2 text-center sm:text-left">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/10 dark:bg-purple-950/60 border border-purple-500/30 text-purple-700 dark:text-purple-300 text-xs font-mono">
            <Cloud className="w-3.5 h-3.5 text-purple-600 dark:text-purple-400" />
            <span>CHAPTER I · 星云碎片与混沌流控</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold font-serif text-slate-900 dark:text-white tracking-tight">
            星云碎片 (Thought Stream)
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 font-light">
            “思绪初生时，从来不是条理分明的。停下来，让雾气停留一会儿。”
          </p>
        </div>

        {/* AI Assistant Button */}
        <button
          onClick={() => setIsAiOpen(true)}
          className="self-center sm:self-auto px-4 py-2 rounded-xl text-xs font-semibold text-teal-800 dark:text-teal-200 bg-teal-50 dark:bg-teal-950/80 border border-teal-300 dark:border-teal-500/40 hover:bg-teal-100 dark:hover:bg-teal-900 transition-all flex items-center gap-2 shadow-sm"
        >
          <Bot className="w-4 h-4 text-teal-600 dark:text-teal-400" />
          <span>AI 降熵助手</span>
        </button>
      </div>

      {/* Quick Input Incubator Card with Apple Glass */}
      <div className="bg-white/80 dark:bg-slate-900 border border-white/80 dark:border-slate-800 rounded-2xl p-5 sm:p-6 shadow-sm dark:shadow-xl relative overflow-hidden backdrop-blur-xl">
        <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-200 dark:border-slate-800">
          <span className="text-xs font-semibold text-teal-700 dark:text-teal-300 flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-teal-600 dark:text-teal-400 animate-pulse" /> 倾泻你的混沌思绪
          </span>
          <span className="text-[11px] font-mono text-slate-400 dark:text-slate-500">不用整理 · 随性而记</span>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <textarea
            id="fragment-input-text"
            rows={3}
            placeholder="在此倾泻未整理的断句、深夜灵感、甚至是一丝困惑... 雾气会在星云中凝结。"
            value={newContent}
            onChange={(e) => setNewContent(e.target.value)}
            className="w-full bg-slate-50 dark:bg-slate-950/80 border border-slate-200 dark:border-slate-800 rounded-xl p-3.5 text-sm text-slate-900 dark:text-slate-200 placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:border-teal-500/60 resize-none font-light shadow-inner"
          />

          <div className="flex flex-wrap items-center justify-between gap-3">
            {/* Mood selector */}
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-xs text-slate-500 dark:text-slate-400 mr-1">心境标记:</span>
              {moodBadges.map((badge) => (
                <button
                  type="button"
                  key={badge.tag}
                  id={`mood-select-${badge.tag}`}
                  onClick={() => {
                    setSelectedMood(badge.tag);
                    setIsCustomMood(false);
                  }}
                  className={`px-2.5 py-1 rounded-full text-xs border transition-all flex items-center gap-1 ${
                    !isCustomMood && selectedMood === badge.tag
                      ? `${badge.color} ring-1 ring-teal-400 font-semibold`
                      : 'bg-slate-100 dark:bg-slate-950/50 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-800 hover:text-slate-900 dark:hover:text-slate-200'
                  }`}
                >
                  <span>{badge.icon}</span>
                  <span>{badge.tag}</span>
                </button>
              ))}

              <button
                type="button"
                onClick={() => setIsCustomMood(!isCustomMood)}
                className="px-2.5 py-1 rounded-full text-xs font-mono text-teal-700 dark:text-teal-400 border border-teal-300 dark:border-teal-500/30 bg-teal-50 dark:bg-teal-950/30 hover:bg-teal-100 dark:hover:bg-teal-950/60"
              >
                {isCustomMood ? '取消自定义' : '+ 自定义'}
              </button>

              {isCustomMood && (
                <input
                  type="text"
                  placeholder="例: 火花/顿悟"
                  value={customMoodInput}
                  onChange={(e) => setCustomMoodInput(e.target.value)}
                  className="bg-white dark:bg-slate-950 border border-teal-500/50 text-teal-700 dark:text-teal-200 text-xs px-2.5 py-1 rounded-full focus:outline-none w-24"
                />
              )}
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setIsAiOpen(true)}
                className="px-3 py-1.5 rounded-xl text-xs font-medium text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 transition-all flex items-center gap-1"
                title="呼唤 AI 进行表达润色或标签提炼"
              >
                <Bot className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                <span>润色</span>
              </button>

              {/* Submit button */}
              <button
                id="submit-thought-btn"
                type="submit"
                disabled={!newContent.trim()}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-white bg-gradient-to-r from-teal-600 to-indigo-600 hover:from-teal-500 hover:to-indigo-500 disabled:opacity-40 disabled:cursor-not-allowed transition-all flex items-center gap-1.5 shadow-md"
              >
                <Send className="w-3.5 h-3.5" />
                <span>记入星云</span>
              </button>
            </div>
          </div>
        </form>
      </div>

      {/* Filter Tabs with Interactive Filter Button */}
      <div className="flex items-center gap-1.5 overflow-x-auto custom-scrollbar border-b border-slate-200 dark:border-slate-800/80 pb-3">
        <button
          onClick={() => setShowCategoryManagerModal(true)}
          className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-teal-500/60 hover:bg-slate-100 dark:hover:bg-slate-800 text-teal-600 dark:text-teal-400 shrink-0 transition-all flex items-center justify-center group shadow-sm mr-1"
          title="管理与编辑心境/思绪标签模版"
        >
          <Filter className="w-4 h-4 text-teal-600 dark:text-teal-400 group-hover:rotate-12 transition-transform" />
        </button>
        <button
          id="filter-mood-all"
            onClick={() => setFilterMood('all')}
            className={`px-3 py-1 rounded-full text-xs font-medium transition-colors flex items-center gap-1.5 ${
              filterMood === 'all'
                ? 'bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-300 border border-teal-300 dark:border-teal-500/30 font-semibold'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            <span>全部</span>
            <span className="text-[10px] font-mono px-1.5 py-0.2 rounded-full bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
              {fragments.length}
            </span>
          </button>
          {customMoodTags.map((tag) => {
            const count = fragments.filter((f) => f.moodTag === tag).length;
            const badge = moodBadges.find((b) => b.tag === tag);
            const icon = badge ? badge.icon : '🏷️';
            return (
              <button
                key={tag}
                id={`filter-mood-${tag}`}
                onClick={() => setFilterMood(tag)}
                className={`px-3 py-1 rounded-full text-xs font-medium transition-all flex items-center gap-1.5 ${
                  filterMood === tag
                    ? 'bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-300 border border-teal-300 dark:border-teal-500/40 font-semibold shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 bg-slate-100 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800'
                }`}
              >
                <span>
                  {icon} {tag}
                </span>
                <span
                  className={`text-[10px] font-mono px-1.5 py-0.2 rounded-full ${
                    filterMood === tag ? 'bg-teal-200 dark:bg-teal-900/80 text-teal-900 dark:text-teal-200' : 'bg-slate-200 dark:bg-slate-800 text-slate-500'
                  }`}
                >
                  {count}
                </span>
              </button>
            );
          })}
      </div>

      {/* Fragments Stream Grid */}
      <div className="space-y-4">
        {filteredFragments.map((fragment) => {
          const badge = moodBadges.find((b) => b.tag === fragment.moodTag) || moodBadges[0];
          return (
            <SpotlightCard
              key={fragment.id}
              id={`fragment-card-${fragment.id}`}
              className="bg-white/80 dark:bg-slate-900 backdrop-blur-xl border border-slate-200/80 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700/80 rounded-2xl p-5 shadow-sm transition-all duration-300 space-y-3"
              spotlightColor="rgba(168, 85, 247, 0.12)"
            >
              <div className="flex items-center justify-between text-xs">
                <span className={`px-2.5 py-0.5 rounded-full border text-[10px] font-mono flex items-center gap-1 ${badge.color}`}>
                  <span>{badge.icon}</span>
                  <span>{fragment.moodTag}</span>
                </span>
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-mono text-slate-400 dark:text-slate-500">{fragment.createdAt}</span>
                  {onDeleteFragment && (
                    <button
                      onClick={() => onDeleteFragment(fragment.id)}
                      className="text-slate-400 hover:text-rose-500 p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                      title="删除此思绪碎片"
                    >
                      <span className="text-xs">🗑️</span>
                    </button>
                  )}
                </div>
              </div>

              <p className="text-sm text-slate-800 dark:text-slate-200 font-light leading-relaxed whitespace-pre-line font-serif">
                {fragment.content}
              </p>

              <div className="pt-2 border-t border-slate-200 dark:border-slate-800/60 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                <div className="flex items-center gap-3">
                  <button
                    id={`star-fragment-${fragment.id}`}
                    onClick={() => onStarFragment(fragment.id)}
                    className={`flex items-center gap-1.5 transition-colors ${
                      fragment.isStarred ? 'text-amber-500 font-semibold' : 'hover:text-amber-500'
                    }`}
                  >
                    <Star className={`w-3.5 h-3.5 ${fragment.isStarred ? 'fill-current text-amber-500' : ''}`} />
                    <span>{fragment.isStarred ? '已精选沉淀' : '标记微光'}</span>
                  </button>

                  <button
                    id={`like-fragment-${fragment.id}`}
                    onClick={() => onLikeFragment(fragment.id)}
                    className="flex items-center gap-1.5 hover:text-rose-500 transition-colors"
                  >
                    <Heart className="w-3.5 h-3.5 fill-current text-slate-400 dark:text-slate-500 hover:text-rose-500" />
                    <span>{fragment.likes}</span>
                  </button>
                </div>

                <button
                  onClick={() => setShareData({ title: '星云思绪碎片', quote: fragment.content })}
                  className="flex items-center gap-1 hover:text-teal-600 dark:hover:text-teal-300 transition-colors text-[11px]"
                >
                  <Share2 className="w-3.5 h-3.5" />
                  <span>生成金句卡</span>
                </button>
              </div>
            </SpotlightCard>
          );
        })}
      </div>

      {/* AI Assistant Modal */}
      <AiAssistantModal
        isOpen={isAiOpen}
        onClose={() => setIsAiOpen(false)}
        initialText={newContent}
        onApplyText={(polishedText) => setNewContent(polishedText)}
      />

      {/* Share Card Modal */}
      {shareData && (
        <ShareCardModal
          isOpen={!!shareData}
          onClose={() => setShareData(null)}
          title={shareData.title}
          quoteOrExcerpt={shareData.quote}
        />
      )}

      {/* Mood Tag Category Manager Modal */}
      {showCategoryManagerModal && (
        <CategoryManagerModal
          title="心境标记与思绪维度管理"
          itemLabel="条星云碎片"
          getItemCount={(tagName) => fragments.filter((f) => f.moodTag === tagName).length}
          categories={['all', ...customMoodTags]}
          onClose={() => setShowCategoryManagerModal(false)}
          onAddCategory={handleAddMoodTag}
          onRenameCategory={handleRenameMoodTag}
          onDeleteCategory={handleDeleteMoodTag}
        />
      )}

    </div>
  );
};
