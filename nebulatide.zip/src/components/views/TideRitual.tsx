import React, { useState } from 'react';
import { TideReview, WeavingGoal, ShellItem } from '../../types';
import { Compass, Waves, Sparkles, Plus, CheckCircle2, ArrowRight, Anchor, ChevronRight, Flame, Filter, Tag } from 'lucide-react';
import { ActivityHeatmap } from '../widgets/ActivityHeatmap';
import { GlowingShellsCard } from '../widgets/GlowingShellsCard';
import { CategoryManagerModal } from '../modals/CategoryManagerModal';
import { InteractiveNebulaGrid, NebulaNode, NebulaLink } from '../widgets/InteractiveNebulaGrid';

interface TideRitualProps {
  reviews: TideReview[];
  weavingGoals: WeavingGoal[];
  onAddReview: (review: Omit<TideReview, 'id' | 'createdAt'>) => void;
  onDeleteReview?: (id: string) => void;
  onAddWeavingGoal: (goal: Omit<WeavingGoal, 'id'>) => void;
  onToggleGoalStatus: (id: string) => void;
  onDeleteGoal?: (id: string) => void;
}

export const TideRitual: React.FC<TideRitualProps> = ({
  reviews,
  weavingGoals,
  onAddReview,
  onDeleteReview,
  onAddWeavingGoal,
  onToggleGoalStatus,
  onDeleteGoal,
}) => {
  const [activeTab, setActiveTab] = useState<'review' | 'weaving'>('review');
  const [showReviewWizard, setShowReviewWizard] = useState(false);
  const [showGoalModal, setShowGoalModal] = useState(false);
  const [showCategoryManagerModal, setShowCategoryManagerModal] = useState(false);
  const [selectedDirectionFilter, setSelectedDirectionFilter] = useState<string>('全部');

  const [directionList, setDirectionList] = useState<string[]>([
    '探索与创作',
    '算法攻坚',
    '系统重构',
    '心智升级',
  ]);

  const handleAddDirection = (newDir: string) => {
    if (!directionList.includes(newDir)) {
      setDirectionList((prev) => [...prev, newDir]);
    }
  };

  const handleRenameDirection = (oldDir: string, newDir: string) => {
    setDirectionList((prev) => prev.map((d) => (d === oldDir ? newDir : d)));
    if (selectedDirectionFilter === oldDir) setSelectedDirectionFilter(newDir);
    if (direction === oldDir) setDirection(newDir);
  };

  const handleDeleteDirection = (dirToDelete: string) => {
    setDirectionList((prev) => prev.filter((d) => d !== dirToDelete));
    if (selectedDirectionFilter === dirToDelete) setSelectedDirectionFilter('全部');
    if (direction === dirToDelete) setDirection('探索与创作');
  };

  // Review wizard state
  const [reviewTitle, setReviewTitle] = useState('');
  const [dateRange, setDateRange] = useState('');
  const [highTideInput, setHighTideInput] = useState('');
  const [highTideWins, setHighTideWins] = useState<string[]>([]);
  
  const [shellTitle, setShellTitle] = useState('');
  const [shellDesc, setShellDesc] = useState('');
  const [shellType, setShellType] = useState<ShellItem['type']>('learning');
  const [shells, setShells] = useState<ShellItem[]>([]);
  
  const [insightPearl, setInsightPearl] = useState('');

  // Weaving modal state
  const [goalTitle, setGoalTitle] = useState('');
  const [direction, setDirection] = useState('探索与创作');
  const [flowLevel, setFlowLevel] = useState<WeavingGoal['flowLevel']>('高能涨潮');

  const handleAddHighTide = () => {
    if (highTideInput.trim()) {
      setHighTideWins([...highTideWins, highTideInput.trim()]);
      setHighTideInput('');
    }
  };

  const handleAddShell = () => {
    if (shellTitle.trim() && shellDesc.trim()) {
      const newShell: ShellItem = {
        id: `shell-${Date.now()}`,
        title: shellTitle.trim(),
        description: shellDesc.trim(),
        type: shellType,
        date: new Date().toLocaleDateString('zh-CN', { month: '2-digit', day: '2-digit' }),
      };
      setShells([...shells, newShell]);
      setShellTitle('');
      setShellDesc('');
    }
  };

  const handleSaveReview = () => {
    if (!reviewTitle.trim() || !insightPearl.trim()) return;
    onAddReview({
      title: reviewTitle.trim(),
      dateRange: dateRange.trim() || '近期周期',
      highTideWins,
      lowTideLearnings: shells,
      insightPearl: insightPearl.trim(),
    });

    // Reset wizard
    setReviewTitle('');
    setDateRange('');
    setHighTideWins([]);
    setShells([]);
    setInsightPearl('');
    setShowReviewWizard(false);
  };

  const handleSaveGoal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!goalTitle.trim()) return;
    onAddWeavingGoal({
      title: goalTitle.trim(),
      direction,
      flowLevel,
      status: 'in_flow',
      shellsLinked: [],
    });
    setGoalTitle('');
    setShowGoalModal(false);
  };

  // Map weaving goals to interactive nebula nodes
  const customNebulaNodes: NebulaNode[] = weavingGoals.map((g) => ({
    id: g.id,
    label: g.title,
    category: g.direction,
    val: g.status === 'completed' ? 14 : 10,
    status: g.status,
  }));

  const customNebulaLinks: NebulaLink[] = [];
  for (let i = 0; i < customNebulaNodes.length; i++) {
    for (let j = i + 1; j < customNebulaNodes.length; j++) {
      if (
        customNebulaNodes[i].category === customNebulaNodes[j].category ||
        j === i + 1
      ) {
        customNebulaLinks.push({
          source: customNebulaNodes[i].id,
          target: customNebulaNodes[j].id,
        });
      }
    }
  }

  return (
    <div className="max-w-5xl xl:max-w-6xl 2xl:max-w-[1500px] mx-auto px-4 sm:px-6 py-8 space-y-10 transition-colors duration-300">
      
      {/* Intro Banner */}
      <div className="text-center space-y-3">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-teal-500/10 dark:bg-teal-950/60 border border-teal-500/30 text-teal-700 dark:text-teal-300 text-xs font-mono">
          <Compass className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
          <span>CHAPTER II & III · 潮汐复盘与顺势织网</span>
        </div>
        <h2 className="text-2xl sm:text-4xl font-bold font-serif text-slate-900 dark:text-white tracking-tight">
          潮汐仪式 (Tide Rituals)
        </h2>
        <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 font-light max-w-xl mx-auto">
          “涨潮时向外奔涌，试错碰撞；退潮时弯腰捡拾，让贝壳显形。规划不是地图，而是感受流向的能力。”
        </p>

        {/* Mode Selector Switch */}
        <div className="inline-flex p-1 bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-full mt-4 shadow-inner">
          <button
            id="tab-ritual-review"
            onClick={() => setActiveTab('review')}
            className={`px-5 py-2 rounded-full text-xs font-semibold transition-all flex items-center gap-2 ${
              activeTab === 'review'
                ? 'bg-gradient-to-r from-teal-600 to-indigo-600 text-white shadow-md'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            <Waves className="w-3.5 h-3.5" /> 退潮拾贝复盘 ({reviews.length})
          </button>
          <button
            id="tab-ritual-weaving"
            onClick={() => setActiveTab('weaving')}
            className={`px-5 py-2 rounded-full text-xs font-semibold transition-all flex items-center gap-2 ${
              activeTab === 'weaving'
                ? 'bg-gradient-to-r from-teal-600 to-indigo-600 text-white shadow-md'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" /> 顺势织网规划 ({weavingGoals.length})
          </button>
        </div>
      </div>

      {/* SECTION A: RETROSPECTIVE REVIEWS */}
      {activeTab === 'review' && (
        <div className="space-y-6">
          {/* 365-Day Activity & Tide Energy Heatmap */}
          <ActivityHeatmap
            onSelectDate={(dateStr) => {
              setReviewTitle(`${dateStr} 潮汐日记与复盘`);
              setDateRange(dateStr);
              setShowReviewWizard(true);
            }}
          />

          {/* Glowing Shells Interactive Collection */}
          <GlowingShellsCard />

          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100 font-serif">退潮捡贝壳日志</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">记录浪潮退去后的惊喜与沉淀智慧</p>
            </div>
            <button
              id="open-review-wizard-btn"
              onClick={() => setShowReviewWizard(true)}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-white bg-teal-600 hover:bg-teal-500 transition-all shadow-md flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>开启本次潮汐复盘</span>
            </button>
          </div>

          {/* Reviews List with Apple Glass */}
          <div className="space-y-6">
            {reviews.map((rev) => (
              <div
                key={rev.id}
                className="bg-white/80 dark:bg-slate-900 border border-white/80 dark:border-slate-800 rounded-2xl p-6 shadow-sm dark:shadow-xl space-y-6 backdrop-blur-xl"
              >
                <div className="flex flex-wrap items-center justify-between gap-2 pb-4 border-b border-slate-200 dark:border-slate-800">
                  <div className="flex items-center gap-2">
                    <Anchor className="w-4 h-4 text-teal-600 dark:text-teal-400" />
                    <h4 className="text-base font-bold text-slate-900 dark:text-white font-serif">{rev.title}</h4>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-xs font-mono text-teal-800 dark:text-teal-300 bg-teal-100 dark:bg-teal-950/80 px-3 py-1 rounded-full border border-teal-300 dark:border-teal-500/20">
                      周期: {rev.dateRange}
                    </span>
                    {onDeleteReview && (
                      <button
                        onClick={() => onDeleteReview(rev.id)}
                        className="text-slate-400 hover:text-rose-500 p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                        title="删除此复盘记录"
                      >
                        <span className="text-xs">🗑️</span>
                      </button>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* High tide wins */}
                  <div className="bg-slate-50 dark:bg-slate-950/60 p-4 rounded-xl border border-slate-200 dark:border-slate-800/80 space-y-2">
                    <span className="text-xs font-semibold text-teal-700 dark:text-teal-400 flex items-center gap-1.5">
                      <Waves className="w-3.5 h-3.5" /> 涨潮奔涌 (尝试与拓展)
                    </span>
                    <ul className="space-y-1.5 text-xs text-slate-700 dark:text-slate-300">
                      {rev.highTideWins.map((win, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <span className="text-teal-600 dark:text-teal-400">▪</span>
                          <span>{win}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Low tide shells */}
                  <div className="bg-slate-50 dark:bg-slate-950/60 p-4 rounded-xl border border-slate-200 dark:border-slate-800/80 space-y-2">
                    <span className="text-xs font-semibold text-indigo-700 dark:text-indigo-400 flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5" /> 退潮贝壳 (收获与经验)
                    </span>
                    <div className="space-y-2">
                      {rev.lowTideLearnings.map((shell) => (
                        <div key={shell.id} className="p-2.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs">
                          <div className="font-semibold text-slate-900 dark:text-slate-200">{shell.title}</div>
                          <div className="text-slate-500 dark:text-slate-400 text-[11px] mt-0.5">{shell.description}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Insight Pearl */}
                <div className="p-4 rounded-xl bg-gradient-to-r from-teal-50 dark:from-teal-950/40 to-indigo-50 dark:to-indigo-950/40 border border-teal-300 dark:border-teal-500/30 text-xs text-slate-800 dark:text-slate-200 space-y-1">
                  <span className="font-mono text-[11px] text-teal-700 dark:text-teal-400 block font-semibold">
                    🐚 凝结的认知珍珠
                  </span>
                  <p className="italic font-serif text-sm">“{rev.insightPearl}”</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SECTION B: WEAVING GOALS */}
      {activeTab === 'weaving' && (
        <div className="space-y-6">
          {/* Interactive Force-Directed Nebula Grid Component */}
          <InteractiveNebulaGrid
            nodes={customNebulaNodes.length > 0 ? customNebulaNodes : undefined}
            links={customNebulaLinks.length > 0 ? customNebulaLinks : undefined}
            title="动态航星节点拓扑星图"
            subtitle="拖拽或点击航星节点，触发引力拓扑与能量脉冲光束"
          />

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-2">
            <div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100 font-serif">顺势织网目标矩阵</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">将拾得的贝壳串联，编织自适应发展罗盘</p>
            </div>
            <button
              id="open-goal-modal-btn"
              onClick={() => setShowGoalModal(true)}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 transition-all shadow-md flex items-center gap-1.5 self-start sm:self-auto"
            >
              <Plus className="w-4 h-4" />
              <span>编织新航行节点</span>
            </button>
          </div>

          {/* Direction Filter Bar */}
          <div className="flex items-center gap-1.5 overflow-x-auto custom-scrollbar border-b border-slate-200 dark:border-slate-800 pb-3">
            <button
              onClick={() => setShowCategoryManagerModal(true)}
              className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-teal-500/60 hover:bg-slate-100 dark:hover:bg-slate-800 text-teal-600 dark:text-teal-400 shrink-0 transition-all flex items-center justify-center group shadow-sm mr-1"
              title="管理与编辑织网方向维度模版"
            >
              <Filter className="w-4 h-4 text-teal-600 dark:text-teal-400 group-hover:rotate-12 transition-transform" />
            </button>
            <button
              onClick={() => setSelectedDirectionFilter('全部')}
              className={`px-3 py-1 rounded-full text-xs font-medium transition-colors ${
                selectedDirectionFilter === '全部'
                  ? 'bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-300 border border-teal-300 dark:border-teal-500/30 font-semibold'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              全部
            </button>
            {directionList.map((dir) => (
              <button
                key={dir}
                onClick={() => setSelectedDirectionFilter(dir)}
                className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
                  selectedDirectionFilter === dir
                    ? 'bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-300 border border-teal-300 dark:border-teal-500/40 font-semibold shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 bg-slate-100 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800'
                }`}
              >
                {dir}
              </button>
            ))}
          </div>

          {/* Goals List */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
            {weavingGoals
              .filter((g) => selectedDirectionFilter === '全部' || g.direction === selectedDirectionFilter)
              .map((goal) => (
                <div
                  key={goal.id}
                  className={`p-5 rounded-2xl border transition-all duration-300 space-y-4 backdrop-blur-xl ${
                    goal.status === 'completed'
                      ? 'bg-slate-100/80 dark:bg-slate-950/40 border-slate-300 dark:border-slate-800/60 opacity-80'
                      : 'bg-white/80 dark:bg-slate-900 border-white/80 dark:border-slate-800 hover:border-teal-500/40 shadow-sm dark:shadow-xl'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-950 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-800">
                        {goal.direction}
                      </span>
                      <h4
                        className={`text-base font-bold font-serif mt-2 ${
                          goal.status === 'completed' ? 'line-through text-slate-400' : 'text-slate-900 dark:text-white'
                        }`}
                      >
                        {goal.title}
                      </h4>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => onToggleGoalStatus(goal.id)}
                        className={`p-1.5 rounded-xl border transition-all ${
                          goal.status === 'completed'
                            ? 'bg-teal-500/20 text-teal-600 dark:text-teal-300 border-teal-500/40'
                            : 'bg-slate-100 dark:bg-slate-950 text-slate-400 border-slate-300 dark:border-slate-800 hover:text-teal-600 dark:hover:text-teal-300'
                        }`}
                        title={goal.status === 'completed' ? '重置为推进中' : '标记为已结出珍珠'}
                      >
                        <CheckCircle2 className="w-4 h-4" />
                      </button>
                      {onDeleteGoal && (
                        <button
                          onClick={() => onDeleteGoal(goal.id)}
                          className="p-1.5 rounded-xl text-slate-400 hover:text-rose-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                          title="删除此航行节点"
                        >
                          <span className="text-xs">🗑️</span>
                        </button>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 pt-2 border-t border-slate-200 dark:border-slate-800/80">
                    <span className="font-mono text-[11px] text-teal-700 dark:text-teal-400 flex items-center gap-1">
                      <Flame className="w-3.5 h-3.5" /> 能级: {goal.flowLevel}
                    </span>
                    <span className="text-[11px] font-mono">
                      {goal.status === 'completed' ? '✨ 已沉淀成精选' : '🌊 顺势流动中'}
                    </span>
                  </div>
                </div>
              ))}
          </div>
        </div>
      )}

      {/* Review Wizard Modal */}
      {showReviewWizard && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/20 dark:bg-slate-950/70 backdrop-blur-md animate-fadeIn transition-all"
          onClick={() => setShowReviewWizard(false)}
        >
          <div
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-2xl w-full p-6 sm:p-8 space-y-6 relative shadow-2xl overflow-y-auto max-h-[90vh] custom-scrollbar text-slate-900 dark:text-slate-100"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
              <h3 className="text-lg font-bold font-serif text-slate-900 dark:text-white flex items-center gap-2">
                <Compass className="w-5 h-5 text-teal-600 dark:text-teal-400" />
                <span>开启退潮拾贝复盘仪式</span>
              </h3>
              <button
                onClick={() => setShowReviewWizard(false)}
                className="text-slate-400 hover:text-slate-900 dark:hover:text-white text-sm"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4 text-xs sm:text-sm">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <input
                  type="text"
                  placeholder="复盘主题 (例: 2026年7月第四周思考复盘)"
                  value={reviewTitle}
                  onChange={(e) => setReviewTitle(e.target.value)}
                  className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-900 dark:text-slate-200 focus:outline-none focus:border-teal-500"
                />
                <input
                  type="text"
                  placeholder="时间周期 (例: 2026.07.20 - 07.25)"
                  value={dateRange}
                  onChange={(e) => setDateRange(e.target.value)}
                  className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-900 dark:text-slate-200 focus:outline-none focus:border-teal-500"
                />
              </div>

              {/* High Tide Wins */}
              <div className="space-y-2">
                <label className="font-semibold text-teal-700 dark:text-teal-300 block">1. 涨潮奔涌 (记录尝试与成就):</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="例: 上线中国京剧剧本可视化网页..."
                    value={highTideInput}
                    onChange={(e) => setHighTideInput(e.target.value)}
                    className="flex-1 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2 text-slate-900 dark:text-slate-200 focus:outline-none"
                  />
                  <button
                    onClick={handleAddHighTide}
                    type="button"
                    className="px-3 py-2 rounded-xl bg-teal-600 text-white font-semibold text-xs"
                  >
                    + 添加
                  </button>
                </div>
                {highTideWins.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {highTideWins.map((w, idx) => (
                      <span key={idx} className="bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-200 px-2.5 py-1 rounded-lg text-xs border border-teal-300 dark:border-teal-500/30">
                        ✓ {w}
                      </span>
                    ))}
                  </div>
                )}
              </div>

              {/* Low Tide Shells */}
              <div className="space-y-2 pt-2 border-t border-slate-200 dark:border-slate-800">
                <label className="font-semibold text-indigo-700 dark:text-indigo-300 block">2. 退潮捡贝壳 (记录经验与洞察):</label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <input
                    type="text"
                    placeholder="贝壳标题"
                    value={shellTitle}
                    onChange={(e) => setShellTitle(e.target.value)}
                    className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2 text-slate-900 dark:text-slate-200 focus:outline-none"
                  />
                  <input
                    type="text"
                    placeholder="贝壳体会与描述"
                    value={shellDesc}
                    onChange={(e) => setShellDesc(e.target.value)}
                    className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2 text-slate-900 dark:text-slate-200 focus:outline-none"
                  />
                </div>
                <button
                  onClick={handleAddShell}
                  type="button"
                  className="w-full py-2 rounded-xl bg-indigo-600 text-white font-semibold text-xs"
                >
                  + 记录存入贝壳库
                </button>
                {shells.length > 0 && (
                  <div className="space-y-1 pt-1">
                    {shells.map((s) => (
                      <div key={s.id} className="p-2 bg-slate-100 dark:bg-slate-950 rounded-lg text-xs flex justify-between">
                        <span>🐚 {s.title}: {s.description}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Pearl */}
              <div className="space-y-2 pt-2 border-t border-slate-200 dark:border-slate-800">
                <label className="font-semibold text-amber-600 dark:text-amber-300 block">3. 凝结的认知珍珠 (最关键的底线认识):</label>
                <textarea
                  rows={2}
                  placeholder="例: 代码越复杂，边界越要保持第一性原理的极简..."
                  value={insightPearl}
                  onChange={(e) => setInsightPearl(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl p-3 text-slate-900 dark:text-slate-200 focus:outline-none"
                />
              </div>
            </div>

            <div className="pt-4 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">
              <button
                onClick={() => setShowReviewWizard(false)}
                className="px-4 py-2 rounded-xl text-xs font-medium text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-slate-800"
              >
                取消
              </button>
              <button
                onClick={handleSaveReview}
                disabled={!reviewTitle.trim() || !insightPearl.trim()}
                className="px-5 py-2 rounded-xl text-xs font-semibold text-white bg-gradient-to-r from-teal-600 to-indigo-600 disabled:opacity-40"
              >
                完成并归档复盘
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Weaving Modal */}
      {showGoalModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/20 dark:bg-slate-950/70 backdrop-blur-md animate-fadeIn transition-all"
          onClick={() => setShowGoalModal(false)}
        >
          <div
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-md w-full p-6 space-y-5 relative shadow-2xl text-slate-900 dark:text-slate-100"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="text-lg font-bold font-serif text-slate-900 dark:text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
              <span>编织新航行节点</span>
            </h3>

            <form onSubmit={handleSaveGoal} className="space-y-4 text-xs sm:text-sm">
              <div className="space-y-1">
                <label className="text-slate-600 dark:text-slate-400 font-medium">节点名称</label>
                <input
                  type="text"
                  placeholder="例: 构建基于 Gemini 的自适应 Agent 调度框架"
                  value={goalTitle}
                  onChange={(e) => setGoalTitle(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-900 dark:text-slate-200 focus:outline-none focus:border-indigo-500"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-600 dark:text-slate-400 font-medium">织网方向维度</label>
                <select
                  value={direction}
                  onChange={(e) => setDirection(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-900 dark:text-slate-200 focus:outline-none"
                >
                  {directionList.map((d) => (
                    <option key={d} value={d}>
                      {d}
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-slate-600 dark:text-slate-400 font-medium">心流与能级匹配</label>
                <select
                  value={flowLevel}
                  onChange={(e) => setFlowLevel(e.target.value as WeavingGoal['flowLevel'])}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-900 dark:text-slate-200 focus:outline-none"
                >
                  <option value="高能涨潮">高能涨潮 (高度专注与创新攻坚)</option>
                  <option value="平缓流淌">平缓流淌 (常规重构与日常总结)</option>
                  <option value="微光沉淀">微光沉淀 (碎片整理与零散记录)</option>
                </select>
              </div>

              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowGoalModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-medium text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-slate-800"
                >
                  取消
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 shadow-md"
                >
                  存入织网节点
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Direction Dimension Manager Modal */}
      {showCategoryManagerModal && (
        <CategoryManagerModal
          title="织网方向与航行维度模版"
          itemLabel="个规划节点"
          getItemCount={(dirName) => weavingGoals.filter((g) => g.direction === dirName).length}
          categories={['全部', ...directionList]}
          onClose={() => setShowCategoryManagerModal(false)}
          onAddCategory={handleAddDirection}
          onRenameCategory={handleRenameDirection}
          onDeleteCategory={handleDeleteDirection}
        />
      )}

    </div>
  );
};
