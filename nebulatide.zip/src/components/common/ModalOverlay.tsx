import React, { useEffect } from 'react';
import { X } from 'lucide-react';

export interface ModalOverlayProps {
  isOpen: boolean;
  onClose: () => void;
  title?: React.ReactNode;
  subtitle?: React.ReactNode;
  icon?: React.ReactNode;
  children: React.ReactNode;
  maxWidthClass?: string; // e.g. 'max-w-md', 'max-w-lg', 'max-w-2xl', 'max-w-4xl'
  closeOnOutsideClick?: boolean;
  showCloseButton?: boolean;
  headerActions?: React.ReactNode;
  className?: string;
  zIndexClass?: string; // e.g. 'z-50', 'z-[60]'
}

/**
 * Standardized Unified Modal Overlay Component
 * Provides:
 * 1. Consistent backdrop blur (backdrop-blur-md sm:backdrop-blur-xl)
 * 2. Click-outside dismissal with e.stopPropagation protection for inner card
 * 3. Escape key listener for keyboard accessibility
 * 4. Mobile responsive layout and high-contrast light/dark mode styling
 */
export const ModalOverlay: React.FC<ModalOverlayProps> = ({
  isOpen,
  onClose,
  title,
  subtitle,
  icon,
  children,
  maxWidthClass = 'max-w-lg',
  closeOnOutsideClick = true,
  showCloseButton = true,
  headerActions,
  className = '',
  zIndexClass = 'z-[60]',
}) => {
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      onClick={(e) => {
        e.stopPropagation();
        if (closeOnOutsideClick) {
          onClose();
        }
      }}
      className={`fixed inset-0 ${zIndexClass} flex items-center justify-center p-3 sm:p-4 bg-slate-950/60 dark:bg-slate-950/80 backdrop-blur-md sm:backdrop-blur-xl animate-in fade-in duration-200 cursor-pointer overflow-y-auto`}
    >
      <div
        onClick={(e) => {
          e.stopPropagation();
        }}
        className={`w-full ${maxWidthClass} my-auto bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800/80 rounded-2xl shadow-2xl overflow-hidden cursor-default transition-all animate-in zoom-in-95 duration-200 flex flex-col max-h-[90vh] ${className}`}
      >
        {/* Modal Header if title or close button specified */}
        {(title || showCloseButton) && (
          <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100 dark:border-slate-800/80 bg-slate-50/50 dark:bg-slate-900/50 shrink-0">
            <div className="flex items-center gap-3 min-w-0 pr-2">
              {icon && (
                <div className="p-2 rounded-xl bg-teal-50 dark:bg-teal-950/50 text-teal-600 dark:text-teal-400 shrink-0">
                  {icon}
                </div>
              )}
              <div className="min-w-0">
                {title && (
                  <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100 truncate">
                    {title}
                  </h3>
                )}
                {subtitle && (
                  <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                    {subtitle}
                  </p>
                )}
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              {headerActions}
              {showCloseButton && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onClose();
                  }}
                  className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
                  aria-label="关闭对话框"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        )}

        {/* Modal Content Body */}
        <div className="flex-1 overflow-y-auto p-5">{children}</div>
      </div>
    </div>
  );
};
