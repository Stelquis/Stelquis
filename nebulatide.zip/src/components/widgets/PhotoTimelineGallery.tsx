import React, { useState, useRef, useEffect } from 'react';
import {
  Camera,
  Calendar,
  MapPin,
  Plus,
  X,
  Upload,
  Trash2,
  Sparkles,
  Maximize2,
  ChevronLeft,
  ChevronRight,
  Tag,
  Filter,
  Image as ImageIcon,
  Heart,
  Share2,
  ArrowUpDown,
  ArrowDownWideNarrow,
  ArrowUpNarrowWide,
} from 'lucide-react';

export interface PhotoItem {
  id: string;
  date: string; // e.g. "2026.07" or "2026.07.15"
  year: string; // e.g. "2026"
  title: string;
  location: string;
  image: string;
  description: string;
  moodTag: string;
  likes?: number;
}

// Date parser helper to convert date strings like "2026.07", "2025.11", "2024-03-15" into comparable number
const parseDateValue = (dateStr: string): number => {
  if (!dateStr) return 0;
  const digits = dateStr.replace(/[^0-9]/g, '.').split('.').filter(Boolean);
  if (digits.length === 0) return 0;
  const year = (digits[0] || '2000').padStart(4, '0');
  const month = (digits[1] || '01').padStart(2, '0');
  const day = (digits[2] || '01').padStart(2, '0');
  return Number(`${year}${month}${day}`);
};

const INITIAL_PHOTOS: PhotoItem[] = [
  {
    id: 'photo-1',
    date: '2026.06',
    year: '2026',
    title: '阿勒泰冰川星空与银河凝视',
    location: '中国 · 新疆禾木',
    image: 'https://images.unsplash.com/photo-1519681393784-d120267933ba?q=80&w=1200&auto=format&fit=crop',
    description: '在海拔 2400 米的无边夜色中凝视遥远的银河，微风带走杂念。在这里思考 NebulaTide 的初版架构与潮汐流动哲学。',
    moodTag: '🌌 沉思',
    likes: 42,
  },
  {
    id: 'photo-2',
    date: '2025.11',
    year: '2025',
    title: 'Silicon Valley 硅谷黑客松决胜之夜',
    location: '美国 · 旧金山湾区',
    image: 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?q=80&w=1200&auto=format&fit=crop',
    description: '连续 48 小时的极限开发马拉松，与来自全球的工程师碰撞观点。零点时分在沉静的会议室中完成多维矩阵可视化的核心 commit。',
    moodTag: '💻 极客黑客松',
    likes: 38,
  },
  {
    id: 'photo-3',
    date: '2025.04',
    year: '2025',
    title: '西湖海岸雨后思想沙龙',
    location: '中国 · 杭州',
    image: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?q=80&w=1200&auto=format&fit=crop',
    description: '雨后的小院散发着泥土与青草的香气，大家围坐在一起交流第一性原理、心智模型与知识卡片复盘体系。',
    moodTag: '🌊 潮汐沙龙',
    likes: 29,
  },
  {
    id: 'photo-4',
    date: '2024.10',
    year: '2024',
    title: '代码高地与晚霞天际线',
    location: '中国 · 北京软件园',
    image: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?q=80&w=1200&auto=format&fit=crop',
    description: '站在顶楼露台眺望被晚霞染红的城市天际线，刚解决了一个复杂的并发瓶颈，心中升起久违的秩序感。',
    moodTag: '🏔️ 远方',
    likes: 51,
  },
];

export const PhotoTimelineGallery: React.FC = () => {
  const [photos, setPhotos] = useState<PhotoItem[]>(() => {
    try {
      const saved = localStorage.getItem('tide_photo_timeline');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.error('Failed to parse photo timeline:', e);
    }
    return INITIAL_PHOTOS;
  });

  const [selectedYear, setSelectedYear] = useState<string>('ALL');
  const [sortOrder, setSortOrder] = useState<'desc' | 'asc'>('desc');
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [activePhotoIndex, setActivePhotoIndex] = useState<number | null>(null);

  // Upload Form State
  const [title, setTitle] = useState('');
  const [date, setDate] = useState('2026.07');
  const [location, setLocation] = useState('中国 · 杭州');
  const [description, setDescription] = useState('');
  const [moodTag, setMoodTag] = useState('✨ 灵感时刻');
  const [imagePreview, setImagePreview] = useState<string>('');
  const [urlInput, setUrlInput] = useState('');
  const [isDragOver, setIsDragOver] = useState(false);
  const [isCompressing, setIsCompressing] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Save to LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem('tide_photo_timeline', JSON.stringify(photos));
    } catch (e) {
      console.error('Failed to save photos to localStorage:', e);
    }
  }, [photos]);

  // Handle Keyboard navigation for Lightbox
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (activePhotoIndex === null) return;
      if (e.key === 'Escape') setActivePhotoIndex(null);
      if (e.key === 'ArrowLeft') handlePrevPhoto();
      if (e.key === 'ArrowRight') handleNextPhoto();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activePhotoIndex, photos]);

  // Compress & convert file to WebP/JPEG dataURL
  const handleFileProcess = (file: File) => {
    if (!file.type.startsWith('image/')) return;
    setIsCompressing(true);
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;
        const maxDim = 1600;
        if (width > maxDim || height > maxDim) {
          if (width > height) {
            height = Math.round((height * maxDim) / width);
            width = maxDim;
          } else {
            width = Math.round((width * maxDim) / height);
            height = maxDim;
          }
        }
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const dataUrl = canvas.toDataURL('image/jpeg', 0.88);
          setImagePreview(dataUrl);
        } else {
          setImagePreview(e.target?.result as string);
        }
        setIsCompressing(false);
      };
      img.onerror = () => setIsCompressing(false);
      img.src = e.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) handleFileProcess(file);
  };

  const handleCreatePhoto = (e: React.FormEvent) => {
    e.preventDefault();
    const finalImage = imagePreview || urlInput.trim();
    if (!finalImage || !title.trim()) return;

    const dateClean = date.trim() || '2026.07';
    const yearMatch = dateClean.match(/\d{4}/);
    const yearStr = yearMatch ? yearMatch[0] : '2026';

    const newPhoto: PhotoItem = {
      id: `photo-${Date.now()}`,
      date: dateClean,
      year: yearStr,
      title: title.trim(),
      location: location.trim() || '未知空间',
      image: finalImage,
      description: description.trim() || '记录此刻微光...',
      moodTag: moodTag.trim() || '✨ 灵感时刻',
      likes: 1,
    };

    setPhotos((prev) => [newPhoto, ...prev]);

    // Reset Form
    setTitle('');
    setDescription('');
    setImagePreview('');
    setUrlInput('');
    setShowUploadModal(false);
  };

  const handleDeletePhoto = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm('确认要删除这张记忆照片吗？')) {
      setPhotos((prev) => prev.filter((p) => p.id !== id));
      if (activePhotoIndex !== null) setActivePhotoIndex(null);
    }
  };

  const handleLikePhoto = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setPhotos((prev) =>
      prev.map((p) => (p.id === id ? { ...p, likes: (p.likes || 0) + 1 } : p))
    );
  };

  // Filtered & Chronologically Sorted
  const yearsList = Array.from(new Set(photos.map((p) => p.year))).sort(
    (a, b) => Number(b) - Number(a)
  );

  const filteredPhotos = (
    selectedYear === 'ALL'
      ? photos
      : photos.filter((p) => p.year === selectedYear)
  ).slice().sort((a, b) => {
    const valA = parseDateValue(a.date);
    const valB = parseDateValue(b.date);
    return sortOrder === 'desc' ? valB - valA : valA - valB;
  });

  const handlePrevPhoto = () => {
    if (activePhotoIndex === null) return;
    setActivePhotoIndex((prev) =>
      prev === null ? null : (prev - 1 + filteredPhotos.length) % filteredPhotos.length
    );
  };

  const handleNextPhoto = () => {
    if (activePhotoIndex === null) return;
    setActivePhotoIndex((prev) =>
      prev === null ? null : (prev + 1) % filteredPhotos.length
    );
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Header & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono text-teal-600 dark:text-teal-400 uppercase tracking-widest block font-semibold">
              CHRONICLE TIMELINE · 岁月轨迹
            </span>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-teal-100 dark:bg-teal-950 text-teal-700 dark:text-teal-300 border border-teal-300 dark:border-teal-500/30">
              {photos.length} 帧时光
            </span>
          </div>
          <h2 className="text-2xl font-bold font-serif text-slate-900 dark:text-white mt-1">
            时光相册与视觉记忆流
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            记录身处世界各地的探索印记、算法灵感时刻与岁月温存
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {/* Year Selector */}
          <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-950 p-1 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-mono">
            <Filter className="w-3.5 h-3.5 text-slate-400 ml-1.5" />
            <button
              onClick={() => setSelectedYear('ALL')}
              className={`px-2.5 py-1 rounded-lg transition-all ${
                selectedYear === 'ALL'
                  ? 'bg-teal-600 text-white font-semibold shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              全部
            </button>
            {yearsList.map((y) => (
              <button
                key={y}
                onClick={() => setSelectedYear(y)}
                className={`px-2.5 py-1 rounded-lg transition-all ${
                  selectedYear === y
                    ? 'bg-teal-600 text-white font-semibold shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {y}
              </button>
            ))}
          </div>

          {/* Sort Direction Toggle Button */}
          <button
            onClick={() => setSortOrder((prev) => (prev === 'desc' ? 'asc' : 'desc'))}
            className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs font-mono text-slate-700 dark:text-slate-300 hover:border-teal-500/50 hover:bg-slate-200 dark:hover:bg-slate-900 transition-all flex items-center gap-1.5 shrink-0"
            title={sortOrder === 'desc' ? '当前：倒序 (最新在前)' : '当前：正序 (最早在前)'}
          >
            {sortOrder === 'desc' ? (
              <>
                <ArrowDownWideNarrow className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                <span>倒序 (最新)</span>
              </>
            ) : (
              <>
                <ArrowUpNarrowWide className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                <span>正序 (最早)</span>
              </>
            )}
          </button>

          {/* Add Photo Button */}
          <button
            onClick={() => setShowUploadModal(true)}
            className="px-4 py-2 rounded-xl text-xs font-semibold text-white bg-gradient-to-r from-teal-600 via-indigo-600 to-purple-600 hover:from-teal-500 hover:to-purple-500 shadow-md hover:shadow-lg transition-all flex items-center gap-2 group active:scale-95 shrink-0"
          >
            <Camera className="w-4 h-4 text-teal-200 group-hover:rotate-12 transition-transform" />
            <span>上传新照片</span>
          </button>
        </div>
      </div>

      {/* Vertical Timeline Stream */}
      {filteredPhotos.length === 0 ? (
        <div className="text-center py-16 bg-slate-50 dark:bg-slate-900/40 rounded-3xl border border-dashed border-slate-300 dark:border-slate-800 space-y-3">
          <ImageIcon className="w-12 h-12 text-slate-300 dark:text-slate-700 mx-auto" />
          <p className="text-sm text-slate-500 dark:text-slate-400 font-serif">该年份暂无记录的照片</p>
          <button
            onClick={() => setShowUploadModal(true)}
            className="px-4 py-2 rounded-xl bg-teal-600 text-white text-xs font-medium hover:bg-teal-500 transition-colors"
          >
            马上上传第一张记忆
          </button>
        </div>
      ) : (
        <div className="relative pl-6 sm:pl-10 space-y-10 sm:space-y-12 before:absolute before:left-3 sm:before:left-5 before:top-2 before:bottom-2 before:w-0.5 before:bg-gradient-to-b before:from-teal-500 before:via-indigo-500 before:to-purple-600/30">
          {filteredPhotos.map((photo, index) => (
            <div
              key={photo.id}
              className="relative group transition-all duration-300"
            >
              {/* Timeline Node Badge / Ring */}
              <div className="absolute -left-6 sm:-left-10 top-4 w-6 h-6 rounded-full bg-white dark:bg-slate-950 border-2 border-teal-500 flex items-center justify-center shadow-lg group-hover:scale-125 group-hover:border-indigo-400 transition-all z-10">
                <div className="w-2 h-2 rounded-full bg-teal-500 group-hover:bg-indigo-400 group-hover:animate-ping" />
              </div>

              {/* Photo Timeline Card */}
              <div className="bg-white/80 dark:bg-slate-900/90 border border-slate-200/80 dark:border-slate-800/90 rounded-3xl p-5 sm:p-7 shadow-sm dark:shadow-2xl backdrop-blur-xl group-hover:border-teal-500/40 group-hover:shadow-teal-500/5 transition-all space-y-5 overflow-hidden">
                
                {/* Meta Top Bar */}
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800/80 pb-3">
                  <div className="flex items-center gap-3">
                    <span className="px-3 py-1 rounded-full bg-teal-100 dark:bg-teal-950/80 text-teal-800 dark:text-teal-300 border border-teal-300 dark:border-teal-500/30 text-xs font-mono font-bold flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                      {photo.date}
                    </span>

                    <span className="text-xs text-slate-500 dark:text-slate-400 font-mono flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5 text-rose-500/80" />
                      {photo.location}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-950 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-800 text-[11px] font-mono">
                      {photo.moodTag}
                    </span>

                    <button
                      onClick={(e) => handleDeletePhoto(photo.id, e)}
                      className="opacity-0 group-hover:opacity-100 p-1.5 rounded-xl hover:bg-rose-100 dark:hover:bg-rose-950 text-slate-400 hover:text-rose-500 transition-all"
                      title="删除这张照片"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Title & Description */}
                <div className="space-y-1.5">
                  <h3 className="text-lg sm:text-xl font-bold font-serif text-slate-900 dark:text-white group-hover:text-teal-600 dark:group-hover:text-teal-300 transition-colors">
                    {photo.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 font-light leading-relaxed">
                    {photo.description}
                  </p>
                </div>

                {/* Photo Banner with Zoom Overlay */}
                <div
                  onClick={() => setActivePhotoIndex(index)}
                  className="relative rounded-2xl overflow-hidden cursor-pointer group/img aspect-[16/9] sm:aspect-[21/9] max-h-[420px] bg-slate-950 shadow-inner border border-slate-200/50 dark:border-slate-800"
                >
                  <img
                    src={photo.image}
                    alt={photo.title}
                    className="w-full h-full object-cover group-hover/img:scale-105 transition-transform duration-700 ease-out"
                    loading="lazy"
                  />

                  {/* Glass Gradient overlay on hover */}
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent opacity-0 group-hover/img:opacity-100 transition-opacity duration-300 flex items-end justify-between p-4 sm:p-6 text-white">
                    <div className="flex items-center gap-2 text-xs font-mono">
                      <Sparkles className="w-4 h-4 text-teal-400 animate-spin-slow" />
                      <span>点击放大全屏沉浸预览</span>
                    </div>

                    <div className="p-2 rounded-2xl bg-white/20 backdrop-blur-md border border-white/30 text-white shadow-xl">
                      <Maximize2 className="w-4 h-4" />
                    </div>
                  </div>
                </div>

                {/* Card Footer Actions */}
                <div className="flex items-center justify-between pt-1 text-xs text-slate-500 dark:text-slate-400">
                  <div className="flex items-center gap-4">
                    <button
                      onClick={(e) => handleLikePhoto(photo.id, e)}
                      className="flex items-center gap-1.5 hover:text-rose-500 transition-colors font-mono"
                    >
                      <Heart className="w-4 h-4 text-rose-500 fill-rose-500/20" />
                      <span>{photo.likes || 0}</span>
                    </button>
                    <span className="font-mono text-[11px] text-slate-400 dark:text-slate-600">
                      ID: {photo.id.slice(-6)}
                    </span>
                  </div>

                  <button
                    onClick={() => setActivePhotoIndex(index)}
                    className="text-teal-600 dark:text-teal-400 font-mono hover:underline flex items-center gap-1"
                  >
                    <span>展开照片故事</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>

              </div>
            </div>
          ))}
        </div>
      )}

      {/* Lightbox Modal */}
      {activePhotoIndex !== null && filteredPhotos[activePhotoIndex] && (
        <div
          className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-xl flex items-center justify-center p-4 sm:p-8 animate-fadeIn"
          onClick={() => setActivePhotoIndex(null)}
        >
          {/* Close button */}
          <button
            onClick={() => setActivePhotoIndex(null)}
            className="absolute top-6 right-6 p-3 rounded-2xl bg-slate-900/80 border border-slate-700 text-slate-300 hover:text-white hover:bg-slate-800 transition-all z-20 shadow-xl"
          >
            <X className="w-6 h-6" />
          </button>

          {/* Left Arrow */}
          <button
            onClick={(e) => { e.stopPropagation(); handlePrevPhoto(); }}
            className="absolute left-4 sm:left-8 top-1/2 -translate-y-1/2 p-3 rounded-2xl bg-slate-900/80 border border-slate-700 text-slate-300 hover:text-white hover:bg-slate-800 transition-all z-20 shadow-xl"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>

          {/* Right Arrow */}
          <button
            onClick={(e) => { e.stopPropagation(); handleNextPhoto(); }}
            className="absolute right-4 sm:right-8 top-1/2 -translate-y-1/2 p-3 rounded-2xl bg-slate-900/80 border border-slate-700 text-slate-300 hover:text-white hover:bg-slate-800 transition-all z-20 shadow-xl"
          >
            <ChevronRight className="w-6 h-6" />
          </button>

          {/* Lightbox Content Card */}
          <div
            className="max-w-5xl w-full max-h-[90vh] bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col lg:flex-row relative z-10 animate-in zoom-in-95 duration-200"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Main Full Image */}
            <div className="flex-1 bg-black flex items-center justify-center p-2 relative overflow-hidden min-h-[300px] lg:min-h-[500px]">
              <img
                src={filteredPhotos[activePhotoIndex].image}
                alt={filteredPhotos[activePhotoIndex].title}
                className="max-w-full max-h-[75vh] object-contain rounded-xl"
              />
            </div>

            {/* Sidebar Details */}
            <div className="w-full lg:w-80 p-6 bg-slate-900 border-t lg:border-t-0 lg:border-l border-slate-800 flex flex-col justify-between space-y-6 text-slate-200">
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <span className="px-3 py-1 rounded-full bg-teal-950 text-teal-300 border border-teal-500/30 text-xs font-mono font-bold">
                    {filteredPhotos[activePhotoIndex].date}
                  </span>
                  <span className="text-xs text-slate-400 font-mono flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-rose-400" />
                    {filteredPhotos[activePhotoIndex].location}
                  </span>
                </div>

                <h3 className="text-xl font-bold font-serif text-white">
                  {filteredPhotos[activePhotoIndex].title}
                </h3>

                <p className="text-xs text-slate-300 font-light leading-relaxed">
                  {filteredPhotos[activePhotoIndex].description}
                </p>

                <div className="pt-2">
                  <span className="inline-block px-3 py-1 rounded-full bg-slate-800 text-teal-300 border border-slate-700 text-xs font-mono">
                    {filteredPhotos[activePhotoIndex].moodTag}
                  </span>
                </div>
              </div>

              {/* Lightbox Footer */}
              <div className="pt-4 border-t border-slate-800 flex items-center justify-between text-xs font-mono text-slate-400">
                <span>
                  {activePhotoIndex + 1} / {filteredPhotos.length}
                </span>

                <button
                  onClick={(e) => handleLikePhoto(filteredPhotos[activePhotoIndex].id, e)}
                  className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-rose-400 flex items-center gap-1.5 transition-colors"
                >
                  <Heart className="w-4 h-4 fill-rose-500" />
                  <span>{filteredPhotos[activePhotoIndex].likes || 0}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Upload Photo Modal */}
      {showUploadModal && (
        <div
          className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn"
          onClick={() => setShowUploadModal(false)}
        >
          <div
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-xl w-full p-6 sm:p-8 space-y-6 shadow-2xl relative animate-in zoom-in-95 duration-200 text-slate-900 dark:text-slate-100"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-teal-100 dark:bg-teal-950 text-teal-600 dark:text-teal-400">
                  <Camera className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold font-serif text-slate-900 dark:text-white">
                    记录新照片记忆
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 font-mono">
                    记录时光与场景，存入本地岁月轨迹
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowUploadModal(false)}
                className="p-2 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleCreatePhoto} className="space-y-4">
              
              {/* Photo Upload Area */}
              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-700 dark:text-slate-300 block">
                  照片上传或 URL 地址 *
                </label>

                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) handleFileProcess(file);
                  }}
                  accept="image/*"
                  className="hidden"
                />

                {imagePreview ? (
                  <div className="relative rounded-2xl overflow-hidden aspect-video max-h-48 border border-teal-500/50 bg-black group">
                    <img
                      src={imagePreview}
                      alt="Preview"
                      className="w-full h-full object-cover"
                    />
                    <button
                      type="button"
                      onClick={() => setImagePreview('')}
                      className="absolute top-2 right-2 p-1.5 rounded-xl bg-slate-900/80 text-white hover:bg-rose-600 transition-colors"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  <div
                    onDragOver={(e) => { e.preventDefault(); setIsDragOver(true); }}
                    onDragLeave={() => setIsDragOver(false)}
                    onDrop={handleDrop}
                    onClick={() => fileInputRef.current?.click()}
                    className={`p-6 rounded-2xl border-2 border-dashed transition-all text-center cursor-pointer flex flex-col items-center gap-2 ${
                      isDragOver
                        ? 'border-teal-500 bg-teal-50 dark:bg-teal-950/40 scale-102'
                        : 'border-slate-300 dark:border-slate-700 hover:border-teal-500 hover:bg-slate-50 dark:hover:bg-slate-800/50'
                    }`}
                  >
                    <Upload className="w-6 h-6 text-teal-600 dark:text-teal-400 animate-bounce" />
                    <p className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                      点击上传图片或拖拽图片至此处
                    </p>
                    <p className="text-[10px] text-slate-500 dark:text-slate-400 font-mono">
                      自动优化压缩画质，无缝高清预览
                    </p>
                  </div>
                )}

                {/* Direct Image URL fallback */}
                {!imagePreview && (
                  <div className="flex gap-2 pt-1">
                    <input
                      type="url"
                      placeholder="或输入图片网络 URL (https://...)"
                      value={urlInput}
                      onChange={(e) => setUrlInput(e.target.value)}
                      className="flex-1 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-1.5 text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:border-teal-500"
                    />
                  </div>
                )}
              </div>

              {/* Title & Date Row */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium text-slate-700 dark:text-slate-300 block mb-1">
                    照片主题 / 名称 *
                  </label>
                  <input
                    type="text"
                    placeholder="如: 攀登雪山之巅"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:border-teal-500"
                    required
                  />
                </div>

                <div>
                  <label className="text-xs font-medium text-slate-700 dark:text-slate-300 block mb-1">
                    拍摄年月 (YYYY.MM) *
                  </label>
                  <input
                    type="text"
                    placeholder="如: 2026.07"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:border-teal-500 font-mono"
                    required
                  />
                </div>
              </div>

              {/* Location & Mood Tag Row */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium text-slate-700 dark:text-slate-300 block mb-1">
                    地点 / 环境
                  </label>
                  <input
                    type="text"
                    placeholder="如: 中国 · 新疆禾木"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:border-teal-500"
                  />
                </div>

                <div>
                  <label className="text-xs font-medium text-slate-700 dark:text-slate-300 block mb-1">
                    Mood / 标签
                  </label>
                  <select
                    value={moodTag}
                    onChange={(e) => setMoodTag(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-800 dark:text-slate-200 focus:outline-none"
                  >
                    <option value="✨ 灵感时刻">✨ 灵感时刻</option>
                    <option value="🌌 沉思">🌌 沉思</option>
                    <option value="💻 极客黑客松">💻 极客黑客松</option>
                    <option value="🌊 潮汐沙龙">🌊 潮汐沙龙</option>
                    <option value="🏔️ 远方与探索">🏔️ 远方与探索</option>
                    <option value="🍵 日常纪实">🍵 日常纪实</option>
                  </select>
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="text-xs font-medium text-slate-700 dark:text-slate-300 block mb-1">
                  照片的故事与心境记录
                </label>
                <textarea
                  rows={3}
                  placeholder="记录当时的气味、思考、相遇的人或解决的难题..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl p-3 text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:border-teal-500 resize-none font-serif"
                />
              </div>

              {/* Submit */}
              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowUploadModal(false)}
                  className="px-4 py-2 rounded-xl text-xs text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                >
                  取消
                </button>
                <button
                  type="submit"
                  disabled={!imagePreview && !urlInput.trim()}
                  className="px-5 py-2 rounded-xl text-xs font-semibold text-white bg-gradient-to-r from-teal-600 to-indigo-600 hover:from-teal-500 hover:to-indigo-500 shadow-md transition-all disabled:opacity-40"
                >
                  存入岁月时间线
                </button>
              </div>

            </form>
          </div>
        </div>
      )}
    </div>
  );
};
