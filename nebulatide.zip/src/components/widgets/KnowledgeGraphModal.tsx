import React, { useState, useMemo, useEffect, useRef } from 'react';
import { X, Network, Search, Sparkles, Filter, FileText, Lightbulb, FolderKanban, Cpu, Hash, ArrowUpRight, Compass, Maximize2, RotateCcw } from 'lucide-react';
import { Post, ThoughtFragment, ProjectItem, MindModel } from '../../types';

interface KnowledgeGraphModalProps {
  isOpen: boolean;
  onClose: () => void;
  posts: Post[];
  fragments: ThoughtFragment[];
  projects: ProjectItem[];
  mindModels?: MindModel[];
  onSelectPost?: (post: Post) => void;
  onAskAIAboutNode?: (nodeTitle: string, nodeType: string) => void;
}

interface GraphNode {
  id: string;
  title: string;
  category: '文章' | '火花' | '项目' | '模型' | '系统';
  tags: string[];
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  color: string;
  rawObj?: any;
}

interface GraphLink {
  source: string;
  target: string;
  commonTags: string[];
}

export const KnowledgeGraphModal: React.FC<KnowledgeGraphModalProps> = ({
  isOpen,
  onClose,
  posts,
  fragments,
  projects,
  mindModels = [],
  onSelectPost,
  onAskAIAboutNode,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [activeNode, setActiveNode] = useState<GraphNode | null>(null);
  const [zoomLevel, setZoomLevel] = useState(1);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Build topology graph nodes & links
  const { nodes, links } = useMemo(() => {
    const rawNodes: GraphNode[] = [];
    
    // 1. Posts
    posts.forEach((p, index) => {
      rawNodes.push({
        id: `post-${p.id}`,
        title: p.title,
        category: '文章',
        tags: p.tags || [],
        x: Math.cos(index * 0.8) * 180 + (Math.random() - 0.5) * 40,
        y: Math.sin(index * 0.8) * 180 + (Math.random() - 0.5) * 40,
        vx: 0,
        vy: 0,
        radius: 12,
        color: '#14b8a6', // Teal
        rawObj: p,
      });
    });

    // 2. Fragments
    fragments.forEach((f, index) => {
      rawNodes.push({
        id: `frag-${f.id}`,
        title: f.content.slice(0, 18) + (f.content.length > 18 ? '...' : ''),
        category: '火花',
        tags: [f.moodTag],
        x: Math.cos(index * 1.2 + 2) * 240 + (Math.random() - 0.5) * 50,
        y: Math.sin(index * 1.2 + 2) * 240 + (Math.random() - 0.5) * 50,
        vx: 0,
        vy: 0,
        radius: 8,
        color: '#f59e0b', // Amber
        rawObj: f,
      });
    });

    // 3. Projects
    projects.forEach((proj, index) => {
      rawNodes.push({
        id: `proj-${proj.id}`,
        title: proj.title,
        category: '项目',
        tags: proj.tags || [],
        x: Math.cos(index * 1.5 + 4) * 300 + (Math.random() - 0.5) * 60,
        y: Math.sin(index * 1.5 + 4) * 300 + (Math.random() - 0.5) * 60,
        vx: 0,
        vy: 0,
        radius: 15,
        color: '#6366f1', // Indigo
        rawObj: proj,
      });
    });

    // 4. Mind Models
    mindModels.forEach((m, index) => {
      rawNodes.push({
        id: `model-${m.title}`,
        title: m.title,
        category: '模型',
        tags: ['思维模型', m.formula],
        x: Math.cos(index * 2 + 1) * 200 + (Math.random() - 0.5) * 40,
        y: Math.sin(index * 2 + 1) * 200 + (Math.random() - 0.5) * 40,
        vx: 0,
        vy: 0,
        radius: 10,
        color: '#ec4899', // Pink
        rawObj: m,
      });
    });

    // Build links based on shared tags
    const rawLinks: GraphLink[] = [];
    for (let i = 0; i < rawNodes.length; i++) {
      for (let j = i + 1; j < rawNodes.length; j++) {
        const nodeA = rawNodes[i];
        const nodeB = rawNodes[j];
        const common = nodeA.tags.filter(t => nodeB.tags.includes(t));
        if (common.length > 0) {
          rawLinks.push({
            source: nodeA.id,
            target: nodeB.id,
            commonTags: common,
          });
        }
      }
    }

    return { nodes: rawNodes, links: rawLinks };
  }, [posts, fragments, projects, mindModels]);

  // Filtered nodes
  const filteredNodes = useMemo(() => {
    return (Array.isArray(nodes) ? nodes : []).filter(node => {
      if (!node) return false;
      const matchesCategory = selectedCategory === 'ALL' || node.category === selectedCategory;
      const matchesSearch = !searchTerm || !searchTerm.trim() || 
        (node.title && node.title.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (node.tags && Array.isArray(node.tags) && node.tags.some(t => typeof t === 'string' && t.toLowerCase().includes(searchTerm.toLowerCase())));
      return matchesCategory && matchesSearch;
    });
  }, [nodes, selectedCategory, searchTerm]);

  // Physics animation on Canvas
  useEffect(() => {
    if (!isOpen || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let width = canvas.parentElement?.clientWidth || 750;
    let height = canvas.parentElement?.clientHeight || 480;
    canvas.width = width * window.devicePixelRatio;
    canvas.height = height * window.devicePixelRatio;

    const centerX = (width * window.devicePixelRatio) / 2;
    const centerY = (height * window.devicePixelRatio) / 2;

    const render = () => {
      ctx.save();
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.scale(zoomLevel, zoomLevel);

      // Draw Links
      const nodeMap = new Map(filteredNodes.map(n => [n.id, n]));
      ctx.lineWidth = 1;
      links.forEach(link => {
        const sourceNode = nodeMap.get(link.source);
        const targetNode = nodeMap.get(link.target);
        if (sourceNode && targetNode) {
          ctx.beginPath();
          ctx.moveTo(centerX + sourceNode.x, centerY + sourceNode.y);
          ctx.lineTo(centerX + targetNode.x, centerY + targetNode.y);
          ctx.strokeStyle = 'rgba(148, 163, 184, 0.15)';
          ctx.stroke();
        }
      });

      // Draw Nodes
      filteredNodes.forEach(node => {
        const isHovered = activeNode?.id === node.id;
        const drawX = centerX + node.x;
        const drawY = centerY + node.y;

        // Outer Glow
        if (isHovered) {
          ctx.beginPath();
          ctx.arc(drawX, drawY, node.radius * 1.8, 0, Math.PI * 2);
          ctx.fillStyle = node.color + '33';
          ctx.fill();
        }

        // Main circle
        ctx.beginPath();
        ctx.arc(drawX, drawY, node.radius, 0, Math.PI * 2);
        ctx.fillStyle = node.color;
        ctx.shadowColor = node.color;
        ctx.shadowBlur = isHovered ? 15 : 6;
        ctx.fill();
        ctx.shadowBlur = 0;

        // Label
        ctx.font = '11px sans-serif';
        ctx.fillStyle = isHovered ? '#38bdf8' : '#94a3b8';
        ctx.textAlign = 'center';
        ctx.fillText(node.title.length > 10 ? node.title.slice(0, 10) + '...' : node.title, drawX, drawY + node.radius + 14);
      });

      ctx.restore();
      animId = requestAnimationFrame(render);
    };

    render();
    return () => cancelAnimationFrame(animId);
  }, [isOpen, filteredNodes, links, activeNode, zoomLevel]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-900/40 dark:bg-slate-950/80 backdrop-blur-md sm:backdrop-blur-xl flex items-center justify-center p-3 sm:p-4 transition-all duration-200 animate-in fade-in"
      onClick={onClose}
    >
      <div
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800/90 rounded-3xl max-w-4xl w-full h-[85vh] flex flex-col shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200 text-slate-900 dark:text-slate-100"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between shrink-0 bg-slate-50 dark:bg-slate-950/50">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-teal-500/10 border border-teal-500/30 text-teal-500">
              <Network className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white font-serif flex items-center gap-2">
                <span>星潮交互式知识拓扑图谱</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-teal-500/10 text-teal-600 dark:text-teal-400 border border-teal-500/20">
                  {filteredNodes.length} Nodes Constellation
                </span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-mono">
                Interactive Knowledge Constellation Map & Cross-References
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search & Filter Toolbar */}
        <div className="p-4 border-b border-slate-200 dark:border-slate-800/80 bg-white dark:bg-slate-900 flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="搜索拓扑节点标题或标签 (如: Agent, 哲学, React)..."
              className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl pl-9 pr-4 py-1.5 text-xs text-slate-900 dark:text-slate-200 focus:outline-none focus:border-teal-500 font-mono"
            />
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
            {['ALL', '文章', '火花', '项目', '模型'].map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1 rounded-lg text-xs font-mono transition-all ${
                  selectedCategory === cat
                    ? 'bg-teal-500 text-slate-950 font-bold shadow-sm'
                    : 'bg-slate-100 dark:bg-slate-800/70 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                }`}
              >
                {cat === 'ALL' ? '全部节点' : cat}
              </button>
            ))}
          </div>
        </div>

        {/* Main Graph View & Node Inspector */}
        <div className="flex-1 relative bg-slate-950 overflow-hidden flex flex-col md:flex-row">
          {/* Canvas Topology View */}
          <div className="flex-1 relative w-full h-full min-h-[350px]">
            <canvas ref={canvasRef} className="w-full h-full block cursor-grab active:cursor-grabbing" />

            {/* Canvas Zoom Controls */}
            <div className="absolute bottom-4 left-4 flex items-center gap-1.5 bg-slate-900/90 border border-slate-800 p-1.5 rounded-xl backdrop-blur-md shadow-lg">
              <button
                onClick={() => setZoomLevel(prev => Math.min(prev + 0.2, 2.5))}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 text-xs font-mono"
                title="放大"
              >
                <Maximize2 className="w-3.5 h-3.5" />
              </button>
              <span className="text-[10px] font-mono text-slate-400 px-1">{Math.round(zoomLevel * 100)}%</span>
              <button
                onClick={() => setZoomLevel(1)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 text-xs font-mono"
                title="重置缩放"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Node Inspector Panel */}
          <div className="w-full md:w-80 border-t md:border-t-0 md:border-l border-slate-800 bg-slate-900/90 p-4 space-y-4 flex flex-col justify-between shrink-0 overflow-y-auto">
            {activeNode ? (
              <div className="space-y-4">
                <div className="space-y-1.5">
                  <span
                    className="inline-block text-[10px] font-mono px-2 py-0.5 rounded-full font-bold"
                    style={{ backgroundColor: activeNode.color + '22', color: activeNode.color }}
                  >
                    {activeNode.category} 节点
                  </span>
                  <h4 className="text-base font-bold text-white font-serif">{activeNode.title}</h4>
                </div>

                <div className="space-y-2">
                  <div className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">语义标签 (Tags)</div>
                  <div className="flex flex-wrap gap-1">
                    {activeNode.tags.map(t => (
                      <span key={t} className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-slate-800 text-slate-300">
                        #{t}
                      </span>
                    ))}
                  </div>
                </div>

                {activeNode.category === '文章' && activeNode.rawObj && (
                  <div className="space-y-3 pt-2">
                    <p className="text-xs text-slate-400 font-serif line-clamp-3">
                      {activeNode.rawObj.excerpt || activeNode.rawObj.summary}
                    </p>
                    <button
                      onClick={() => {
                        onClose();
                        if (onSelectPost && activeNode.rawObj) onSelectPost(activeNode.rawObj);
                      }}
                      className="w-full py-2 rounded-xl bg-teal-500 hover:bg-teal-400 text-slate-950 text-xs font-mono font-bold transition-all flex items-center justify-center gap-1.5 shadow"
                    >
                      <span>深度阅读此文章</span>
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}

                {onAskAIAboutNode && (
                  <button
                    onClick={() => {
                      onClose();
                      onAskAIAboutNode(activeNode.title, activeNode.category);
                    }}
                    className="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-mono transition-all flex items-center justify-center gap-1.5 border border-slate-700"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    <span>请求 AI Copilot 深度剖析</span>
                  </button>
                )}
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-3 text-slate-500">
                <Compass className="w-8 h-8 text-slate-600 animate-pulse" />
                <div className="text-xs font-mono">
                  鼠标悬停在拓扑星图节点上查看全网知识关联
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Node Selection Quick Bar */}
        <div className="p-3 bg-slate-900 border-t border-slate-800 flex items-center gap-2 overflow-x-auto">
          <span className="text-[10px] font-mono text-slate-500 shrink-0">节点速选:</span>
          {filteredNodes.slice(0, 10).map(node => (
            <button
              key={node.id}
              onClick={() => setActiveNode(node)}
              className={`px-2.5 py-1 rounded-lg text-xs font-mono shrink-0 transition-all border ${
                activeNode?.id === node.id
                  ? 'bg-slate-800 text-teal-400 border-teal-500/50'
                  : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
              }`}
            >
              {node.title}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
