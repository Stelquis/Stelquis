import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Layers,
  Cpu,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Play,
  Terminal,
  Activity,
  ArrowRight,
  Maximize2,
  Minimize2,
  RefreshCw,
  FolderGit2,
  FileCode,
  Sliders,
  ChevronRight,
  X
} from 'lucide-react';

export interface TaskNode {
  id: string;
  title: string;
  type: 'AI_AGENT' | 'DATA_VECTOR' | 'SYSTEM_BUILD' | 'SECURITY_CHECK';
  status: 'processing' | 'waiting' | 'completed' | 'warning';
  progress: number;
  updatedAt: string;
  assignee: string;
  detailLog: string[];
}

export const AITaskFlowDashboardWidget: React.FC = () => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [selectedNodeId, setSelectedNodeId] = useState<string>('node-1');
  const [activeTab, setActiveTab] = useState<'stream' | 'timeline' | 'logs'>('stream');

  const [nodes, setNodes] = useState<TaskNode[]>([
    {
      id: 'node-1',
      title: 'NebulaTide DeepSeek-R1 认知图谱向量化',
      type: 'AI_AGENT',
      status: 'processing',
      progress: 88,
      updatedAt: '10:42:15',
      assignee: 'DeepSeek-Copilot',
      detailLog: [
        '[System] 初始化三维向量空间 (Dim: 1536)...',
        '[Embedding] 读取知识碎片 24 条，构建图谱边...',
        '[RAG] 执行语义高维拓扑聚类，提取核心实体...',
        '[Status] 正在将关联节点同步写入本地 SQLite 与 VFS...'
      ]
    },
    {
      id: 'node-2',
      title: 'SQLite VFS 虚拟文件系统增量快照打点',
      type: 'SYSTEM_BUILD',
      status: 'completed',
      progress: 100,
      updatedAt: '10:39:00',
      assignee: 'VFS Engine',
      detailLog: [
        '[VFS] 检测到 SQLite 数据更新，创建 Snapshot #104',
        '[SHA256] 校验和: a3f89e21... 匹配成功',
        '[Storage] 状态已持久化至本地索引库'
      ]
    },
    {
      id: 'node-3',
      title: 'Web3 / AI Dashboard 玻璃拟态 3D 节点流重构',
      type: 'DATA_VECTOR',
      status: 'processing',
      progress: 65,
      updatedAt: '10:41:20',
      assignee: 'Design Engine',
      detailLog: [
        '[UI/UX] 调整黑曜石背景与 #00FF88 荧光绿 Accent',
        '[Glass] 应用 backdrop-blur-md 与 1px 发光微边框',
        '[Perspective] 渲染透视景深 Perspective 视角卡片阵列'
      ]
    },
    {
      id: 'node-4',
      title: '多端自适应智能搜索与全量索引',
      type: 'SECURITY_CHECK',
      status: 'waiting',
      progress: 20,
      updatedAt: '10:30:10',
      assignee: 'Index Worker',
      detailLog: [
        '[Index] 队列等待中: 准备建立多域模糊搜索全量倒排索引...',
        '[Filter] 包含了文章、碎片、项目与认知模型'
      ]
    }
  ]);

  // 模拟 AI 处理进度动画
  useEffect(() => {
    const interval = setInterval(() => {
      setNodes((prevNodes) =>
        prevNodes.map((n) => {
          if (n.status === 'processing' && n.progress < 99) {
            return { ...n, progress: Math.min(n.progress + 2, 99) };
          }
          return n;
        })
      );
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  const currentNode = nodes.find((n) => n.id === selectedNodeId) || nodes[0];

  return (
    <section className="relative w-full rounded-2xl bg-slate-950/90 dark:bg-[#050607]/95 border border-slate-800/80 dark:border-emerald-500/20 shadow-2xl backdrop-blur-xl overflow-hidden p-4 sm:p-6 transition-all duration-300 my-6 font-sans">
      {/* Background Ambient Glow */}
      <div className="absolute -top-24 -left-24 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-24 -right-24 w-96 h-96 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header Bar */}
      <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4 pb-5 border-b border-slate-800/80">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-[#00FF88] shadow-sm">
            <Cpu className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base sm:text-lg font-bold text-slate-100 dark:text-emerald-50 tracking-tight">
                AI Agent 工作流 & 3D 节点可视化控制台
              </h3>
              <span className="inline-flex items-center gap-1 text-[10px] font-mono font-semibold px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-[#00FF88]">
                <Activity className="w-3 h-3" /> LIVE
              </span>
            </div>
            <p className="text-xs text-slate-400 dark:text-slate-400">
              Dark Obsidian SaaS Architecture · 黑曜石玻璃拟态 AI Agent 工作流
            </p>
          </div>
        </div>

        {/* Top Control Action Buttons */}
        <div className="flex items-center gap-2 self-end md:self-auto">
          <div className="flex items-center p-1 rounded-xl bg-slate-900 border border-slate-800 text-xs">
            <button
              onClick={() => setActiveTab('stream')}
              className={`px-3 py-1 rounded-lg transition-all ${
                activeTab === 'stream'
                  ? 'bg-emerald-500/20 text-[#00FF88] font-semibold border border-emerald-500/40'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              3D 文件节点流
            </button>
            <button
              onClick={() => setActiveTab('timeline')}
              className={`px-3 py-1 rounded-lg transition-all ${
                activeTab === 'timeline'
                  ? 'bg-emerald-500/20 text-[#00FF88] font-semibold border border-emerald-500/40'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              甘特时间轴
            </button>
            <button
              onClick={() => setActiveTab('logs')}
              className={`px-3 py-1 rounded-lg transition-all ${
                activeTab === 'logs'
                  ? 'bg-emerald-500/20 text-[#00FF88] font-semibold border border-emerald-500/40'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              AI 运行日志
            </button>
          </div>

          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-emerald-400 transition-colors"
            title={isExpanded ? '收起控制台' : '展开全屏面板'}
          >
            {isExpanded ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* 4 Stats Cards Grid (Glassmorphism & Neon Glowing Borders) */}
      <div className="relative z-10 grid grid-cols-2 lg:grid-cols-4 gap-3 my-5">
        {[
          { label: '活跃 Task 节点', val: '12', sub: '今日已协同 8 轮', icon: Layers, color: 'text-emerald-400', border: 'border-emerald-500/30' },
          { label: '进行中推理', val: '2', sub: 'DeepSeek-R1 88%', icon: Sparkles, color: 'text-teal-300', border: 'border-teal-500/30' },
          { label: '系统已归档', val: '56', sub: 'VFS 校验和一致', icon: CheckCircle2, color: 'text-emerald-500', border: 'border-emerald-500/30' },
          { label: '预警节点', val: '0', sub: '状态极佳 (Healthy)', icon: AlertTriangle, color: 'text-emerald-400', border: 'border-emerald-500/30' }
        ].map((st, i) => {
          const Icon = st.icon;
          return (
            <div
              key={i}
              className={`p-3.5 rounded-xl bg-slate-900/60 border ${st.border} backdrop-blur-md hover:border-emerald-500/50 hover:bg-slate-900/90 transition-all duration-300 group shadow-inner`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs text-slate-400 font-medium">{st.label}</span>
                <Icon className={`w-4 h-4 ${st.color} group-hover:scale-110 transition-transform`} />
              </div>
              <div className="text-xl sm:text-2xl font-bold font-mono text-slate-100 flex items-baseline gap-1.5">
                <span>{st.val}</span>
                <span className="text-[10px] font-sans font-normal text-slate-400">{st.sub}</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Central Visual Main View */}
      <div className="relative z-10 grid grid-cols-1 lg:grid-cols-3 gap-5">
        
        {/* Left/Center Visual Workspace */}
        <div className="lg:col-span-2 bg-slate-900/80 border border-slate-800/90 rounded-xl p-4 min-h-[320px] flex flex-col justify-between overflow-hidden relative group">
          
          {/* Perspective 3D Floating File Node Stream Stage */}
          {activeTab === 'stream' && (
            <div className="relative w-full h-full min-h-[280px] flex items-center justify-center py-6">
              {/* Perspective Container */}
              <div
                className="w-full max-w-xl space-y-3 transition-transform duration-500"
                style={{
                  perspective: '1000px',
                  transformStyle: 'preserve-3d',
                }}
              >
                {nodes.map((node, idx) => {
                  const isSelected = node.id === selectedNodeId;
                  const isProcessing = node.status === 'processing';
                  const isDone = node.status === 'completed';

                  return (
                    <div
                      key={node.id}
                      onClick={() => setSelectedNodeId(node.id)}
                      className={`relative cursor-pointer p-4 rounded-xl border transition-all duration-300 flex items-center justify-between gap-4 backdrop-blur-lg ${
                        isSelected
                          ? 'bg-slate-900/95 border-[#00FF88] shadow-[0_0_25px_rgba(0,255,136,0.2)] scale-[1.02]'
                          : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 hover:bg-slate-900/80'
                      }`}
                      style={{
                        transform: `rotateX(12deg) translateZ(${idx * -12}px)`,
                      }}
                    >
                      {/* Left Status Bar */}
                      <div className="flex items-center gap-3 min-w-0">
                        <div
                          className={`w-2.5 h-2.5 rounded-full shrink-0 ${
                            isProcessing
                              ? 'bg-[#00FF88] animate-ping'
                              : isDone
                              ? 'bg-emerald-500'
                              : 'bg-slate-600'
                          }`}
                        />
                        <div className="min-w-0">
                          <h4 className="text-xs sm:text-sm font-semibold text-slate-200 truncate group-hover:text-emerald-300">
                            {node.title}
                          </h4>
                          <div className="flex items-center gap-2 mt-0.5 text-[11px] text-slate-400 font-mono">
                            <span>{node.assignee}</span>
                            <span>•</span>
                            <span>更新于 {node.updatedAt}</span>
                          </div>
                        </div>
                      </div>

                      {/* Right Progress Pill */}
                      <div className="flex items-center gap-3 shrink-0">
                        <div className="w-20 sm:w-28 bg-slate-950 rounded-full h-1.5 overflow-hidden border border-slate-800">
                          <div
                            className={`h-full transition-all duration-500 ${
                              isDone
                                ? 'bg-emerald-500'
                                : 'bg-gradient-to-r from-teal-500 to-[#00FF88]'
                            }`}
                            style={{ width: `${node.progress}%` }}
                          />
                        </div>
                        <span className="text-xs font-mono font-bold text-[#00FF88] w-9 text-right">
                          {node.progress}%
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Timeline Gantt View */}
          {activeTab === 'timeline' && (
            <div className="w-full space-y-4 py-3">
              <h4 className="text-xs font-semibold text-slate-300 flex items-center gap-2">
                <Clock className="w-3.5 h-3.5 text-[#00FF88]" />
                <span>任务流甘特图 (Gantt Exec Schedule)</span>
              </h4>
              <div className="space-y-3 font-sans">
                {nodes.map((node) => (
                  <div key={node.id} className="space-y-1">
                    <div className="flex justify-between text-xs text-slate-300">
                      <span>{node.title}</span>
                      <span className="font-mono text-slate-400">{node.status}</span>
                    </div>
                    <div className="w-full h-3 bg-slate-950 rounded-full border border-slate-800 overflow-hidden relative">
                      <div
                        className="h-full bg-gradient-to-r from-emerald-600 to-[#00FF88] rounded-full transition-all duration-500"
                        style={{ width: `${node.progress}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Terminal Log View */}
          {activeTab === 'logs' && (
            <div className="w-full h-full min-h-[220px] bg-slate-950 rounded-lg p-3 font-mono text-xs text-emerald-400 space-y-1.5 border border-slate-800 overflow-y-auto">
              <div className="text-slate-500 pb-1 border-b border-slate-800 flex justify-between">
                <span>[LOG CONSOLE] Node: {currentNode.title}</span>
                <span>STATUS: {currentNode.status.toUpperCase()}</span>
              </div>
              {currentNode.detailLog.map((log, i) => (
                <div key={i} className="flex gap-2">
                  <span className="text-slate-600">&gt;</span>
                  <span>{log}</span>
                </div>
              ))}
              <div className="flex gap-2 text-slate-500 animate-pulse">
                <span>&gt;</span>
                <span>_ 等待下一个 AI Agent 指令...</span>
              </div>
            </div>
          )}

          <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400 font-mono">
            <span>点击节点切换焦点查看详情</span>
            <span className="text-[#00FF88]">Cyber AI Node Stream Engine v2.4</span>
          </div>
        </div>

        {/* Right Detail Panel Drawer */}
        <div className="bg-slate-900/80 border border-slate-800/90 rounded-xl p-4 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5 text-[#00FF88]" />
                <span>节点控制详情面板</span>
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-[#00FF88] border border-emerald-500/30">
                {currentNode.status}
              </span>
            </div>

            <div>
              <h4 className="text-sm font-bold text-slate-100">{currentNode.title}</h4>
              <p className="text-xs text-slate-400 mt-1">
                负责人: <span className="text-slate-200 font-mono">{currentNode.assignee}</span>
              </p>
            </div>

            <div className="space-y-2 text-xs text-slate-300">
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">更新时间</span>
                <span className="font-mono">{currentNode.updatedAt}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">节点类型</span>
                <span className="font-mono text-emerald-400">{currentNode.type}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">处理完成度</span>
                <span className="font-mono font-bold text-[#00FF88]">{currentNode.progress}%</span>
              </div>
            </div>

            {/* AI Reasoning Log Snippet */}
            <div className="space-y-1">
              <label className="text-[11px] font-semibold text-slate-400">最新推演步日志</label>
              <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-[11px] font-mono text-slate-300 line-clamp-3">
                {currentNode.detailLog[currentNode.detailLog.length - 1]}
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-800 flex gap-2">
            <button
              onClick={() => {
                setNodes((prev) =>
                  prev.map((n) =>
                    n.id === selectedNodeId
                      ? { ...n, status: 'completed', progress: 100 }
                      : n
                  )
                );
              }}
              className="flex-1 py-1.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-[#00FF88] border border-emerald-500/40 text-xs font-semibold transition-all flex items-center justify-center gap-1"
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>标记完成</span>
            </button>
            <button
              onClick={() => {
                setNodes((prev) =>
                  prev.map((n) =>
                    n.id === selectedNodeId ? { ...n, progress: 0, status: 'processing' } : n
                  )
                );
              }}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs transition-colors"
              title="重新推算此节点"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
