import React, { useState } from 'react';
import { InteractiveNebulaGrid, NebulaNode, NebulaLink } from './InteractiveNebulaGrid';
import {
  Cpu,
  Code2,
  Database,
  Terminal,
  Sparkles,
  Layers,
  Bot,
  Brain,
  Mic,
  Box,
  Zap,
  BarChart3,
  Globe,
  Network,
  Server,
  Wrench,
  Plus,
  Pencil,
  Trash2,
  X,
  Check,
  Flame,
  GitBranch
} from 'lucide-react';

export interface TechItem {
  id?: string;
  name: string;
  level: 'master' | 'proficient' | 'familiar';
  category: 'ai' | 'backend' | 'frontend' | 'data' | 'system';
  description: string;
  projectRelation?: string;
  icon?: string;
}

const initialTechItems: TechItem[] = [
  // AI & Agent
  { id: 'tech-1', name: 'PyTorch & GNN', level: 'master', category: 'ai', icon: 'PyTorch', description: '图神经网络 (GCN/EGNN/SE3-Transformer) 分子构象与复杂网络拓扑建模', projectRelation: 'BioNet 蛋白质折叠预测' },
  { id: 'tech-2', name: 'LLM RAG & Agent Flow', level: 'master', category: 'ai', icon: 'LangChain', description: '基于 LangChain / Vercel AI SDK 的智能代理工作流与多模态知识图谱检索', projectRelation: 'NebulaTide AI Writing Assistant' },
  { id: 'tech-3', name: 'Whisper & Speech Processing', level: 'proficient', category: 'ai', icon: 'Whisper', description: '端到端语音转文字与降噪预处理', projectRelation: '语音潮汐日记' },

  // Backend & Cloud Native
  { id: 'tech-4', name: 'Python Asyncio & FastAPI', level: 'master', category: 'backend', icon: 'Python', description: '高并发异步 API 架构、协程调度与低延迟推演接口', projectRelation: 'TideEngine Backend' },
  { id: 'tech-5', name: 'Docker & Kubernetes', level: 'proficient', category: 'backend', icon: 'Docker', description: '云原生容器化部署、自动扩缩容与 Envoy/Nginx 反向代理配置', projectRelation: 'CNB 自动构建与部署流水线' },
  { id: 'tech-6', name: 'Redis & Message Queue', level: 'familiar', category: 'backend', icon: 'Redis', description: '高并发缓存、Pub/Sub 订阅与分布式锁引擎', projectRelation: '实时潮汐广播中心' },

  // Data & Visualization
  { id: 'tech-7', name: 'D3.js & WebGL Visuals', level: 'master', category: 'data', icon: 'D3', description: '交互式力导向图、星图粒子系统与潮汐三维可视化', projectRelation: 'NebulaTide 星云宇宙交互图' },
  { id: 'tech-8', name: 'PostgreSQL & Vector DB', level: 'proficient', category: 'data', icon: 'PostgreSQL', description: 'pgvector 向量相似度检索、Prisma ORM 与复杂 SQL 性能调优', projectRelation: '全站向量知识库' },
  { id: 'tech-9', name: 'Pandas & Scientific Stack', level: 'master', category: 'data', icon: 'Pandas', description: '海量结构化/半结构化数据清洗、统计建模与信号处理', projectRelation: '科研分子动力学轨迹分析' },

  // System & Web
  { id: 'tech-10', name: 'TypeScript & Next.js / React 18', level: 'master', category: 'frontend', icon: 'TypeScript', description: '服务端渲染、App Router、Tailwind CSS 与微前端组件库', projectRelation: 'NebulaTide Blog System' },
  { id: 'tech-11', name: 'PySpider & Anti-Anti-Crawler', level: 'proficient', category: 'system', icon: 'FastAPI', description: '分布式爬虫架构、动态渲染解析与 IP 代理池调度', projectRelation: '科研论文 & 潮汐数据自动抓取' },
  { id: 'tech-12', name: 'Linux OS & Shell Scripting', level: 'master', category: 'system', icon: 'Linux', description: 'Linux 系统底层调度、Shell 自动化运维与性能 Profiling', projectRelation: '服务器自治运维架构' },
];

const categories = [
  { id: 'all', name: '全部领域', icon: '🌌' },
  { id: 'ai', name: 'AI & 智能代理', icon: '🤖' },
  { id: 'backend', name: '后端与云原生', icon: '⚙️' },
  { id: 'data', name: '数据与可视化', icon: '📊' },
  { id: 'frontend', name: '前端与 UI', icon: '🎨' },
  { id: 'system', name: '系统与爬虫', icon: '🚀' },
] as const;

// Brand Primary Colors & Shields Badge URLs Configuration
export interface BrandMeta {
  color: string;
  badgeUrl: string;
  label: string;
}

export const BRAND_CONFIGS: Record<string, BrandMeta> = {
  Python: {
    color: '#3776AB',
    badgeUrl: 'https://img.shields.io/badge/Python-3776AB?style=flat&logo=python&logoColor=white',
    label: 'Python',
  },
  PyTorch: {
    color: '#EE4C2C',
    badgeUrl: 'https://img.shields.io/badge/PyTorch-EE4C2C?style=flat&logo=pytorch&logoColor=white',
    label: 'PyTorch',
  },
  Docker: {
    color: '#2496ED',
    badgeUrl: 'https://img.shields.io/badge/Docker-2496ED?style=flat&logo=docker&logoColor=white',
    label: 'Docker',
  },
  Kubernetes: {
    color: '#326CE5',
    badgeUrl: 'https://img.shields.io/badge/Kubernetes-326CE5?style=flat&logo=kubernetes&logoColor=white',
    label: 'Kubernetes',
  },
  Linux: {
    color: '#FACC15',
    badgeUrl: 'https://img.shields.io/badge/Linux-FCC624?style=flat&logo=linux&logoColor=black',
    label: 'Linux',
  },
  React: {
    color: '#61DAFB',
    badgeUrl: 'https://img.shields.io/badge/React-61DAFB?style=flat&logo=react&logoColor=black',
    label: 'React',
  },
  TypeScript: {
    color: '#3178C6',
    badgeUrl: 'https://img.shields.io/badge/TypeScript-3178C6?style=flat&logo=typescript&logoColor=white',
    label: 'TypeScript',
  },
  PostgreSQL: {
    color: '#4169E1',
    badgeUrl: 'https://img.shields.io/badge/PostgreSQL-4169E1?style=flat&logo=postgresql&logoColor=white',
    label: 'PostgreSQL',
  },
  Redis: {
    color: '#DC382D',
    badgeUrl: 'https://img.shields.io/badge/Redis-DC382D?style=flat&logo=redis&logoColor=white',
    label: 'Redis',
  },
  FastAPI: {
    color: '#10B981',
    badgeUrl: 'https://img.shields.io/badge/FastAPI-059669?style=flat&logo=fastapi&logoColor=white',
    label: 'FastAPI',
  },
  Pandas: {
    color: '#E70488',
    badgeUrl: 'https://img.shields.io/badge/Pandas-150458?style=flat&logo=pandas&logoColor=white',
    label: 'Pandas',
  },
  D3: {
    color: '#F9A03F',
    badgeUrl: 'https://img.shields.io/badge/D3.js-F9A03F?style=flat&logo=d3.js&logoColor=white',
    label: 'D3.js',
  },
  LangChain: {
    color: '#34D399',
    badgeUrl: 'https://img.shields.io/badge/LangChain-10B981?style=flat&logo=langchain&logoColor=white',
    label: 'LangChain',
  },
  Whisper: {
    color: '#2DD4BF',
    badgeUrl: 'https://img.shields.io/badge/Whisper_AI-14B8A6?style=flat&logo=openai&logoColor=white',
    label: 'Whisper',
  },
  Go: {
    color: '#00ADD8',
    badgeUrl: 'https://img.shields.io/badge/Go-00ADD8?style=flat&logo=go&logoColor=white',
    label: 'Go',
  },
  Rust: {
    color: '#FDBA74',
    badgeUrl: 'https://img.shields.io/badge/Rust-DEA584?style=flat&logo=rust&logoColor=black',
    label: 'Rust',
  },
  Tailwind: {
    color: '#38BDF8',
    badgeUrl: 'https://img.shields.io/badge/Tailwind-06B6D4?style=flat&logo=tailwindcss&logoColor=white',
    label: 'Tailwind',
  },
  Git: {
    color: '#FB923C',
    badgeUrl: 'https://img.shields.io/badge/Git-F05032?style=flat&logo=git&logoColor=white',
    label: 'Git',
  },
};

// Component to render Shields Badge image with fallback
export const TechShieldBadge: React.FC<{ iconKey?: string; name: string }> = ({ iconKey, name }) => {
  const brand = BRAND_CONFIGS[iconKey || ''];
  const [imgError, setImgError] = useState(false);

  if (brand && brand.badgeUrl && !imgError) {
    return (
      <img
        src={brand.badgeUrl}
        alt={name}
        onError={() => setImgError(true)}
        referrerPolicy="no-referrer"
        className="h-5 rounded shrink-0 shadow-sm transition-transform group-hover:scale-105"
      />
    );
  }

  // Fallback inline rendering if image load fails
  return (
    <span
      className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-mono font-bold shrink-0 text-white shadow-sm"
      style={{ backgroundColor: brand?.color || '#0D9488' }}
    >
      {brand?.label || name.split(' ')[0]}
    </span>
  );
};

export const TechStackMatrix: React.FC = () => {
  const [techs, setTechs] = useState<TechItem[]>(initialTechItems);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'grid' | 'nebula'>('grid');
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingItem, setEditingItem] = useState<TechItem | null>(null);

  const catNameMap: Record<string, string> = {
    ai: '算法攻坚',
    backend: '系统重构',
    frontend: '探索与创作',
    data: '数据与可视化',
    system: '心智升级',
  };

  const techNebulaNodes: NebulaNode[] = techs.map((item, idx) => ({
    id: item.id || `tech-${idx}`,
    label: item.name,
    category: catNameMap[item.category] || item.category,
    val: item.level === 'master' ? 15 : item.level === 'proficient' ? 11 : 8,
    status: item.level,
  }));

  const techNebulaLinks: NebulaLink[] = [];
  for (let i = 0; i < techNebulaNodes.length; i++) {
    for (let j = i + 1; j < techNebulaNodes.length; j++) {
      if (
        techNebulaNodes[i].category === techNebulaNodes[j].category ||
        j === i + 1
      ) {
        techNebulaLinks.push({
          source: techNebulaNodes[i].id,
          target: techNebulaNodes[j].id,
        });
      }
    }
  }

  // Form State
  const [formData, setFormData] = useState<TechItem>({
    name: '',
    level: 'proficient',
    category: 'ai',
    icon: 'Python',
    description: '',
    projectRelation: '',
  });

  const filteredTechs = selectedCategory === 'all'
    ? techs
    : techs.filter((t) => t.category === selectedCategory);

  const getLevelBadge = (level: TechItem['level']) => {
    switch (level) {
      case 'master':
        return {
          label: '精通',
          cls: 'bg-teal-100 dark:bg-teal-950/80 text-teal-800 dark:text-teal-300 border border-teal-300 dark:border-teal-500/40 shadow-sm hover:bg-teal-200 dark:hover:bg-teal-900',
        };
      case 'proficient':
        return {
          label: '熟练',
          cls: 'bg-indigo-100 dark:bg-indigo-950/80 text-indigo-800 dark:text-indigo-300 border border-indigo-300 dark:border-indigo-500/40 hover:bg-indigo-200 dark:hover:bg-indigo-900',
        };
      case 'familiar':
      default:
        return {
          label: '了解',
          cls: 'bg-amber-100 dark:bg-amber-950/70 text-amber-800 dark:text-amber-300 border border-amber-300 dark:border-amber-500/30 hover:bg-amber-200 dark:hover:bg-amber-900/60',
        };
    }
  };

  const handleOpenAdd = () => {
    setEditingItem(null);
    setFormData({
      name: '',
      level: 'proficient',
      category: 'ai',
      icon: 'Python',
      description: '',
      projectRelation: '',
    });
    setShowEditModal(true);
  };

  const handleOpenEdit = (item: TechItem) => {
    setEditingItem(item);
    setFormData({ ...item });
    setShowEditModal(true);
  };

  const handleDelete = (id?: string) => {
    if (!id) return;
    setTechs((prev) => prev.filter((t) => t.id !== id));
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.description.trim()) return;

    if (editingItem && editingItem.id) {
      setTechs((prev) =>
        prev.map((t) => (t.id === editingItem.id ? { ...formData, id: editingItem.id } : t))
      );
    } else {
      const newItem: TechItem = {
        ...formData,
        id: `tech-${Date.now()}`,
      };
      setTechs((prev) => [...prev, newItem]);
    }

    setShowEditModal(false);
  };

  return (
    <div className="bg-white/80 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm dark:shadow-xl space-y-6 backdrop-blur-md text-slate-900 dark:text-slate-100">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-100 dark:bg-teal-950/80 border border-teal-300 dark:border-teal-500/30 text-teal-800 dark:text-teal-300 text-xs font-mono">
              <Cpu className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
              <span>ENGINEERING & AI CAPABILITIES</span>
            </span>
          </div>
          <h3 className="text-xl font-bold font-serif text-slate-900 dark:text-white">技术矩阵与工程基因</h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 font-light mt-0.5">
            融合 AI 智能体、图神经网络与云原生架构（使用 Shields 官方技术栈徽章与品牌原色高亮）
          </p>
        </div>

        {/* Category Filters + ViewMode + Add Button */}
        <div className="flex flex-wrap items-center gap-1.5">
          {/* View Mode Toggle */}
          <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-950 p-1 rounded-xl border border-slate-200 dark:border-slate-800 mr-1">
            <button
              onClick={() => setViewMode('grid')}
              className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
                viewMode === 'grid'
                  ? 'bg-white dark:bg-slate-800 text-teal-600 dark:text-teal-400 shadow-sm font-semibold'
                  : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              矩阵卡片
            </button>
            <button
              onClick={() => setViewMode('nebula')}
              className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all flex items-center gap-1 ${
                viewMode === 'nebula'
                  ? 'bg-white dark:bg-slate-800 text-teal-600 dark:text-teal-400 shadow-sm font-semibold'
                  : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              <Sparkles className="w-3 h-3 text-teal-500" />
              <span>星云图谱</span>
            </button>
          </div>

          {viewMode === 'grid' && categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all flex items-center gap-1.5 ${
                selectedCategory === cat.id
                  ? 'bg-gradient-to-r from-teal-600 to-indigo-600 text-white shadow-md'
                  : 'bg-white dark:bg-slate-950 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-800 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              <span>{cat.icon}</span>
              <span>{cat.name}</span>
            </button>
          ))}

          <button
            onClick={handleOpenAdd}
            className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-teal-100 dark:hover:bg-teal-900/80 hover:text-teal-800 dark:hover:text-teal-200 border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-mono transition-all flex items-center gap-1.5 shadow-sm ml-1"
            title="新增或自定义技术栈条目"
          >
            <Plus className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
            <span>新增栈节点</span>
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      {viewMode === 'nebula' ? (
        <InteractiveNebulaGrid
          nodes={techNebulaNodes}
          links={techNebulaLinks}
          title="技术基因与工程栈星云图谱"
          subtitle="点击或拖拽基因节点，沿着相互依附与协作引力连线，发射高亮能量光束"
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredTechs.map((item) => {
          const badge = getLevelBadge(item.level);
          const brand = BRAND_CONFIGS[item.icon || ''];
          const highlightColor = brand ? brand.color : '#0D9488';

          return (
            <div
              key={item.id || item.name}
              className="bg-white/90 dark:bg-slate-950/70 border border-slate-200 dark:border-slate-800/80 hover:border-teal-500/40 rounded-xl p-4 transition-all space-y-3 group relative shadow-sm"
            >
              <div className="flex items-center justify-between gap-2 overflow-hidden">
                {/* Left side: Shields Badge + Title Text */}
                <div className="flex items-center gap-2.5 min-w-0 flex-1">
                  <TechShieldBadge iconKey={item.icon} name={item.name} />

                  <h4
                    className="text-sm font-bold font-serif truncate transition-all text-slate-900 dark:text-white"
                    style={{ color: highlightColor }}
                    title={item.name}
                  >
                    {item.name}
                  </h4>
                </div>

                {/* Right side: Level Badge Button */}
                <button
                  type="button"
                  onClick={() => handleOpenEdit(item)}
                  className={`text-[10px] font-mono font-medium px-2.5 py-0.5 rounded-full shrink-0 ml-auto hover:scale-105 active:scale-95 transition-all cursor-pointer ${badge.cls}`}
                  title="点击编辑此类目的熟练度与详情"
                >
                  {badge.label}
                </button>
              </div>

              <p className="text-xs text-slate-600 dark:text-slate-400 font-light leading-relaxed">
                {item.description}
              </p>

              {item.projectRelation && (
                <div className="pt-2 border-t border-slate-200 dark:border-slate-800/60 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 font-mono">
                  <span className="text-teal-600 dark:text-teal-400 font-semibold">🔗 关联成果:</span>
                  <span className="truncate max-w-[160px]">{item.projectRelation}</span>
                </div>
              )}
            </div>
          );
        })}
        </div>
      )}

      {/* Edit / Add Modal */}
      {showEditModal && (
        <div
          className="fixed inset-0 z-50 bg-slate-900/20 dark:bg-slate-950/70 backdrop-blur-md flex items-center justify-center p-4 transition-all duration-200 animate-in fade-in"
          onClick={() => setShowEditModal(false)}
        >
          <div
            className="bg-white dark:bg-slate-900/95 border border-slate-200 dark:border-slate-800/90 rounded-3xl max-w-lg w-full p-6 space-y-5 shadow-2xl animate-in zoom-in-95 duration-200 text-slate-900 dark:text-slate-100"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="text-base font-bold text-slate-900 dark:text-white font-serif">
                {editingItem ? '编辑技术基因条目' : '新增技术栈与技能节点'}
              </h3>
              <button
                onClick={() => setShowEditModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-slate-600 dark:text-slate-300 block mb-1">技术栈/工具名称 *</label>
                  <input
                    type="text"
                    placeholder="如: Rust & WebAssembly"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-slate-200 focus:outline-none focus:border-teal-500 font-mono"
                    required
                  />
                </div>

                <div>
                  <label className="text-xs text-slate-600 dark:text-slate-300 block mb-1">熟练度等级</label>
                  <select
                    value={formData.level}
                    onChange={(e) => setFormData({ ...formData, level: e.target.value as any })}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-slate-200 focus:outline-none focus:border-teal-500"
                  >
                    <option value="master">精通</option>
                    <option value="proficient">熟练</option>
                    <option value="familiar">了解</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-slate-600 dark:text-slate-300 block mb-1">所属工程维度</label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value as any })}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-slate-200 focus:outline-none focus:border-teal-500"
                  >
                    <option value="ai">AI & 智能代理</option>
                    <option value="backend">后端与云原生</option>
                    <option value="data">数据与可视化</option>
                    <option value="frontend">前端与 UI</option>
                    <option value="system">系统与爬虫</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs text-slate-600 dark:text-slate-300 block mb-1">专属 Shields 徽章 (Badge)</label>
                  <select
                    value={formData.icon || 'Python'}
                    onChange={(e) => setFormData({ ...formData, icon: e.target.value })}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-slate-200 focus:outline-none focus:border-teal-500"
                  >
                    <option value="Python">🐍 Python 官方 Shield 徽章</option>
                    <option value="PyTorch">🔥 PyTorch 官方 Shield 徽章</option>
                    <option value="Docker">🐳 Docker 官方 Shield 徽章</option>
                    <option value="Kubernetes">☸️ Kubernetes 官方 Shield 徽章</option>
                    <option value="Linux">🐧 Linux 官方 Shield 徽章</option>
                    <option value="React">⚛️ React 官方 Shield 徽章</option>
                    <option value="TypeScript">📘 TypeScript 官方 Shield 徽章</option>
                    <option value="PostgreSQL">🐘 PostgreSQL 官方 Shield 徽章</option>
                    <option value="Redis">🔴 Redis 官方 Shield 徽章</option>
                    <option value="FastAPI">⚡ FastAPI 官方 Shield 徽章</option>
                    <option value="Pandas">🐼 Pandas 官方 Shield 徽章</option>
                    <option value="D3">📊 D3.js 官方 Shield 徽章</option>
                    <option value="LangChain">🦜 LangChain 官方 Shield 徽章</option>
                    <option value="Whisper">🎙️ Whisper AI 官方 Shield 徽章</option>
                    <option value="Go">🐹 Go / Golang 官方 Shield 徽章</option>
                    <option value="Rust">🦀 Rust 官方 Shield 徽章</option>
                    <option value="Tailwind">🎨 Tailwind CSS 官方 Shield 徽章</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs text-slate-600 dark:text-slate-300 block mb-1">关联项目/代表性产出</label>
                <input
                  type="text"
                  placeholder="如: NebulaTide 开源项目"
                  value={formData.projectRelation || ''}
                  onChange={(e) => setFormData({ ...formData, projectRelation: e.target.value })}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-slate-200 focus:outline-none focus:border-teal-500 font-mono"
                />
              </div>

              <div>
                <label className="text-xs text-slate-600 dark:text-slate-300 block mb-1">技术能力与应用场景描述 *</label>
                <textarea
                  rows={3}
                  placeholder="阐述该技术栈的具体应用场景、底层原理与能力边界..."
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl p-3 text-xs text-slate-900 dark:text-slate-200 focus:outline-none focus:border-teal-500 resize-none font-serif"
                  required
                />
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-slate-200 dark:border-slate-800">
                {editingItem?.id ? (
                  <button
                    type="button"
                    onClick={() => {
                      handleDelete(editingItem.id);
                      setShowEditModal(false);
                    }}
                    className="px-3.5 py-2 rounded-xl text-xs font-semibold text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 dark:hover:bg-rose-900/60 border border-rose-200 dark:border-rose-500/30 transition-all flex items-center gap-1.5 shadow-sm"
                    title="从技术矩阵中彻底删除此项"
                  >
                    <Trash2 className="w-3.5 h-3.5 text-rose-500 dark:text-rose-400" />
                    <span>删除节点</span>
                  </button>
                ) : (
                  <div />
                )}

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setShowEditModal(false)}
                    className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 transition-all"
                  >
                    取消
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-xl text-xs font-semibold text-white bg-teal-600 hover:bg-teal-500 transition-all shadow-lg flex items-center gap-1.5"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>保存基因节点</span>
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
