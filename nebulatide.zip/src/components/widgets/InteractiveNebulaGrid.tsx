import React, { useEffect, useRef, useState } from 'react';
import { Sparkles, RefreshCw, Zap, Maximize2, Compass, Layers, ShieldCheck } from 'lucide-react';

export interface NebulaNode {
  id: string;
  label: string;
  category: string;
  val: number; // Node strength/size
  status?: string;
  color?: string;
}

export interface NebulaLink {
  source: string;
  target: string;
  strength?: number;
}

interface InteractiveNebulaGridProps {
  nodes?: NebulaNode[];
  links?: NebulaLink[];
  title?: string;
  subtitle?: string;
  onNodeClick?: (node: NebulaNode) => void;
  className?: string;
}

// Default navigation star nodes if none provided
const DEFAULT_NODES: NebulaNode[] = [
  { id: '1', label: 'WebGL 实时渲染引擎', category: '算法攻坚', val: 14, status: 'completed' },
  { id: '2', label: 'Force-Directed 物理拓扑', category: '算法攻坚', val: 12, status: 'in-progress' },
  { id: '3', label: '音频合成与潮汐鸣响', category: '探索与创作', val: 10, status: 'in-progress' },
  { id: '4', label: '第一性原理知识图谱', category: '心智升级', val: 15, status: 'completed' },
  { id: '5', label: 'Rust WebAssembly 模块', category: '系统重构', val: 9, status: 'in-progress' },
  { id: '6', label: '响应式离线 PWA 架构', category: '系统重构', val: 11, status: 'completed' },
  { id: '7', label: '灵感片段离线快照', category: '探索与创作', val: 8, status: 'completed' },
  { id: '8', label: '全域卡片模糊与交互', category: '心智升级', val: 13, status: 'in-progress' },
];

const DEFAULT_LINKS: NebulaLink[] = [
  { source: '1', target: '2' },
  { source: '1', target: '5' },
  { source: '2', target: '4' },
  { source: '3', target: '7' },
  { source: '4', target: '8' },
  { source: '5', target: '6' },
  { source: '6', target: '7' },
  { source: '8', target: '3' },
  { source: '2', target: '8' },
];

interface PhysicsNode extends NebulaNode {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  colorHex: string;
  glowHex: string;
  pulsePhase: number;
  highlighted: boolean;
}

interface PulseBeam {
  id: string;
  sourceX: number;
  sourceY: number;
  targetX: number;
  targetY: number;
  progress: number; // 0 to 1
  speed: number;
  color: string;
}

export const InteractiveNebulaGrid: React.FC<InteractiveNebulaGridProps> = ({
  nodes = DEFAULT_NODES,
  links = DEFAULT_LINKS,
  title = '动态航星节点图谱',
  subtitle = '拖拽或点击星束节点，发射能量脉冲并探索引力拓扑',
  onNodeClick,
  className = '',
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const [selectedNode, setSelectedNode] = useState<NebulaNode | null>(null);
  const [hoveredNode, setHoveredNode] = useState<NebulaNode | null>(null);
  const [pulsesCount, setPulsesCount] = useState<number>(0);
  const [filterCategory, setFilterCategory] = useState<string>('全部');

  // Interactive state references for canvas loop
  const physicsNodesRef = useRef<PhysicsNode[]>([]);
  const pulseBeamsRef = useRef<PulseBeam[]>([]);
  const draggedNodeRef = useRef<PhysicsNode | null>(null);
  const mousePosRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  const categories = Array.from(new Set(nodes.map((n) => n.category)));

  // Color generator for node categories
  const getCategoryColor = (cat: string) => {
    switch (cat) {
      case '算法攻坚':
        return { main: '#10b981', glow: 'rgba(16, 185, 129, 0.4)' };
      case '探索与创作':
        return { main: '#6366f1', glow: 'rgba(99, 102, 241, 0.4)' };
      case '系统重构':
        return { main: '#06b6d4', glow: 'rgba(6, 182, 212, 0.4)' };
      case '心智升级':
        return { main: '#f59e0b', glow: 'rgba(245, 158, 11, 0.4)' };
      default:
        return { main: '#14b8a6', glow: 'rgba(20, 184, 166, 0.4)' };
    }
  };

  // Initialize physics simulation nodes
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const width = container.clientWidth || 800;
    const height = 420;

    const initialized: PhysicsNode[] = nodes.map((node, i) => {
      const angle = (i / nodes.length) * Math.PI * 2;
      const dist = Math.min(width, height) * 0.28 + (Math.random() * 40 - 20);
      const colorInfo = getCategoryColor(node.category);

      return {
        ...node,
        x: width / 2 + Math.cos(angle) * dist,
        y: height / 2 + Math.sin(angle) * dist,
        vx: (Math.random() - 0.5) * 0.4,
        vy: (Math.random() - 0.5) * 0.4,
        radius: Math.max(14, Math.min(26, node.val * 1.3)),
        colorHex: colorInfo.main,
        glowHex: colorInfo.glow,
        pulsePhase: Math.random() * Math.PI * 2,
        highlighted: false,
      };
    });

    physicsNodesRef.current = initialized;
  }, [nodes]);

  // Main Canvas Render & Physics Animation Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;

    const updateCanvasSize = () => {
      if (!containerRef.current || !canvas) return;
      const rect = containerRef.current.getBoundingClientRect();
      const dpr = window.devicePixelRatio || 1;
      const h = rect.width < 640 ? 360 : rect.width < 1024 ? 420 : rect.width < 1440 ? 460 : 520;
      canvas.width = rect.width * dpr;
      canvas.height = h * dpr;
      ctx.scale(dpr, dpr);
    };

    updateCanvasSize();
    window.addEventListener('resize', updateCanvasSize);

    // Particle flow ticks along links
    let globalTime = 0;

    const render = () => {
      globalTime += 0.015;
      const width = canvas.width / (window.devicePixelRatio || 1);
      const height = canvas.height / (window.devicePixelRatio || 1);

      ctx.clearRect(0, 0, width, height);

      const pNodes = physicsNodesRef.current;
      const pBeams = pulseBeamsRef.current;

      // 1. Force-Directed Physics Updates
      const cx = width / 2;
      const cy = height / 2;

      for (let i = 0; i < pNodes.length; i++) {
        const n1 = pNodes[i];
        if (n1 === draggedNodeRef.current) continue;

        // Centripetal spring force
        const dx = cx - n1.x;
        const dy = cy - n1.y;
        n1.vx += dx * 0.00015;
        n1.vy += dy * 0.00015;

        // Repulsion between nodes
        for (let j = i + 1; j < pNodes.length; j++) {
          const n2 = pNodes[j];
          const rx = n2.x - n1.x;
          const ry = n2.y - n1.y;
          const distSq = rx * rx + ry * ry + 0.1;
          const dist = Math.sqrt(distSq);

          if (dist < 180) {
            const force = (180 - dist) / 180;
            const fx = (rx / dist) * force * 0.12;
            const fy = (ry / dist) * force * 0.12;

            n1.vx -= fx;
            n1.vy -= fy;
            if (n2 !== draggedNodeRef.current) {
              n2.vx += fx;
              n2.vy += fy;
            }
          }
        }

        // Apply friction & boundary soft padding
        n1.vx *= 0.92;
        n1.vy *= 0.92;

        n1.x += n1.vx;
        n1.y += n1.vy;

        // Soft wall bounds
        const pad = 40;
        if (n1.x < pad) { n1.x = pad; n1.vx *= -0.5; }
        if (n1.x > width - pad) { n1.x = width - pad; n1.vx *= -0.5; }
        if (n1.y < pad) { n1.y = pad; n1.vy *= -0.5; }
        if (n1.y > height - pad) { n1.y = height - pad; n1.vy *= -0.5; }
      }

      // 2. Draw Gravitational Link Lines & Ambient Energy Particles
      links.forEach((link) => {
        const sourceNode = pNodes.find((n) => n.id === link.source);
        const targetNode = pNodes.find((n) => n.id === link.target);

        if (!sourceNode || !targetNode) return;

        const isFilteredOut =
          filterCategory !== '全部' &&
          sourceNode.category !== filterCategory &&
          targetNode.category !== filterCategory;

        const isHighlightedLink =
          selectedNode &&
          (selectedNode.id === sourceNode.id || selectedNode.id === targetNode.id);

        const linkAlpha = isFilteredOut ? 0.08 : isHighlightedLink ? 0.7 : 0.25;

        // Draw Line
        ctx.beginPath();
        ctx.moveTo(sourceNode.x, sourceNode.y);
        ctx.lineTo(targetNode.x, targetNode.y);

        const lineGrad = ctx.createLinearGradient(
          sourceNode.x,
          sourceNode.y,
          targetNode.x,
          targetNode.y
        );
        lineGrad.addColorStop(0, sourceNode.colorHex);
        lineGrad.addColorStop(1, targetNode.colorHex);

        ctx.strokeStyle = lineGrad;
        ctx.lineWidth = isHighlightedLink ? 2.5 : 1.2;
        ctx.globalAlpha = linkAlpha;
        ctx.stroke();
        ctx.globalAlpha = 1.0;

        // Draw Ambient Flowing Energy Particle along line
        if (!isFilteredOut) {
          const flowProgress = (globalTime * 0.4 + parseInt(sourceNode.id, 10)) % 1;
          const px = sourceNode.x + (targetNode.x - sourceNode.x) * flowProgress;
          const py = sourceNode.y + (targetNode.y - sourceNode.y) * flowProgress;

          ctx.beginPath();
          ctx.arc(px, py, isHighlightedLink ? 2.8 : 1.8, 0, Math.PI * 2);
          ctx.fillStyle = sourceNode.colorHex;
          ctx.shadowColor = sourceNode.colorHex;
          ctx.shadowBlur = 6;
          ctx.fill();
          ctx.shadowBlur = 0;
        }
      });

      // 3. Render Pulse Energy Beams (Fired on click/hover)
      for (let i = pBeams.length - 1; i >= 0; i--) {
        const beam = pBeams[i];
        beam.progress += beam.speed;

        if (beam.progress >= 1) {
          pBeams.splice(i, 1);
          continue;
        }

        const currX = beam.sourceX + (beam.targetX - beam.sourceX) * beam.progress;
        const currY = beam.sourceY + (beam.targetY - beam.sourceY) * beam.progress;

        // Beam Tail
        const tailProgress = Math.max(0, beam.progress - 0.2);
        const tailX = beam.sourceX + (beam.targetX - beam.sourceX) * tailProgress;
        const tailY = beam.sourceY + (beam.targetY - beam.sourceY) * tailProgress;

        const beamGrad = ctx.createLinearGradient(tailX, tailY, currX, currY);
        beamGrad.addColorStop(0, 'transparent');
        beamGrad.addColorStop(1, beam.color);

        ctx.beginPath();
        ctx.moveTo(tailX, tailY);
        ctx.lineTo(currX, currY);
        ctx.strokeStyle = beamGrad;
        ctx.lineWidth = 4;
        ctx.stroke();

        // Beam Head Pulse Spark
        ctx.beginPath();
        ctx.arc(currX, currY, 5, 0, Math.PI * 2);
        ctx.fillStyle = '#ffffff';
        ctx.shadowColor = beam.color;
        ctx.shadowBlur = 12;
        ctx.fill();
        ctx.shadowBlur = 0;
      }

      // 4. Render Nodes (Stars)
      pNodes.forEach((node) => {
        const isSelected = selectedNode?.id === node.id;
        const isHovered = hoveredNode?.id === node.id;
        const isMatchCategory = filterCategory === '全部' || node.category === filterCategory;

        node.pulsePhase += 0.03;
        const breathe = Math.sin(node.pulsePhase) * 2;

        const currentRadius = node.radius + (isSelected ? 4 : isHovered ? 2 : breathe);
        const alpha = isMatchCategory ? 1 : 0.3;

        ctx.globalAlpha = alpha;

        // Node Glow Ring
        const glowGrad = ctx.createRadialGradient(
          node.x,
          node.y,
          0,
          node.x,
          node.y,
          currentRadius * 2.2
        );
        glowGrad.addColorStop(0, node.glowHex);
        glowGrad.addColorStop(1, 'transparent');

        ctx.fillStyle = glowGrad;
        ctx.beginPath();
        ctx.arc(node.x, node.y, currentRadius * 2.2, 0, Math.PI * 2);
        ctx.fill();

        // Outer Orbit Ring for Selected or Completed Status
        if (isSelected || node.status === 'completed') {
          ctx.beginPath();
          ctx.arc(node.x, node.y, currentRadius + 5, 0, Math.PI * 2);
          ctx.strokeStyle = isSelected ? '#ffffff' : node.colorHex;
          ctx.lineWidth = isSelected ? 2 : 1;
          ctx.setLineDash([4, 4]);
          ctx.stroke();
          ctx.setLineDash([]);
        }

        // Inner Star Circle
        ctx.beginPath();
        ctx.arc(node.x, node.y, currentRadius, 0, Math.PI * 2);
        ctx.fillStyle = node.colorHex;
        ctx.shadowColor = node.colorHex;
        ctx.shadowBlur = isSelected ? 20 : 10;
        ctx.fill();
        ctx.shadowBlur = 0;

        // Label Text
        ctx.font = `${isSelected ? 'bold 12px' : '11px'} sans-serif`;
        ctx.fillStyle = isSelected ? '#38bdf8' : '#e2e8f0';
        ctx.textAlign = 'center';
        ctx.fillText(node.label, node.x, node.y + currentRadius + 18);

        // Category Subtag
        ctx.font = '9px monospace';
        ctx.fillStyle = '#94a3b8';
        ctx.fillText(node.category, node.x, node.y + currentRadius + 30);

        ctx.globalAlpha = 1.0;
      });

      animationId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', updateCanvasSize);
      cancelAnimationFrame(animationId);
    };
  }, [links, selectedNode, hoveredNode, filterCategory]);

  // Trigger Energy Pulse Beam Emission to neighbors
  const triggerPulseBeams = (sourceNode: PhysicsNode) => {
    const pNodes = physicsNodesRef.current;
    const connectedLinks = links.filter(
      (l) => l.source === sourceNode.id || l.target === sourceNode.id
    );

    const newBeams: PulseBeam[] = [];

    connectedLinks.forEach((l) => {
      const targetId = l.source === sourceNode.id ? l.target : l.source;
      const targetNode = pNodes.find((n) => n.id === targetId);

      if (targetNode) {
        newBeams.push({
          id: `beam-${Date.now()}-${Math.random()}`,
          sourceX: sourceNode.x,
          sourceY: sourceNode.y,
          targetX: targetNode.x,
          targetY: targetNode.y,
          progress: 0,
          speed: 0.035 + Math.random() * 0.015,
          color: sourceNode.colorHex,
        });
      }
    });

    pulseBeamsRef.current.push(...newBeams);
    setPulsesCount((prev) => prev + newBeams.length);
  };

  // Mouse / Touch Event Handlers
  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const clickedNode = physicsNodesRef.current.find((n) => {
      const dx = n.x - x;
      const dy = n.y - y;
      return Math.sqrt(dx * dx + dy * dy) <= n.radius + 8;
    });

    if (clickedNode) {
      draggedNodeRef.current = clickedNode;
      setSelectedNode(clickedNode);
      triggerPulseBeams(clickedNode);
      if (onNodeClick) onNodeClick(clickedNode);
    } else {
      setSelectedNode(null);
    }
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    mousePosRef.current = { x, y };

    if (draggedNodeRef.current) {
      draggedNodeRef.current.x = x;
      draggedNodeRef.current.y = y;
      draggedNodeRef.current.vx = 0;
      draggedNodeRef.current.vy = 0;
    } else {
      const found = physicsNodesRef.current.find((n) => {
        const dx = n.x - x;
        const dy = n.y - y;
        return Math.sqrt(dx * dx + dy * dy) <= n.radius + 8;
      });

      if (found !== hoveredNode) {
        setHoveredNode(found || null);
        if (found) {
          triggerPulseBeams(found);
        }
      }
    }
  };

  const handlePointerUp = () => {
    draggedNodeRef.current = null;
  };

  // Re-layout / Jiggle nodes
  const handleRebalance = () => {
    physicsNodesRef.current.forEach((n) => {
      n.vx += (Math.random() - 0.5) * 8;
      n.vy += (Math.random() - 0.5) * 8;
    });
  };

  return (
    <div
      ref={containerRef}
      className={`bg-white/80 dark:bg-slate-900/90 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-5 sm:p-6 shadow-sm dark:shadow-2xl backdrop-blur-xl relative overflow-hidden text-slate-900 dark:text-slate-100 ${className}`}
    >
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4 relative z-10">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-teal-600 dark:text-teal-400 animate-pulse" />
            <h3 className="text-lg font-bold font-serif text-slate-900 dark:text-white">
              {title}
            </h3>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-teal-500/10 text-teal-600 dark:text-teal-400 border border-teal-500/30">
              Force Grid
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400">{subtitle}</p>
        </div>

        {/* Controls */}
        <div className="flex items-center gap-2 shrink-0">
          <div className="text-[10px] font-mono text-slate-400 bg-slate-100 dark:bg-slate-950 px-2.5 py-1 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center gap-1.5">
            <Zap className="w-3 h-3 text-amber-500" />
            <span>能量脉冲: {pulsesCount}</span>
          </div>

          <button
            onClick={handleRebalance}
            className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 transition-all text-xs flex items-center gap-1"
            title="激发星系拓扑引力"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">重置力场</span>
          </button>
        </div>
      </div>

      {/* Category Filter Chips */}
      <div className="flex items-center gap-1.5 overflow-x-auto custom-scrollbar pb-3 mb-2 relative z-10">
        <button
          onClick={() => setFilterCategory('全部')}
          className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
            filterCategory === '全部'
              ? 'bg-teal-600 text-white font-semibold shadow-sm'
              : 'bg-slate-100 dark:bg-slate-800/60 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
          }`}
        >
          全天星区
        </button>
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setFilterCategory(cat)}
            className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
              filterCategory === cat
                ? 'bg-teal-600 text-white font-semibold shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800/60 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Canvas Node Container */}
      <div className="relative rounded-2xl bg-slate-950/90 dark:bg-slate-950/90 border border-slate-800 overflow-hidden shadow-inner cursor-grab active:cursor-grabbing">
        <canvas
          ref={canvasRef}
          className="w-full h-[360px] sm:h-[420px] lg:h-[460px] xl:h-[520px] block"
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerLeave={handlePointerUp}
        />

        {/* Selected Node Drawer / Tooltip Badge */}
        {selectedNode && (
          <div className="absolute bottom-4 left-4 right-4 sm:left-6 sm:right-auto bg-slate-900/90 border border-teal-500/40 rounded-2xl p-3.5 backdrop-blur-md shadow-2xl animate-in slide-in-from-bottom-2 duration-200 max-w-sm text-xs space-y-1.5 text-slate-200 z-20">
            <div className="flex items-center justify-between gap-2">
              <span className="font-bold text-teal-300 font-serif text-sm">
                {selectedNode.label}
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-teal-500/20 text-teal-300 border border-teal-500/30">
                {selectedNode.category}
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              节点引力值: {selectedNode.val} • 状态: {selectedNode.status === 'completed' ? '已收录珍珠' : '推进织网中'}
            </p>
            <div className="text-[10px] text-teal-400/90 font-mono flex items-center gap-1 pt-1 border-t border-slate-800">
              <Zap className="w-3 h-3 text-amber-400" />
              <span>已向邻近拓扑节点传输能量光束</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
