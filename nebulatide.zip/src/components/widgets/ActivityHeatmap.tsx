import React, { useState, useEffect } from 'react';
import { Calendar as CalendarIcon, Sparkles, Flame, Waves, CheckCircle2 } from 'lucide-react';

interface ActivityHeatmapProps {
  onSelectDate?: (dateStr: string) => void;
}

export const ActivityHeatmap: React.FC<ActivityHeatmapProps> = ({ onSelectDate }) => {
  const [activities, setActivities] = useState<Record<string, number>>({});
  const [hoveredDay, setHoveredDay] = useState<{ date: string; count: number } | null>(null);
  const [selectedYear, setSelectedYear] = useState(2026);

  // Initialize or fetch heat map activity counts
  useEffect(() => {
    const activityData: Record<string, number> = {};
    const startDate = new Date(selectedYear, 0, 1);
    const endDate = new Date(selectedYear, 11, 31);
    const curr = new Date(startDate);

    // Seed mock activity representing consistent commits & tide reviews
    while (curr <= endDate) {
      const year = curr.getFullYear();
      const month = String(curr.getMonth() + 1).padStart(2, '0');
      const day = String(curr.getDate()).padStart(2, '0');
      const key = `${year}-${month}-${day}`;

      // Pseudo-random but consistent pattern with higher activity on active months
      const dayVal = curr.getDate() + curr.getMonth() * 31;
      let count = 0;
      if (dayVal % 7 === 0 || dayVal % 5 === 0) count = 3;
      else if (dayVal % 3 === 0) count = 2;
      else if (dayVal % 2 === 0) count = 1;
      else if (dayVal % 13 === 0) count = 4;

      activityData[key] = count;
      curr.setDate(curr.getDate() + 1);
    }

    // Merge saved custom notes count from localStorage
    const savedNotes = localStorage.getItem('nebulatide_daily_notes');
    if (savedNotes) {
      try {
        const parsed = JSON.parse(savedNotes);
        Object.keys(parsed).forEach((k) => {
          if (parsed[k]) activityData[k] = (activityData[k] || 0) + 2;
        });
      } catch (e) {
        console.error(e);
      }
    }

    setActivities(activityData);
  }, [selectedYear]);

  // Generate 52-week columns
  const generateWeeks = () => {
    const weeks: { dateStr: string; count: number; dateObj: Date }[][] = [];
    const startDate = new Date(selectedYear, 0, 1);
    
    // Adjust start to previous Sunday/Monday for alignment
    const firstDayOfWeek = startDate.getDay();
    const curr = new Date(startDate);
    curr.setDate(curr.getDate() - firstDayOfWeek);

    for (let w = 0; w < 53; w++) {
      const weekDays = [];
      for (let d = 0; d < 7; d++) {
        const year = curr.getFullYear();
        const month = String(curr.getMonth() + 1).padStart(2, '0');
        const day = String(curr.getDate()).padStart(2, '0');
        const dateStr = `${year}-${month}-${day}`;
        const count = year === selectedYear ? activities[dateStr] || 0 : -1;

        weekDays.push({
          dateStr,
          count,
          dateObj: new Date(curr),
        });
        curr.setDate(curr.getDate() + 1);
      }
      weeks.push(weekDays);
    }
    return weeks;
  };

  const weeks = generateWeeks();

  const getColorClass = (count: number) => {
    if (count < 0) return 'bg-transparent border-transparent pointer-events-none';
    if (count === 0) return 'bg-slate-100 dark:bg-slate-900/80 border-slate-200 dark:border-slate-800/80 hover:border-slate-300 dark:hover:border-slate-700';
    if (count === 1) return 'bg-teal-100 dark:bg-teal-950 border-teal-300 dark:border-teal-800/60 shadow-sm';
    if (count === 2) return 'bg-teal-300 dark:bg-teal-800/60 border-teal-400 dark:border-teal-600/60 text-teal-900';
    if (count === 3) return 'bg-teal-500 dark:bg-teal-600 border-teal-400 dark:border-teal-400/80 shadow-md shadow-teal-500/20';
    return 'bg-gradient-to-r from-teal-400 to-emerald-400 border-emerald-300 dark:border-emerald-300 shadow-lg shadow-teal-500/40 animate-pulse';
  };

  const monthsLabel = ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'];

  return (
    <div className="bg-white/80 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm dark:shadow-xl space-y-4 backdrop-blur-md text-slate-900 dark:text-slate-100">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200 dark:border-slate-800/80">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-xl bg-teal-50 dark:bg-teal-950 border border-teal-200 dark:border-teal-500/30 text-teal-600 dark:text-teal-400">
            <Flame className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm sm:text-base font-bold font-serif text-slate-900 dark:text-white flex items-center gap-2">
              <span>潮汐能量与 Commit 热力图</span>
              <span className="text-xs font-mono text-teal-800 dark:text-teal-300 bg-teal-100 dark:bg-teal-950/80 px-2.5 py-0.5 rounded-full border border-teal-300 dark:border-teal-500/20">
                {selectedYear} 年
              </span>
            </h3>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 font-light">
              每天 × 365 = 37× 的复利逻辑，每个深色格子均记录了一次思考、代码提交或潮汐复盘
            </p>
          </div>
        </div>

        {/* Legend */}
        <div className="flex items-center gap-2 text-[10px] font-mono text-slate-500 dark:text-slate-400">
          <span>少</span>
          <div className="flex items-center gap-1">
            <div className="w-2.5 h-2.5 rounded-sm bg-slate-100 dark:bg-slate-900 border border-slate-300 dark:border-slate-800" />
            <div className="w-2.5 h-2.5 rounded-sm bg-teal-100 dark:bg-teal-950 border border-teal-300 dark:border-teal-800" />
            <div className="w-2.5 h-2.5 rounded-sm bg-teal-300 dark:bg-teal-800/60 border border-teal-400 dark:border-teal-600" />
            <div className="w-2.5 h-2.5 rounded-sm bg-teal-500 dark:bg-teal-600 border border-teal-400" />
            <div className="w-2.5 h-2.5 rounded-sm bg-emerald-400 border border-emerald-300" />
          </div>
          <span>多 (高能涨潮)</span>
        </div>
      </div>

      {/* Months axis */}
      <div className="overflow-x-auto custom-scrollbar pb-2">
        <div className="min-w-[680px]">
          <div className="flex justify-between text-[10px] font-mono text-slate-500 dark:text-slate-400 px-1 mb-1">
            {monthsLabel.map((m) => (
              <span key={m}>{m}</span>
            ))}
          </div>

          {/* Grid of Weeks */}
          <div className="flex gap-1.5">
            {weeks.map((week, wIndex) => (
              <div key={wIndex} className="flex flex-col gap-1.5">
                {week.map((day, dIndex) => (
                  <button
                    key={dIndex}
                    id={`heatmap-cell-${day.dateStr}`}
                    onClick={() => day.count >= 0 && onSelectDate?.(day.dateStr)}
                    onMouseEnter={() => day.count >= 0 && setHoveredDay({ date: day.dateStr, count: day.count })}
                    onMouseLeave={() => setHoveredDay(null)}
                    className={`w-3 h-3 rounded-[3px] border transition-all duration-150 ${getColorClass(
                      day.count
                    )}`}
                    title={day.count >= 0 ? `${day.dateStr}: ${day.count} 次潮汐沉淀` : ''}
                  />
                ))}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Hover tooltip / Status bar */}
      <div className="flex items-center justify-between text-xs font-mono text-slate-500 dark:text-slate-400 pt-1 border-t border-slate-200 dark:border-slate-800/60">
        <span>
          {hoveredDay ? (
            <span className="text-teal-700 dark:text-teal-300 font-semibold">
              📅 {hoveredDay.date} — {hoveredDay.count} 次复盘与 Commit 沉淀
            </span>
          ) : (
            <span>点击任意日期可开启或查看当日潮汐日志 (Daily Note)</span>
          )}
        </span>
        <span className="hidden sm:inline-block text-slate-500 dark:text-slate-400">
          状态: 🌊 365天持续复利中
        </span>
      </div>

    </div>
  );
};
