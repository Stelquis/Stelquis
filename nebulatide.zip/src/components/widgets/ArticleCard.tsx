import React from 'react';
import { Post } from '../../types';
import { Clock, Heart, ArrowUpRight, Sparkles } from 'lucide-react';
import { SpotlightCard } from './SpotlightCard';

interface ArticleCardProps {
  post: Post;
  onSelect: (post: Post) => void;
  onLike: (postId: string, e: React.MouseEvent) => void;
}

export const ArticleCard: React.FC<ArticleCardProps> = ({ post, onSelect, onLike }) => {
  return (
    <SpotlightCard
      id={`article-card-${post.id}`}
      onClick={() => onSelect(post)}
      className="group bg-white/80 dark:bg-slate-900 backdrop-blur-xl border border-slate-200/80 dark:border-slate-800 hover:border-teal-500/50 rounded-2xl overflow-hidden shadow-sm dark:shadow-lg hover:shadow-xl dark:hover:shadow-teal-950/30 transition-all duration-300 flex flex-col justify-between cursor-pointer"
      spotlightColor="rgba(20, 184, 166, 0.15)"
    >
      {/* Cover Image */}
      <div className="relative h-48 sm:h-52 w-full overflow-hidden bg-slate-100 dark:bg-slate-950">
        <img
          src={post.coverImage}
          alt={post.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-90 group-hover:opacity-100"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 dark:from-slate-950 via-transparent to-transparent" />
        
        {/* Category Pill */}
        <div className="absolute top-3 left-3">
          <span className="px-3 py-1 rounded-full text-[11px] font-medium bg-slate-950/80 backdrop-blur-md text-teal-300 border border-teal-500/30 shadow-sm">
            {post.category}
          </span>
        </div>

        {post.featured && (
          <div className="absolute top-3 right-3">
            <span className="px-2.5 py-1 rounded-full text-[10px] font-semibold bg-amber-500/20 backdrop-blur-md text-amber-300 border border-amber-500/40 flex items-center gap-1 shadow-sm">
              <Sparkles className="w-3 h-3 text-amber-400" /> 推荐精选
            </span>
          </div>
        )}
      </div>

      {/* Card Body */}
      <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 font-mono">
            <span>{post.date}</span>
            <span>•</span>
            <span className="flex items-center gap-1">
              <Clock className="w-3 h-3 text-slate-400" />
              {post.readTime}
            </span>
          </div>

          <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100 group-hover:text-teal-600 dark:group-hover:text-teal-300 transition-colors line-clamp-2 font-serif leading-snug">
            {post.title}
          </h3>

          <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-2 font-light leading-relaxed">
            {post.excerpt}
          </p>
        </div>

        {/* Tags */}
        <div className="flex flex-wrap gap-1.5 pt-1">
          {post.tags.map((tag) => (
            <span
              key={tag}
              className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 hover:text-teal-600 dark:hover:text-teal-300 transition-colors"
            >
              #{tag}
            </span>
          ))}
        </div>

        {/* Card Footer */}
        <div className="pt-3 border-t border-slate-200 dark:border-slate-800/80 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
          <div className="flex items-center gap-2">
            <img
              src={post.author.avatar}
              alt={post.author.name}
              className="w-5 h-5 rounded-full object-cover"
            />
            <span className="text-slate-700 dark:text-slate-300 text-xs font-medium">{post.author.name}</span>
          </div>

          <div className="flex items-center gap-3">
            <button
              id={`like-post-${post.id}`}
              onClick={(e) => onLike(post.id, e)}
              className="flex items-center gap-1 text-slate-500 dark:text-slate-400 hover:text-rose-500 dark:hover:text-rose-400 transition-colors"
              title="认可这篇思考"
            >
              <Heart className="w-3.5 h-3.5 fill-current text-slate-400 dark:text-slate-500 hover:text-rose-500" />
              <span className="text-xs">{post.likes}</span>
            </button>
            <div className="text-teal-600 dark:text-teal-400 group-hover:translate-x-0.5 transition-transform">
              <ArrowUpRight className="w-4 h-4" />
            </div>
          </div>
        </div>
      </div>
    </SpotlightCard>
  );
};

