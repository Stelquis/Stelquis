import React, { useEffect, useState, useCallback } from 'react';

interface TextScrambleProps {
  text: string;
  className?: string;
  scrambleSpeed?: number;
  triggerOnHover?: boolean;
}

const CHARS = '░▒▓█<>/\\|[]{}—=+*^?#~ΔΨΦΩ✦✧🌊✨';

export const TextScramble: React.FC<TextScrambleProps> = ({
  text,
  className = '',
  scrambleSpeed = 30,
  triggerOnHover = true,
}) => {
  const [displayText, setDisplayText] = useState(text);
  const [isScrambling, setIsScrambling] = useState(false);

  const scramble = useCallback(() => {
    if (isScrambling) return;
    setIsScrambling(true);

    let iteration = 0;
    const maxIterations = text.length * 2;

    const interval = setInterval(() => {
      setDisplayText(() =>
        text
          .split('')
          .map((char, index) => {
            if (char === ' ' || char === '×' || char === '·') return char;
            if (index < iteration / 2) {
              return text[index];
            }
            return CHARS[Math.floor(Math.random() * CHARS.length)];
          })
          .join('')
      );

      iteration += 1;

      if (iteration > maxIterations) {
        clearInterval(interval);
        setDisplayText(text);
        setIsScrambling(false);
      }
    }, scrambleSpeed);
  }, [text, scrambleSpeed, isScrambling]);

  useEffect(() => {
    scramble();
  }, []);

  return (
    <span
      className={`inline-block cursor-pointer font-mono tracking-wide ${className}`}
      onMouseEnter={() => triggerOnHover && scramble()}
    >
      {displayText}
    </span>
  );
};
