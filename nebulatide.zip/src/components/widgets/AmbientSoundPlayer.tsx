import React, { useState, useEffect, useRef } from 'react';
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Repeat,
  Upload,
  Video,
  Music,
  Sparkles,
  X,
  Film,
  Disc,
  RotateCcw,
  AlertCircle,
} from 'lucide-react';
import {
  ActiveMedia,
  DEFAULT_MEDIA,
  getActiveMedia,
  saveActiveMedia,
  resetToDefaultMedia,
} from '../../utils/mediaDb';

export const AmbientSoundPlayer: React.FC = () => {
  const [media, setMedia] = useState<ActiveMedia>(DEFAULT_MEDIA);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);
  const [volume, setVolume] = useState<number>(0.6);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isLooping, setIsLooping] = useState<boolean>(true);

  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [isUploading, setIsUploading] = useState<boolean>(false);
  const [uploadError, setUploadError] = useState<string | null>(null);

  const mediaRef = useRef<HTMLVideoElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Load saved custom media if available
  useEffect(() => {
    let isMounted = true;
    getActiveMedia().then((savedMedia) => {
      if (isMounted && savedMedia) {
        setMedia(savedMedia);
      }
    });
    return () => {
      isMounted = false;
    };
  }, []);

  // Update volume & mute on media element
  useEffect(() => {
    if (mediaRef.current) {
      mediaRef.current.volume = isMuted ? 0 : volume;
    }
  }, [volume, isMuted]);

  // Handle source changes
  useEffect(() => {
    if (mediaRef.current) {
      mediaRef.current.currentTime = 0;
      setCurrentTime(0);
      if (isPlaying) {
        mediaRef.current.play().catch((err) => {
          console.warn('Autoplay error:', err);
          setIsPlaying(false);
        });
      }
    }
  }, [media.url]);

  const togglePlay = () => {
    if (!mediaRef.current) return;

    if (isPlaying) {
      mediaRef.current.pause();
      setIsPlaying(false);
    } else {
      mediaRef.current
        .play()
        .then(() => setIsPlaying(true))
        .catch((err) => {
          console.warn('Playback error:', err);
          setIsPlaying(false);
        });
    }
  };

  const handleEnded = () => {
    if (isLooping && mediaRef.current) {
      mediaRef.current.currentTime = 0;
      mediaRef.current.play().catch((err) => {
        console.warn('Loop play error:', err);
        setIsPlaying(false);
      });
    } else {
      setIsPlaying(false);
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newTime = parseFloat(e.target.value);
    if (mediaRef.current) {
      mediaRef.current.currentTime = newTime;
      setCurrentTime(newTime);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const file = files[0];
    if (!file.type.startsWith('audio/') && !file.type.startsWith('video/')) {
      setUploadError('请选择有效的音频或视频文件 (如 MP3, MP4, WAV 等)');
      return;
    }

    setIsUploading(true);
    setUploadError(null);

    try {
      const newMedia = await saveActiveMedia(file);
      setMedia(newMedia);
      setIsPlaying(true);
    } catch (err: any) {
      setUploadError(err.message || '替换音视频介质失败，请重试');
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleResetMedia = async () => {
    const defaultMedia = await resetToDefaultMedia();
    setMedia(defaultMedia);
    setIsPlaying(false);
    setUploadError(null);
  };

  const formatTime = (seconds: number) => {
    if (isNaN(seconds) || seconds < 0) return '00:00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="relative inline-block">
      {/* Underlying Audio/Video HTML Element */}
      <video
        ref={mediaRef}
        src={media.url}
        onTimeUpdate={() => mediaRef.current && setCurrentTime(mediaRef.current.currentTime)}
        onLoadedMetadata={() => mediaRef.current && setDuration(mediaRef.current.duration)}
        onEnded={handleEnded}
        playsInline
        className="hidden"
      />

      {/* Navbar Widget Trigger Button - Responsive Single Icon on Mobile */}
      <button
        id="ambient-sound-toggle"
        onClick={() => setIsOpen(!isOpen)}
        className={`p-2 sm:px-3 sm:py-1.5 rounded-full text-xs font-medium transition-all border shrink-0 flex items-center justify-center gap-1.5 sm:gap-2 active:scale-95 ${
          isPlaying
            ? 'bg-teal-50 dark:bg-teal-950/90 border-teal-400 dark:border-teal-500/70 text-teal-800 dark:text-teal-300 shadow-[0_0_16px_rgba(20,184,166,0.2)]'
            : 'bg-white dark:bg-slate-900/90 border-slate-200 dark:border-slate-700/70 text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:border-teal-500/50'
        }`}
        title="点击调出潮汐声学与视听控制台"
      >
        {/* On mobile: single icon (Disc). On sm+: Sparkles on left */}
        <Sparkles className={`hidden sm:block w-3.5 h-3.5 shrink-0 ${isPlaying ? 'animate-spin text-teal-600 dark:text-teal-400' : 'text-slate-400'}`} />

        {/* Disc Icon shown on mobile always (single icon), and on sm+ when paused */}
        <Disc className={`w-4 h-4 sm:w-3.5 sm:h-3.5 shrink-0 ${isPlaying ? 'animate-spin text-teal-600 dark:text-teal-400' : 'text-slate-400'} ${isPlaying ? 'sm:hidden' : ''}`} />

        {/* Text name shown on sm+ */}
        <span className="hidden sm:inline-block max-w-[100px] sm:max-w-[120px] truncate">
          {isPlaying ? media.name : '潮汐介质'}
        </span>

        {/* Sound wave bars shown on sm+ when playing */}
        {isPlaying ? (
          <div className="hidden sm:flex items-end gap-0.5 h-3.5 px-0.5 shrink-0">
            <span className="w-0.5 bg-teal-500 dark:bg-teal-400 animate-[bounce_0.8s_infinite_100ms] h-3" />
            <span className="w-0.5 bg-teal-400 dark:bg-teal-300 animate-[bounce_0.8s_infinite_300ms] h-2" />
            <span className="w-0.5 bg-teal-500 dark:bg-teal-400 animate-[bounce_0.8s_infinite_200ms] h-3.5" />
          </div>
        ) : null}
      </button>

      {/* Backdrop for click-outside dismissal with daylight/darkness glass blur */}
      {isOpen && (
        <div
          className="fixed inset-0 z-40 bg-slate-900/40 dark:bg-slate-950/70 backdrop-blur-md sm:backdrop-blur-xl transition-all"
          onClick={(e) => {
            e.stopPropagation();
            setIsOpen(false);
          }}
        />
      )}

      {/* Anchored Dropdown Popover Card for Desktop / Responsive Modal for Mobile */}
      {isOpen && (
        <div
          className="fixed inset-x-3 top-16 sm:top-auto sm:inset-auto sm:absolute sm:right-0 sm:top-full sm:mt-2.5 z-50 w-auto sm:w-[320px] max-w-[calc(100vw-24px)] mx-auto sm:mx-0 animate-in fade-in slide-in-from-top-2 duration-200"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Top Arrow Pointer (Desktop only) */}
          <div className="absolute -top-1.5 right-8 w-3 h-3 bg-white dark:bg-slate-900 border-t border-l border-slate-200 dark:border-teal-500/40 rotate-45 z-10 hidden sm:block" />

          {/* Card Container - Compact & Refined */}
          <div className="bg-white/95 dark:bg-slate-900/95 backdrop-blur-2xl border border-slate-200 dark:border-teal-500/30 rounded-2xl shadow-xl dark:shadow-[0_20px_50px_rgba(0,0,0,0.85),0_0_25px_rgba(20,184,166,0.12)] p-3.5 sm:p-4 flex flex-col space-y-2.5 relative overflow-hidden max-h-[85vh] sm:max-h-none overflow-y-auto custom-scrollbar text-slate-900 dark:text-slate-100">
            {/* Background Glow Effect */}
            <div className="absolute -top-12 -right-12 w-36 h-36 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />

            {/* Header */}
            <div className="flex items-center justify-between pb-2.5 border-b border-slate-200 dark:border-slate-800/80">
              <div className="flex items-center gap-2">
                <div className="p-1.5 bg-teal-50 dark:bg-teal-950/90 border border-teal-200 dark:border-teal-500/40 rounded-lg text-teal-600 dark:text-teal-400">
                  <Film className="w-3.5 h-3.5" />
                </div>
                <div className="flex items-center gap-2">
                  <h3 className="text-xs font-bold text-slate-900 dark:text-white font-serif">潮汐声学与视听</h3>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-teal-100 dark:bg-teal-950/80 text-teal-800 dark:text-teal-300 border border-teal-300 dark:border-teal-500/30">
                    {media.type === 'video' ? 'MV 视频' : 'MP3 音频'}
                  </span>
                </div>
              </div>

              <button
                id="sound-options-close"
                onClick={() => setIsOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-800 dark:hover:text-white bg-slate-100 dark:bg-slate-800/60 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-full transition-colors"
                title="关闭控制卡片"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Media Player Visual Viewport */}
            <div className="relative bg-slate-900 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800/90 overflow-hidden flex flex-col items-center justify-center shadow-inner group">
              {media.type === 'video' ? (
                <div className="relative w-full aspect-video bg-black flex items-center justify-center overflow-hidden">
                  <video
                    src={media.url}
                    autoPlay={isPlaying}
                    loop={isLooping}
                    muted={isMuted}
                    playsInline
                    onClick={togglePlay}
                    ref={(node) => {
                      if (node && mediaRef.current) {
                        node.currentTime = currentTime;
                      }
                    }}
                    className="w-full h-full object-cover cursor-pointer"
                  />
                  {!isPlaying && (
                    <button
                      onClick={togglePlay}
                      className="absolute inset-0 m-auto w-11 h-11 rounded-full bg-teal-500/90 hover:bg-teal-400 text-slate-950 flex items-center justify-center shadow-xl backdrop-blur-sm transition-transform hover:scale-110"
                    >
                      <Play className="w-5 h-5 fill-current ml-0.5" />
                    </button>
                  )}
                  <span className="absolute top-2 left-2 px-2 py-0.5 rounded bg-slate-950/80 text-[10px] font-mono text-indigo-300 border border-indigo-500/30 flex items-center gap-1 backdrop-blur-sm">
                    <Video className="w-3 h-3" /> MV 视听画面
                  </span>
                </div>
              ) : (
                <div className="py-6 px-4 w-full flex flex-col items-center justify-center space-y-2.5 bg-gradient-to-br from-teal-500/5 via-slate-100 to-teal-100/50 dark:from-slate-900 dark:via-slate-950 dark:to-teal-950/30">
                  <div className="relative">
                    <div
                      className={`w-16 h-16 rounded-full border-2 border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 flex items-center justify-center shadow-lg transition-transform duration-1000 ${
                        isPlaying ? 'animate-[spin_8s_linear_infinite]' : ''
                      }`}
                    >
                      <div className="w-6 h-6 rounded-full bg-slate-100 dark:bg-slate-900 border border-teal-500/50 flex items-center justify-center">
                        <Music className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                      </div>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded bg-white/90 dark:bg-slate-900/90 text-[10px] font-mono text-teal-700 dark:text-teal-300 border border-teal-500/30 flex items-center gap-1">
                    <Music className="w-3 h-3" /> 高保真单轨音频
                  </span>
                </div>
              )}

              {/* Title & Live Counter Overlay */}
              <div className="w-full bg-slate-100/90 dark:bg-slate-950/90 backdrop-blur-md px-3 py-1.5 border-t border-slate-200 dark:border-slate-800/80 flex items-center justify-between text-xs">
                <h4 className="font-semibold text-slate-800 dark:text-slate-200 truncate max-w-[180px]" title={media.name}>
                  {media.name}
                </h4>
                <span className="font-mono text-[11px] text-teal-400 font-medium shrink-0">
                  {formatTime(currentTime)} / {formatTime(duration)}
                </span>
              </div>
            </div>

            {/* Timeline Progress Slider */}
            <div className="space-y-1">
              <input
                id="ambient-seek-slider"
                type="range"
                min="0"
                max={duration || 100}
                step="0.1"
                value={currentTime}
                onChange={handleSeek}
                className="w-full accent-teal-500 dark:accent-teal-400 h-1.5 bg-slate-200 dark:bg-slate-800 rounded-lg cursor-pointer hover:bg-slate-300 dark:hover:bg-slate-700 transition-colors"
              />
              <div className="flex justify-between text-[10px] text-slate-500 dark:text-slate-500 font-mono">
                <span>{formatTime(currentTime)}</span>
                <span>{formatTime(duration)}</span>
              </div>
            </div>

            {/* Audio/Video Control Buttons */}
            <div className="flex items-center justify-between bg-slate-100 dark:bg-slate-950/70 p-2.5 rounded-xl border border-slate-200 dark:border-slate-800/80">
              {/* Loop Toggle Button */}
              <button
                type="button"
                onClick={() => setIsLooping(!isLooping)}
                className={`p-2 rounded-lg transition-colors ${
                  isLooping
                    ? 'text-teal-700 dark:text-teal-400 bg-teal-100 dark:bg-teal-950/80 border border-teal-300 dark:border-teal-500/40'
                    : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-300 bg-white dark:bg-slate-900 border border-slate-200 dark:border-transparent'
                }`}
                title={isLooping ? '循环播放：已开启' : '循环播放：关闭'}
              >
                <Repeat className="w-4 h-4" />
              </button>

              {/* Primary Play/Pause Button */}
              <button
                id="ambient-play-toggle"
                type="button"
                onClick={togglePlay}
                className={`w-11 h-11 rounded-full flex items-center justify-center transition-transform hover:scale-105 active:scale-95 shadow-md ${
                  isPlaying
                    ? 'bg-rose-500 text-white shadow-rose-950/50'
                    : 'bg-teal-600 dark:bg-teal-500 text-white dark:text-slate-950 hover:bg-teal-500 dark:hover:bg-teal-400 shadow-[0_0_15px_rgba(20,184,166,0.3)]'
                }`}
                title={isPlaying ? '暂停' : '播放'}
              >
                {isPlaying ? <Pause className="w-5 h-5 fill-current" /> : <Play className="w-5 h-5 fill-current ml-0.5" />}
              </button>

              {/* Volume Slider & Mute Button */}
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => setIsMuted(!isMuted)}
                  className="p-1.5 text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-lg transition-colors"
                  title={isMuted ? '取消静音' : '静音'}
                >
                  {isMuted || volume === 0 ? (
                    <VolumeX className="w-4 h-4 text-rose-500" />
                  ) : (
                    <Volume2 className="w-4 h-4" />
                  )}
                </button>
                <input
                  id="ambient-volume-slider"
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={isMuted ? 0 : volume}
                  onChange={(e) => {
                    setVolume(parseFloat(e.target.value));
                    if (isMuted) setIsMuted(false);
                  }}
                  className="w-14 accent-teal-500 dark:accent-teal-400 h-1 bg-slate-300 dark:bg-slate-800 rounded-lg cursor-pointer"
                />
              </div>
            </div>

            {/* Upload Error Warning if any */}
            {uploadError && (
              <div className="p-2 bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-500/30 rounded-lg text-rose-700 dark:text-rose-300 text-[11px] flex items-center gap-2">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                <span>{uploadError}</span>
              </div>
            )}

            {/* Bottom Actions: Media Upload & Reset */}
            <div className="flex items-center justify-between pt-1 border-t border-slate-200 dark:border-slate-800/80">
              <label className="cursor-pointer px-3.5 py-1.5 rounded-lg bg-teal-100 dark:bg-teal-950/90 hover:bg-teal-200 dark:hover:bg-teal-900 text-teal-800 dark:text-teal-300 border border-teal-300 dark:border-teal-500/40 text-xs font-medium transition-all flex items-center gap-1.5 shadow-sm hover:scale-105 active:scale-95">
                <Upload className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                <span>{isUploading ? '替换中...' : '更换 MP3 或 MV'}</span>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="audio/*,video/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>

              <button
                type="button"
                onClick={handleResetMedia}
                className="px-2.5 py-1.5 text-xs font-mono text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors flex items-center gap-1"
                title="恢复为系统默认潮汐介质"
              >
                <RotateCcw className="w-3 h-3" />
                <span>重置默认</span>
              </button>
            </div>

          </div>
        </div>
      )}
    </div>
  );
};
