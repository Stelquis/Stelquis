import React, { useState } from 'react';
import { Sparkles, Star, Waves, Compass, Shell, Plus, Check, Heart, Bookmark } from 'lucide-react';

interface GlowingShell {
  id: string;
  title: string;
  content: string;
  type: 'learning' | 'insight' | 'victory' | 'flow';
  sourceDate: string;
  isGlowing: boolean;
  likes: number;
}

const initialGlowingShells: GlowingShell[] = [
  {
    id: 'shell-1',
    title: '第一性原理拆解',
    content: '理解了与不确定性共舞，不在混沌中焦虑。清晰从来不是混沌的对立面，而是混沌的沉积物。',
    type: 'insight',
    sourceDate: '2026.07.20',
    isGlowing: true,
    likes: 12,
  },
  {
    id: 'shell-2',
    title: 'ACM MM 短视频预加载算法',
    content: '结合用户滑动行为预测与带宽感知重构，成功将 QoE 提升 +7.5%，带宽浪费降低 -21%。',
    type: 'victory',
    sourceDate: '2026.06.18',
    isGlowing: true,
    likes: 28,
  },
  {
    id: 'shell-3',
    title: 'ChinaVis 戏剧知识图谱',
    content: '针对 1,473 部传统京剧剧本提取角色冲突，散沙般流传的戏曲剧本，经过知识图谱交织成恢弘星图。',
    type: 'flow',
    sourceDate: '2026.05.02',
    isGlowing: true,
    likes: 19,
  },
  {
    id: 'shell-4',
    title: '退潮时的归航领悟',
    content: '规划不是对抗不确定性，而是顺应内心能量起伏的优雅编织。涨潮时向外奔涌，退潮时安心归航。',
    type: 'learning',
    sourceDate: '2026.04.11',
    isGlowing: true,
    likes: 15,
  },
];

export const GlowingShellsCard: React.FC = () => {
  const [shells, setShells] = useState<GlowingShell[]>(initialGlowingShells);
  const [filterType, setFilterType] = useState<string>('all');
  const [newShellTitle, setNewShellTitle] = useState('');
  const [newShellContent, setNewShellContent] = useState('');
  const [showAdd, setShowAdd] = useState(false);

  const getTypeBadge = (type: GlowingShell['type']) => {
    switch (type) {
      case 'insight':
        return { label: '💎 智慧珍珠', cls: 'bg-purple-100 dark:bg-purple-950 text-purple-800 dark:text-purple-300 border-purple-300 dark:border-purple-500/40 shadow-sm' };
      case 'victory':
        return { label: '🌊 涨潮硬核战果', cls: 'bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-300 border-teal-300 dark:border-teal-500/40 shadow-sm' };
      case 'learning':
        return { label: '🐚 试错经验贝壳', cls: 'bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 border-amber-300 dark:border-amber-500/40' };
      case 'flow':
        return { label: '🌌 暗流灵感', cls: 'bg-indigo-100 dark:bg-indigo-950 text-indigo-800 dark:text-indigo-300 border-indigo-300 dark:border-indigo-500/40' };
    }
  };

  const handleToggleGlowing = (id: string) => {
    setShells(shells.map(s => s.id === id ? { ...s, isGlowing: !s.isGlowing } : s));
  };

  const handleLike = (id: string) => {
    setShells(shells.map(s => s.id === id ? { ...s, likes: s.likes + 1 } : s));
  };

  const handleAddShell = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newShellTitle.trim() || !newShellContent.trim()) return;
    const created: GlowingShell = {
      id: `shell-${Date.now()}`,
      title: newShellTitle.trim(),
      content: newShellContent.trim(),
      type: 'insight',
      sourceDate: '2026.07.24',
      isGlowing: true,
      likes: 1,
    };
    setShells([created, ...shells]);
    setNewShellTitle('');
    setNewShellContent('');
    setShowAdd(false);
  };

  const filtered = filterType === 'all' ? shells : shells.filter(s => s.type === filterType);

  return (
    <div className="bg-white/80 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm dark:shadow-xl space-y-6 backdrop-blur-md relative overflow-hidden text-slate-900 dark:text-slate-100">
      
      {/* Background ambient light */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-teal-500/5 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-100 dark:bg-teal-950/80 border border-teal-300 dark:border-teal-500/30 text-teal-800 dark:text-teal-300 text-xs font-mono mb-2">
            <Sparkles className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400 animate-pulse" />
            <span>GLOWING SHELLS & INSIGHT PEARLS</span>
          </div>
          <h3 className="text-xl font-bold font-serif text-slate-900 dark:text-white flex items-center gap-2">
            <span>沙滩发光的贝壳与珍珠</span>
            <span className="text-xs font-mono text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-slate-950 px-2.5 py-0.5 rounded-full border border-slate-200 dark:border-slate-800">
              {shells.filter(s => s.isGlowing).length} 颗深光沉淀
            </span>
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 font-light mt-0.5">
            “潮水会带走无意义的沙砾，留下真正属于你的闪光思考”
          </p>
        </div>

        <button
          onClick={() => setShowAdd(!showAdd)}
          className="px-4 py-2 rounded-xl text-xs font-semibold text-teal-800 dark:text-teal-200 bg-teal-100 dark:bg-teal-950 border border-teal-300 dark:border-teal-500/40 hover:bg-teal-200 dark:hover:bg-teal-900 transition-all flex items-center gap-1.5 shadow-sm"
        >
          <Plus className="w-4 h-4 text-teal-600 dark:text-teal-400" />
          <span>捡拾并放入新贝壳</span>
        </button>
      </div>

      {/* Add Form */}
      {showAdd && (
        <form onSubmit={handleAddShell} className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 space-y-3 animate-fadeIn">
          <h4 className="text-xs font-bold text-teal-700 dark:text-teal-300 font-mono">捡拾归档新贝壳</h4>
          <input
            type="text"
            value={newShellTitle}
            onChange={(e) => setNewShellTitle(e.target.value)}
            placeholder="贝壳/珍珠主题 (例如：第二大脑降熵心得)..."
            className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-slate-200 focus:outline-none focus:border-teal-500/60 font-serif"
          />
          <textarea
            rows={2}
            value={newShellContent}
            onChange={(e) => setNewShellContent(e.target.value)}
            placeholder="退潮后记录下的沉淀或经验点滴..."
            className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3 text-xs text-slate-900 dark:text-slate-200 focus:outline-none focus:border-teal-500/60 font-sans"
          />
          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setShowAdd(false)}
              className="px-3 py-1.5 rounded-xl text-xs text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white bg-slate-200 dark:bg-slate-800"
            >
              取消
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 rounded-xl text-xs font-semibold text-white bg-teal-600 hover:bg-teal-500 shadow"
            >
              收入收藏盒
            </button>
          </div>
        </form>
      )}

      {/* Grid of Shells */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.map((shell) => {
          const badge = getTypeBadge(shell.type);
          return (
            <div
              key={shell.id}
              className={`p-5 rounded-2xl border transition-all duration-300 space-y-3 relative overflow-hidden group ${
                shell.isGlowing
                  ? 'bg-white/90 dark:bg-slate-950/90 border-teal-300 dark:border-teal-500/30 shadow-md dark:shadow-lg hover:border-teal-400/60'
                  : 'bg-slate-50/80 dark:bg-slate-950/50 border-slate-200 dark:border-slate-800 opacity-70'
              }`}
            >
              {shell.isGlowing && (
                <div className="absolute top-3 right-3 text-amber-500 dark:text-amber-400 animate-pulse">
                  <Star className="w-4 h-4 fill-current" />
                </div>
              )}

              <div className="flex items-center justify-between">
                <span className={`text-[10px] font-mono px-2.5 py-0.5 rounded-full border ${badge.cls}`}>
                  {badge.label}
                </span>
                <span className="text-[10px] font-mono text-slate-500">{shell.sourceDate}</span>
              </div>

              <h4 className="text-sm font-bold font-serif text-slate-900 dark:text-slate-100 group-hover:text-teal-600 dark:group-hover:text-teal-300 transition-colors">
                {shell.title}
              </h4>

              <p className="text-xs text-slate-700 dark:text-slate-300 font-light leading-relaxed font-serif">
                “{shell.content}”
              </p>

              <div className="pt-2 border-t border-slate-200 dark:border-slate-800/60 flex items-center justify-between text-xs font-mono text-slate-500 dark:text-slate-400">
                <button
                  onClick={() => handleToggleGlowing(shell.id)}
                  className={`flex items-center gap-1 text-[11px] transition-colors ${
                    shell.isGlowing ? 'text-amber-600 dark:text-amber-400 font-semibold' : 'hover:text-slate-900 dark:hover:text-slate-200'
                  }`}
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>{shell.isGlowing ? '发光中' : '点亮发光'}</span>
                </button>

                <button
                  onClick={() => handleLike(shell.id)}
                  className="flex items-center gap-1 text-[11px] hover:text-rose-500 transition-colors"
                >
                  <Heart className="w-3.5 h-3.5 text-slate-400 group-hover:text-rose-500 fill-current" />
                  <span>{shell.likes} 次共鸣</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

    </div>
  );
};
