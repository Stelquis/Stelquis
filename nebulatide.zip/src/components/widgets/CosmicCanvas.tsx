import React, { useEffect, useRef } from 'react';

interface CosmicCanvasProps {
  theme?: 'dark' | 'light';
}

export const CosmicCanvas: React.FC<CosmicCanvasProps> = ({ theme = 'dark' }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);

    const isLight = theme === 'light';

    // 1. Create floating particles / stars with pulsing luminescence
    const numStars = Math.min(Math.floor((width * height) / 8000), 120);
    const stars = Array.from({ length: numStars }, () => ({
      x: Math.random() * width,
      y: Math.random() * height,
      radius: Math.random() * 1.8 + 0.5,
      alpha: Math.random() * 0.7 + 0.3,
      speed: Math.random() * 0.006 + 0.002,
      phase: Math.random() * Math.PI * 2,
      colorType: Math.random() > 0.3 ? 'teal' : Math.random() > 0.5 ? 'indigo' : 'amber',
    }));

    // 2. Create rotating galaxy nebula gas clouds
    const nebulas = [
      {
        angleOffset: 0,
        distRatio: 0.25,
        radius: Math.min(width, height) * 0.45,
        colorLight: 'rgba(13, 148, 136, 0.09)',
        colorDark: 'rgba(20, 184, 166, 0.08)',
        rotSpeed: 0.0003,
      },
      {
        angleOffset: Math.PI * 0.6,
        distRatio: 0.35,
        radius: Math.min(width, height) * 0.5,
        colorLight: 'rgba(99, 102, 241, 0.08)',
        colorDark: 'rgba(99, 102, 241, 0.07)',
        rotSpeed: -0.00025,
      },
      {
        angleOffset: Math.PI * 1.2,
        distRatio: 0.2,
        radius: Math.min(width, height) * 0.38,
        colorLight: 'rgba(217, 119, 6, 0.06)',
        colorDark: 'rgba(245, 158, 11, 0.05)',
        rotSpeed: 0.0004,
      },
      {
        angleOffset: Math.PI * 1.7,
        distRatio: 0.4,
        radius: Math.min(width, height) * 0.42,
        colorLight: 'rgba(168, 85, 247, 0.07)',
        colorDark: 'rgba(168, 85, 247, 0.06)',
        rotSpeed: -0.00035,
      },
    ];

    // 3. Occasional Shooting Star Sparks
    let shootingSpark = {
      active: false,
      x: 0,
      y: 0,
      vx: 0,
      vy: 0,
      length: 0,
      life: 0,
      maxLife: 0,
    };

    const spawnShootingSpark = () => {
      if (Math.random() < 0.008) {
        shootingSpark = {
          active: true,
          x: Math.random() * width * 0.8,
          y: Math.random() * height * 0.4,
          vx: Math.random() * 4 + 3,
          vy: Math.random() * 2 + 1,
          length: Math.random() * 60 + 40,
          life: 0,
          maxLife: 40 + Math.random() * 20,
        };
      }
    };

    let time = 0;

    const render = () => {
      time += 0.01;
      ctx.clearRect(0, 0, width, height);

      // Background base gradient
      const bgGrad = ctx.createLinearGradient(0, 0, width, height);
      if (isLight) {
        bgGrad.addColorStop(0, '#f8fafc');
        bgGrad.addColorStop(0.5, '#f1f5f9');
        bgGrad.addColorStop(1, '#e2e8f0');
      } else {
        bgGrad.addColorStop(0, '#060913');
        bgGrad.addColorStop(0.5, '#0a0e1c');
        bgGrad.addColorStop(1, '#070b18');
      }
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, width, height);

      // Center of galactic orbit
      const cx = width * 0.5 + Math.sin(time * 0.1) * 30;
      const cy = height * 0.45 + Math.cos(time * 0.08) * 20;

      // Draw Rotating Galaxy Nebula Shimmer
      nebulas.forEach((n) => {
        const currentAngle = n.angleOffset + time * n.rotSpeed * 100;
        const currentDist = Math.min(width, height) * n.distRatio;
        const nx = cx + Math.cos(currentAngle) * currentDist;
        const ny = cy + Math.sin(currentAngle) * currentDist;
        const currentRadius = n.radius + Math.sin(time * 0.5 + n.angleOffset) * 25;

        const grad = ctx.createRadialGradient(nx, ny, 0, nx, ny, currentRadius);
        const col = isLight ? n.colorLight : n.colorDark;

        grad.addColorStop(0, col);
        grad.addColorStop(0.6, col.replace(/[\d\.]+\)$/, '0.01)'));
        grad.addColorStop(1, 'transparent');

        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(nx, ny, currentRadius, 0, Math.PI * 2);
        ctx.fill();
      });

      // Draw Tidal Wave Stream Lines
      ctx.lineWidth = isLight ? 1.4 : 1.2;
      for (let waveIndex = 0; waveIndex < 3; waveIndex++) {
        ctx.beginPath();
        const waveYOffset = height * (0.62 + waveIndex * 0.12);
        const waveColor = isLight
          ? waveIndex === 0
            ? 'rgba(13, 148, 136, 0.15)'
            : waveIndex === 1
            ? 'rgba(79, 70, 229, 0.12)'
            : 'rgba(217, 119, 6, 0.10)'
          : waveIndex === 0
          ? 'rgba(20, 184, 166, 0.07)'
          : waveIndex === 1
          ? 'rgba(99, 102, 241, 0.06)'
          : 'rgba(245, 158, 11, 0.05)';

        ctx.strokeStyle = waveColor;

        for (let x = 0; x <= width; x += 15) {
          const y =
            waveYOffset +
            Math.sin(x * 0.003 + time * 0.4 + waveIndex) * 28 +
            Math.cos(x * 0.001 - time * 0.25) * 16;

          if (x === 0) {
            ctx.moveTo(x, y);
          } else {
            ctx.lineTo(x, y);
          }
        }
        ctx.stroke();
      }

      // Draw Cosmic Stars & Pulsing Shimmer Dust
      stars.forEach((star) => {
        star.phase += star.speed;
        const opacity = Math.sin(star.phase) * 0.45 + 0.55;

        let starColor = isLight
          ? `rgba(13, 148, 136, ${star.alpha * opacity * 0.5})`
          : `rgba(255, 255, 255, ${star.alpha * opacity})`;

        if (star.colorType === 'indigo') {
          starColor = isLight
            ? `rgba(79, 70, 229, ${star.alpha * opacity * 0.45})`
            : `rgba(165, 180, 252, ${star.alpha * opacity * 0.8})`;
        } else if (star.colorType === 'amber') {
          starColor = isLight
            ? `rgba(217, 119, 6, ${star.alpha * opacity * 0.4})`
            : `rgba(253, 230, 138, ${star.alpha * opacity * 0.7})`;
        }

        ctx.fillStyle = starColor;
        ctx.beginPath();
        ctx.arc(star.x, star.y, star.radius, 0, Math.PI * 2);
        ctx.fill();
      });

      // Handle Shooting Star Spark Animation
      spawnShootingSpark();
      if (shootingSpark.active) {
        shootingSpark.life++;
        shootingSpark.x += shootingSpark.vx;
        shootingSpark.y += shootingSpark.vy;

        const sparkAlpha = Math.sin((shootingSpark.life / shootingSpark.maxLife) * Math.PI);
        const headX = shootingSpark.x;
        const headY = shootingSpark.y;
        const tailX = headX - shootingSpark.vx * 12;
        const tailY = headY - shootingSpark.vy * 12;

        const sparkGrad = ctx.createLinearGradient(tailX, tailY, headX, headY);
        sparkGrad.addColorStop(
          0,
          isLight ? 'rgba(13, 148, 136, 0)' : 'rgba(20, 184, 166, 0)'
        );
        sparkGrad.addColorStop(
          1,
          isLight
            ? `rgba(13, 148, 136, ${0.6 * sparkAlpha})`
            : `rgba(56, 189, 248, ${0.8 * sparkAlpha})`
        );

        ctx.beginPath();
        ctx.moveTo(tailX, tailY);
        ctx.lineTo(headX, headY);
        ctx.strokeStyle = sparkGrad;
        ctx.lineWidth = 1.8;
        ctx.stroke();

        if (shootingSpark.life >= shootingSpark.maxLife) {
          shootingSpark.active = false;
        }
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
    };
  }, [theme]);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none z-0 transition-opacity duration-500"
      aria-hidden="true"
    />
  );
};
