import React from 'react';
import { Waves, Github, Code2, Rss, Download, Sparkles, Compass, BookOpen, ExternalLink, ShieldCheck } from 'lucide-react';
import { USER_PROFILE } from '../../data/initialData';

interface FooterProps {
  onNavigate?: (tab: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  return (
    <footer className="mt-20 border-t border-slate-200 dark:border-slate-800/80 bg-white/90 dark:bg-slate-950/90 backdrop-blur-2xl relative z-10 text-slate-500 dark:text-slate-400 text-xs transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
        
        {/* Top Hub Grid */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
          
          {/* Col 1: Brand & Philosophy */}
          <div className="md:col-span-5 space-y-3">
            <div className="flex items-center gap-2">
              <div className="p-1.5 rounded-lg bg-teal-500/10 border border-teal-500/20 text-teal-500">
                <Waves className="w-4 h-4" />
              </div>
              <span className="font-serif text-base font-bold text-slate-900 dark:text-white tracking-tight">
                NebulaTide · 星云潮汐
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-teal-500/10 text-teal-600 dark:text-teal-400 font-bold border border-teal-500/20">
                v2.5 Live Engine
              </span>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-400 font-serif leading-relaxed max-w-md">
              第一性原理 × 每日复利。潮起时航行，潮落时织网。全栈 AI Agent 演化架构试炼场与赛博存在主义数字花园。
            </p>

            <div className="flex items-center gap-2 text-[11px] font-mono text-slate-400 pt-1">
              <ShieldCheck className="w-3.5 h-3.5 text-teal-500" />
              <span>Fullstack Linux VFS & SQLite In-Memory Runtime</span>
            </div>
          </div>

          {/* Col 2: Navigation Links */}
          <div className="md:col-span-3 space-y-2.5">
            <h4 className="text-[11px] font-mono font-bold uppercase text-slate-900 dark:text-slate-200 tracking-wider">
              全站快速探针
            </h4>
            <div className="grid grid-cols-2 gap-2 text-xs font-mono">
              <button
                onClick={() => onNavigate?.('articles')}
                className="text-left text-slate-600 dark:text-slate-400 hover:text-teal-600 dark:hover:text-teal-300 transition-colors"
              >
                潮汐长文
              </button>
              <button
                onClick={() => onNavigate?.('fragments')}
                className="text-left text-slate-600 dark:text-slate-400 hover:text-teal-600 dark:hover:text-teal-300 transition-colors"
              >
                混沌沙盒
              </button>
              <button
                onClick={() => onNavigate?.('rituals')}
                className="text-left text-slate-600 dark:text-slate-400 hover:text-teal-600 dark:hover:text-teal-300 transition-colors"
              >
                退潮织网
              </button>
              <button
                onClick={() => onNavigate?.('projects')}
                className="text-left text-slate-600 dark:text-slate-400 hover:text-teal-600 dark:hover:text-teal-300 transition-colors"
              >
                星星之火
              </button>
              <button
                onClick={() => onNavigate?.('about')}
                className="text-left text-slate-600 dark:text-slate-400 hover:text-teal-600 dark:hover:text-teal-300 transition-colors"
              >
                航行者档案
              </button>
            </div>
          </div>

          {/* Col 3: Data & Export Hub */}
          <div className="md:col-span-4 space-y-2.5">
            <h4 className="text-[11px] font-mono font-bold uppercase text-slate-900 dark:text-slate-200 tracking-wider">
              开放数据与开放 API 枢纽
            </h4>
            <div className="flex flex-wrap items-center gap-2">
              <a
                href="/api/feed.xml"
                target="_blank"
                rel="noopener noreferrer"
                className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800/90 text-amber-500 hover:border-amber-500/40 transition-all shadow-sm flex items-center gap-1.5 text-xs font-mono font-medium"
                title="RSS 2.0 文章订阅源 (XML Feed)"
              >
                <Rss className="w-3.5 h-3.5" />
                <span>RSS 2.0 Feed</span>
              </a>

              <a
                href="/api/export"
                target="_blank"
                rel="noopener noreferrer"
                className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800/90 text-teal-600 dark:text-teal-400 hover:border-teal-500/40 transition-all shadow-sm flex items-center gap-1.5 text-xs font-mono font-medium"
                title="全站 VFS Markdown & SQLite 数据一键便携导出"
              >
                <Download className="w-3.5 h-3.5" />
                <span>VFS 数据导出</span>
              </a>

              <a
                href={USER_PROFILE.socials.cnb.url}
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-xl bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800/90 text-slate-600 dark:text-slate-300 hover:text-teal-500 transition-all shadow-sm"
                title="CNB 镜像仓库"
              >
                <Code2 className="w-4 h-4" />
              </a>

              <a
                href={USER_PROFILE.socials.github.url}
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-xl bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800/90 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white transition-all shadow-sm"
                title="GitHub"
              >
                <Github className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>

        {/* Bottom Bar: Copyright */}
        <div className="pt-6 border-t border-slate-200/80 dark:border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-3 text-[11px] font-mono text-slate-500">
          <div>
            © 2026 Niu (Stelquis) · Crafting with DeepSeek & Gemini Agentic Sandbox.
          </div>
          <div className="flex items-center gap-4">
            <span className="hover:text-slate-700 dark:hover:text-slate-300 transition-colors">MIT License</span>
            <span>•</span>
            <span className="hover:text-slate-700 dark:hover:text-slate-300 transition-colors">Cyber Existentialism</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
