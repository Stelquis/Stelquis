import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  Waves,
  BookOpen,
  Sparkles,
  Compass,
  User,
  Plus,
  X,
  FolderGit2,
  Sun,
  Moon,
  Bot,
  Palette,
  History,
  Cpu,
  Network,
  Rss,
  SlidersHorizontal,
  ChevronDown,
  Server,
  Search,
  LayoutGrid,
  AlignRight,
} from 'lucide-react';
import { AmbientSoundPlayer } from '../widgets/AmbientSoundPlayer';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenNewPostModal: () => void;
  onOpenNewThoughtModal: () => void;
  onOpenSearchModal?: () => void;
  onOpenAIAssistant?: () => void;
  onOpenThemeModal?: () => void;
  onOpenTimeTravelModal?: () => void;
  onOpenMcpSkillModal?: () => void;
  onOpenKnowledgeGraph?: () => void;
  onOpenArchModal?: () => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  theme: 'dark' | 'light';
  setTheme: (theme: 'dark' | 'light') => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  onOpenNewPostModal,
  onOpenNewThoughtModal,
  onOpenSearchModal,
  onOpenAIAssistant,
  onOpenThemeModal,
  onOpenTimeTravelModal,
  onOpenMcpSkillModal,
  onOpenKnowledgeGraph,
  onOpenArchModal,
  searchQuery,
  setSearchQuery,
  theme,
  setTheme,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [toolsMenuOpen, setToolsMenuOpen] = useState(false);

  const navItems = [
    { id: 'manifesto', label: '星云宣言', icon: Sparkles },
    { id: 'projects', label: '星星之火', icon: FolderGit2 },
    { id: 'articles', label: '潮汐长文', icon: BookOpen },
    { id: 'fragments', label: '混沌沙盒', icon: Waves },
    { id: 'rituals', label: '退潮织网', icon: Compass },
    { id: 'about', label: '航行者档案', icon: User },
  ];

  const toggleTheme = () => {
    setTheme(theme === 'dark' ? 'light' : 'dark');
  };

  return (
    <header className="sticky top-0 z-40 backdrop-blur-2xl bg-white/80 dark:bg-slate-950/90 border-b border-slate-200 dark:border-slate-800/80 transition-all duration-300 shadow-sm dark:shadow-none">
      <div className="max-w-7xl xl:max-w-[1440px] 2xl:max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo */}
          <div className="flex items-center gap-3">
            <button
              id="brand-logo-btn"
              onClick={() => setActiveTab('manifesto')}
              className="flex items-center gap-2.5 group text-left focus:outline-none"
            >
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-teal-500 via-indigo-500 to-purple-600 p-[1px] shadow-md shadow-teal-500/20 group-hover:scale-105 transition-transform duration-300">
                <div className="w-full h-full bg-white dark:bg-slate-950 rounded-[11px] flex items-center justify-center">
                  <Waves className="w-5 h-5 text-teal-600 dark:text-teal-400 group-hover:rotate-12 transition-transform duration-300" />
                </div>
              </div>
              <div>
                <span className="text-lg font-bold tracking-tight bg-gradient-to-r from-teal-600 via-indigo-600 to-purple-600 dark:from-teal-200 dark:via-indigo-200 dark:to-purple-200 bg-clip-text text-transparent">
                  NebulaTide
                </span>
                <span className="hidden sm:block text-[10px] text-teal-600 dark:text-teal-400/80 tracking-widest font-mono uppercase">
                  Niu · Chaos & Flow
                </span>
              </div>
            </button>
          </div>

          {/* Navigation Links - OriginKit Spring Motion Pill Navigation */}
          <nav className="hidden lg:flex items-center gap-1 bg-slate-100/90 dark:bg-slate-900/90 p-1.5 rounded-full border border-slate-200/80 dark:border-slate-800/90 shadow-inner relative">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  id={`nav-tab-${item.id}`}
                  onClick={() => setActiveTab(item.id)}
                  className={`relative flex items-center gap-1.5 px-3.5 xl:px-4 py-1.5 rounded-full text-xs font-medium transition-colors z-10 whitespace-nowrap ${
                    isActive
                      ? 'text-white dark:text-teal-300 font-semibold'
                      : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
                  }`}
                >
                  {isActive && (
                    <motion.div
                      layoutId="active-nav-tab-bg"
                      className="absolute inset-0 bg-teal-600 dark:bg-gradient-to-r dark:from-teal-500/25 dark:to-indigo-500/25 border border-teal-500/50 rounded-full shadow-sm z-0"
                      transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                    />
                  )}
                  <Icon className={`w-3.5 h-3.5 relative z-10 ${isActive ? 'text-white dark:text-teal-400' : ''}`} />
                  <span className="relative z-10">{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Right Actions */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            
            {/* Global Search Modal Card Trigger Button */}
            {onOpenSearchModal && (
              <button
                id="search-modal-trigger"
                onClick={onOpenSearchModal}
                className="p-2 sm:px-3 sm:py-1.5 rounded-full bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-teal-500/50 hover:text-teal-600 dark:hover:text-teal-300 transition-all flex items-center gap-1.5 shadow-sm text-xs font-sans shrink-0"
                title="打开搜索卡片，检索全域文章、火花与工程"
              >
                <Search className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                <span className="hidden sm:inline font-sans text-xs">搜索</span>
              </button>
            )}

            {/* DeepSeek AI Copilot Trigger Button (Icon Only) */}
            {onOpenAIAssistant && (
              <button
                id="ai-copilot-trigger"
                onClick={onOpenAIAssistant}
                className="p-2 rounded-full bg-teal-500/10 hover:bg-teal-500/20 text-teal-600 dark:text-teal-300 border border-teal-500/30 transition-all shadow-sm active:scale-95"
                title="开启星云智囊 · AI Copilot"
              >
                <Bot className="w-4 h-4 text-teal-600 dark:text-teal-400 animate-pulse shrink-0" />
              </button>
            )}

            {/* Theme & Typography Preferences Button */}
            <button
              id="theme-toggle-btn"
              onClick={onOpenThemeModal || toggleTheme}
              className="p-2 rounded-full bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-teal-600 dark:text-teal-400 hover:border-teal-500/40 hover:scale-105 active:scale-95 transition-all shadow-sm shrink-0 flex items-center justify-center"
              title="外观偏好、主题调色板与全局中英文字体设置"
            >
              <Palette className="w-4 h-4" />
            </button>

            {/* Agent Toolkit & Labs Dropdown (Replaces crowded icon bar) */}
            <div className="relative">
              <button
                id="agent-toolkit-menu-btn"
                onClick={() => setToolsMenuOpen(!toolsMenuOpen)}
                className={`p-2 sm:px-3 sm:py-1.5 rounded-full border transition-all flex items-center gap-1.5 shadow-sm text-xs font-mono shrink-0 ${
                  toolsMenuOpen
                    ? 'bg-teal-500/10 border-teal-500/50 text-teal-600 dark:text-teal-300 font-bold'
                    : 'bg-slate-100 dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-teal-500/40'
                }`}
                title="Agent 扩展实验室与系统高阶工具"
              >
                <SlidersHorizontal className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                <span className="hidden sm:inline">Agent 实验室</span>
                <ChevronDown className={`w-3 h-3 text-slate-400 transition-transform ${toolsMenuOpen ? 'rotate-180' : ''}`} />
              </button>

              {/* Tools Dropdown Menu Modal */}
              {toolsMenuOpen && (
                <>
                  <div
                    className="fixed inset-0 z-40"
                    onClick={() => setToolsMenuOpen(false)}
                  />
                  <div className="absolute right-0 top-11 z-50 w-72 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl p-2 space-y-1 animate-in fade-in zoom-in-95 duration-150">
                    <div className="px-3 py-2 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between text-[11px] font-mono text-slate-500">
                      <span>AGENT EXTENSIONS</span>
                      <span className="px-1.5 py-0.5 rounded bg-teal-500/10 text-teal-600 dark:text-teal-400 font-bold">5 LABS</span>
                    </div>

                    {onOpenArchModal && (
                      <button
                        onClick={() => {
                          onOpenArchModal();
                          setToolsMenuOpen(false);
                        }}
                        className="w-full text-left p-2.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800/80 transition-all flex items-center gap-3 group"
                      >
                        <div className="p-2 rounded-lg bg-indigo-500/10 border border-indigo-500/20 text-indigo-500 group-hover:scale-110 transition-transform">
                          <Server className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="text-xs font-bold text-slate-900 dark:text-white font-mono flex items-center gap-1">
                            <span>分布式架构控制台</span>
                          </div>
                          <div className="text-[10px] text-slate-500 dark:text-slate-400 font-mono">HA & HP System Monitor</div>
                        </div>
                      </button>
                    )}

                    {onOpenKnowledgeGraph && (
                      <button
                        onClick={() => {
                          onOpenKnowledgeGraph();
                          setToolsMenuOpen(false);
                        }}
                        className="w-full text-left p-2.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800/80 transition-all flex items-center gap-3 group"
                      >
                        <div className="p-2 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-500 group-hover:scale-110 transition-transform">
                          <Network className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="text-xs font-bold text-slate-900 dark:text-white font-mono flex items-center gap-1">
                            <span>星潮知识拓扑图谱</span>
                          </div>
                          <div className="text-[10px] text-slate-500 dark:text-slate-400 font-mono">3D Network Topology</div>
                        </div>
                      </button>
                    )}

                    {onOpenTimeTravelModal && (
                      <button
                        onClick={() => {
                          onOpenTimeTravelModal();
                          setToolsMenuOpen(false);
                        }}
                        className="w-full text-left p-2.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800/80 transition-all flex items-center gap-3 group"
                      >
                        <div className="p-2 rounded-lg bg-teal-500/10 border border-teal-500/20 text-teal-500 group-hover:scale-110 transition-transform">
                          <History className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="text-xs font-bold text-slate-900 dark:text-white font-mono">
                            VFS Git 时光机 & Diff
                          </div>
                          <div className="text-[10px] text-slate-500 dark:text-slate-400 font-mono">Version Time Travel Engine</div>
                        </div>
                      </button>
                    )}

                    {onOpenMcpSkillModal && (
                      <button
                        onClick={() => {
                          onOpenMcpSkillModal();
                          setToolsMenuOpen(false);
                        }}
                        className="w-full text-left p-2.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800/80 transition-all flex items-center gap-3 group"
                      >
                        <div className="p-2 rounded-lg bg-indigo-500/10 border border-indigo-500/20 text-indigo-500 group-hover:scale-110 transition-transform">
                          <Cpu className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="text-xs font-bold text-slate-900 dark:text-white font-mono">
                            MCP 协议 & Skill 插件中心
                          </div>
                          <div className="text-[10px] text-slate-500 dark:text-slate-400 font-mono">Protocol Bridge & Dynamic Prompt</div>
                        </div>
                      </button>
                    )}

                    <div className="pt-2 border-t border-slate-100 dark:border-slate-800/80 p-2 bg-slate-50 dark:bg-slate-950/50 rounded-xl">
                      <div className="text-[10px] font-mono text-slate-500 mb-1.5 px-1">环境白噪音引擎 (Soundscape)</div>
                      <AmbientSoundPlayer />
                    </div>
                  </div>
                </>
              )}
            </div>

            {/* Create Actions Menu (Tablet & Desktop Adaptive) */}
            <div className="hidden md:flex items-center gap-1 sm:gap-1.5">
              <button
                id="create-thought-btn"
                onClick={onOpenNewThoughtModal}
                className="px-2.5 lg:px-3 py-1.5 rounded-full text-xs font-medium text-slate-700 dark:text-slate-300 hover:text-teal-600 dark:hover:text-teal-300 bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-teal-500/40 transition-all flex items-center gap-1 shadow-sm shrink-0"
              >
                <Plus className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                <span className="hidden xl:inline">捡拾碎片</span>
                <span className="xl:hidden">碎片</span>
              </button>
              <button
                id="create-post-btn"
                onClick={onOpenNewPostModal}
                className="px-2.5 lg:px-3 py-1.5 rounded-full text-xs font-semibold text-white bg-gradient-to-r from-teal-600 to-indigo-600 hover:from-teal-500 hover:to-indigo-500 transition-all shadow-md flex items-center gap-1 shrink-0"
              >
                <Plus className="w-3.5 h-3.5" />
                <span className="hidden xl:inline">凝炼长文</span>
                <span className="xl:hidden">长文</span>
              </button>
            </div>

            {/* Mobile / Pad Menu Toggle Button (Sleek Modern Icon) */}
            <button
              id="mobile-menu-toggle"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-full bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-teal-600 dark:text-teal-400 hover:border-teal-500/50 hover:scale-105 active:scale-95 transition-all shadow-sm shrink-0 flex items-center justify-center"
              aria-label="Toggle Navigation"
              title="展开导航菜单"
            >
              {mobileMenuOpen ? (
                <X className="w-4 h-4 text-slate-700 dark:text-slate-200" />
              ) : (
                <AlignRight className="w-4 h-4 text-teal-600 dark:text-teal-400" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile / Pad Drawer with Apple Frosted Glass */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white/95 dark:bg-slate-950/95 border-b border-slate-200 dark:border-slate-800 px-4 pt-2 pb-6 space-y-3 shadow-2xl backdrop-blur-2xl animate-in fade-in slide-in-from-top-2 duration-200">
          <div className="space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  id={`mobile-nav-${item.id}`}
                  onClick={() => {
                    setActiveTab(item.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-colors ${
                    isActive
                      ? 'bg-teal-500/10 text-teal-600 dark:text-teal-300 border-l-4 border-teal-500 font-semibold'
                      : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-900 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  <Icon className="w-4 h-4 text-teal-600 dark:text-teal-400" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>

          <div className="pt-3 border-t border-slate-200 dark:border-slate-800/80 grid grid-cols-2 gap-2">
            <button
              id="mobile-create-thought"
              onClick={() => {
                onOpenNewThoughtModal();
                setMobileMenuOpen(false);
              }}
              className="py-2.5 px-3 rounded-xl text-xs font-medium text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-900 border border-slate-300 dark:border-slate-700/60 text-center flex items-center justify-center gap-1"
            >
              <Plus className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
              <span>捡拾碎片</span>
            </button>
            <button
              id="mobile-create-post"
              onClick={() => {
                onOpenNewPostModal();
                setMobileMenuOpen(false);
              }}
              className="py-2.5 px-3 rounded-xl text-xs font-semibold text-white bg-gradient-to-r from-teal-600 to-indigo-600 text-center flex items-center justify-center gap-1 shadow-md"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>凝炼长文</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
