import React, { useEffect, useState } from "react";
import { FileText, Tag, Copy, Check, Hash } from "lucide-react";
import { vfsService, VFSFileDetail } from "../../services/vfsService";
import { ModalOverlay } from "../common/ModalOverlay";

interface Props {
  filePath: string | null;
  onClose: () => void;
}

export const FilePreviewModal: React.FC<Props> = ({ filePath, onClose }) => {
  const [fileDetail, setFileDetail] = useState<VFSFileDetail | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);

  useEffect(() => {
    if (!filePath) {
      setFileDetail(null);
      return;
    }
    setLoading(true);
    vfsService.getFile(filePath).then(data => {
      setFileDetail(data);
      setLoading(false);
    });
  }, [filePath]);

  if (!filePath) return null;

  const handleCopy = () => {
    if (!fileDetail) return;
    navigator.clipboard.writeText(fileDetail.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <ModalOverlay
      isOpen={Boolean(filePath)}
      onClose={onClose}
      title={filePath}
      subtitle={fileDetail ? `全栈 VFS 节点 · 分类: ${fileDetail.category}` : "加载中..."}
      icon={<FileText className="w-5 h-5" />}
      maxWidthClass="max-w-3xl"
      headerActions={
        fileDetail ? (
          <button
            onClick={handleCopy}
            className="px-3 py-1.5 text-xs font-mono rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 flex items-center gap-1.5 transition-colors border border-slate-200 dark:border-slate-700"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? "已复制 Markdown" : "复制节点"}</span>
          </button>
        ) : null
      }
    >
      <div className="space-y-4 font-sans text-sm">
        {loading ? (
          <div className="py-20 text-center text-slate-500 font-mono text-xs animate-pulse">
            正在从 VFS 虚拟节点提取 Markdown 数据...
          </div>
        ) : fileDetail ? (
          <>
            {/* Metadata Panel */}
            <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 space-y-2">
              <div className="text-xs font-mono text-slate-500 dark:text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                <Hash className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                <span>Frontmatter 元数据</span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
                <div>
                  <span className="text-slate-500">标题:</span>{" "}
                  <span className="text-slate-800 dark:text-slate-200 font-medium">{fileDetail.title}</span>
                </div>
                <div>
                  <span className="text-slate-500">更新时间:</span>{" "}
                  <span className="text-slate-700 dark:text-slate-300">{fileDetail.updatedAt}</span>
                </div>
                <div>
                  <span className="text-slate-500">分类:</span>{" "}
                  <span className="text-teal-600 dark:text-teal-400 font-mono">{fileDetail.category}</span>
                </div>
              </div>
              {fileDetail.metadata?.tags && (
                <div className="flex items-center gap-1.5 pt-1">
                  <Tag className="w-3 h-3 text-slate-400 shrink-0" />
                  <div className="flex flex-wrap gap-1">
                    {fileDetail.metadata.tags.map((t: string, i: number) => (
                      <span key={i} className="px-2 py-0.5 text-[10px] rounded-md bg-teal-50 dark:bg-teal-500/10 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-500/20 font-mono">
                        #{t}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Raw Markdown Source */}
            <div className="space-y-1.5">
              <div className="text-xs font-mono text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                Raw Markdown 源码
              </div>
              <pre className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800/80 font-mono text-xs text-slate-800 dark:text-slate-300 leading-relaxed whitespace-pre-wrap overflow-x-auto selection:bg-teal-500/30 selection:text-teal-800 dark:selection:text-teal-200">
                {fileDetail.content}
              </pre>
            </div>
          </>
        ) : (
          <div className="py-20 text-center text-slate-500 font-mono text-xs">
            未能加载该 VFS 虚拟节点文件。
          </div>
        )}
      </div>
    </ModalOverlay>
  );
};

