import React, { useState, useEffect, useRef } from "react";
import Markdown from "react-markdown";
import {
  Bot,
  X,
  Send,
  AtSign,
  FileText,
  Sparkles,
  ChevronDown,
  ChevronUp,
  Brain,
  Cpu,
  Layers,
  Settings,
  CheckCircle2,
  AlertCircle,
  Loader2,
  RefreshCw,
  Zap,
  Wand2,
  Check
} from "lucide-react";
import { aiService, AIChatMessage, AgenticAction } from "../../services/aiService";
import { vfsService, VFSTreeResponse, VFSFileItem } from "../../services/vfsService";
import { FilePreviewModal } from "./FilePreviewModal";
import { AI_MODELS } from "../../config/aiModels";
import { ModalOverlay } from "../common/ModalOverlay";

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const GlobalAIAssistant: React.FC<Props> = ({ isOpen, onClose }) => {
  const [messages, setMessages] = useState<AIChatMessage[]>([
    {
      id: "welcome-1",
      role: "assistant",
      content: `🌌 **欢迎进入 星云潮汐 · 全局 AI 智囊**

已就绪 **DeepSeek-V4** 与 **VFS (虚拟文件系统)**。全站【宣言】、【火花】、【文章】、【项目】、【沙盒】、【档案】均已挂载为结构化 Markdown 节点。

**💡 快捷引用提示:**
可以在下方输入框中直接键入 **\`@\`** 召唤文件，或试一试：
- 对比 \`@项目/梨园星图.md\` 与 \`@文章/潮汐中的数字哲学.md\`
- 分析 \`@宣言/星云潮汐宣言.md\` 的核心价值观
- 查阅 \`@档案/星云航行者档案.md\` 中的全栈配置`,
      provider: "DeepSeek-V4 Flash (VFS Core Engine)",
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    }
  ]);

  const [inputPrompt, setInputPrompt] = useState<string>("");
  const [selectedModel, setSelectedModel] = useState<string>("deepseek-v4-flash");
  const [selectedContextPaths, setSelectedContextPaths] = useState<string[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [vfsTree, setVfsTree] = useState<VFSTreeResponse | null>(null);

  // Settings & Custom API Key State
  const [showSettings, setShowSettings] = useState<boolean>(false);
  const [customApiKey, setCustomApiKey] = useState<string>(() => localStorage.getItem("nebula_custom_api_key") || "");
  const [customBaseUrl, setCustomBaseUrl] = useState<string>(() => localStorage.getItem("nebula_custom_base_url") || "https://api.deepseek.com/v1/chat/completions");
  const [testingConnection, setTestingConnection] = useState<boolean>(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string; latencyMs: number } | null>(null);

  // Popover State for @ Mentioning
  const [showAtPopover, setShowAtPopover] = useState<boolean>(false);
  const [atQuery, setAtQuery] = useState<string>("");

  // Preview Modal File
  const [previewFilePath, setPreviewFilePath] = useState<string | null>(null);

  // DeepSeek reasoning collapse states per message
  const [expandedReasoning, setExpandedReasoning] = useState<Record<string, boolean>>({
    "welcome-1": false
  });
  const [actionExecuted, setActionExecuted] = useState<Record<string, boolean>>({});

  const chatContainerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  // Execute Agentic Action (Create Post, Create Project, Create Category)
  const handleExecuteAgenticAction = async (msgId: string, action: AgenticAction) => {
    try {
      if (action.type === "CREATE_POST") {
        const res = await fetch("/api/posts", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            title: action.payload.title,
            category: action.payload.category || "思考",
            summary: action.payload.summary || "由 AI 智囊生成的文章草稿",
            content: `# ${action.payload.title}\n\n${action.payload.summary}\n\n---\n*由星云智囊 Agentic Action 自动生成发布*`,
            tags: ["AI智囊", "Agentic"]
          })
        });
        if (res.ok) {
          setActionExecuted(prev => ({ ...prev, [msgId]: true }));
        }
      } else if (action.type === "CREATE_PROJECT") {
        const res = await fetch("/api/projects", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            title: action.payload.title,
            category: action.payload.category || "开源",
            description: action.payload.description,
            content: `# ${action.payload.title}\n\n${action.payload.description}\n\n## 架构设计\n- **前端**: React + Vite + Tailwind CSS\n- **后端**: Express + VFS 模块化框架\n`,
            techStack: ["React", "TypeScript", "Express"]
          })
        });
        if (res.ok) {
          setActionExecuted(prev => ({ ...prev, [msgId]: true }));
        }
      } else if (action.type === "CREATE_CATEGORY") {
        setActionExecuted(prev => ({ ...prev, [msgId]: true }));
      }
    } catch (err) {
      console.error("Failed to execute agentic action:", err);
    }
  };

  // Fetch VFS Tree when opened
  useEffect(() => {
    if (isOpen) {
      vfsService.getTree().then(setVfsTree);
    }
  }, [isOpen]);

  // Save Custom Settings to localStorage
  useEffect(() => {
    localStorage.setItem("nebula_custom_api_key", customApiKey);
  }, [customApiKey]);

  useEffect(() => {
    localStorage.setItem("nebula_custom_base_url", customBaseUrl);
  }, [customBaseUrl]);

  // Scroll to bottom on new messages
  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [messages, loading]);

  // Keyboard Esc key listener to close
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        if (showSettings) {
          setShowSettings(false);
        } else if (isOpen) {
          onClose();
        }
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, showSettings, onClose]);

  if (!isOpen) return null;

  // Handle API Test Connection
  const handleTestConnection = async () => {
    setTestingConnection(true);
    setTestResult(null);
    try {
      const res = await aiService.testConnection({
        apiKey: customApiKey,
        baseUrl: customBaseUrl,
        model: selectedModel
      });
      setTestResult(res);
    } catch (err: any) {
      setTestResult({
        success: false,
        message: `测试异常: ${err.message || "请求超时或网络中断"}`,
        latencyMs: 0
      });
    } finally {
      setTestingConnection(false);
    }
  };

  // Handle Input Change and @ trigger
  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const val = e.target.value;
    setInputPrompt(val);

    const lastAtPos = val.lastIndexOf("@");
    if (lastAtPos !== -1 && lastAtPos >= val.length - 15) {
      const query = val.slice(lastAtPos + 1);
      if (!query.includes(" ")) {
        setShowAtPopover(true);
        setAtQuery(query.toLowerCase());
        return;
      }
    }
    setShowAtPopover(false);
  };

  // Select a VFS File from At-Popover
  const handleSelectVFSFile = (fileItem: VFSFileItem) => {
    const lastAtPos = inputPrompt.lastIndexOf("@");
    let newPrompt = inputPrompt;
    if (lastAtPos !== -1) {
      newPrompt = inputPrompt.slice(0, lastAtPos) + `${fileItem.path} `;
    } else {
      newPrompt += `${fileItem.path} `;
    }
    setInputPrompt(newPrompt);
    setShowAtPopover(false);

    if (!selectedContextPaths.includes(fileItem.path)) {
      setSelectedContextPaths([...selectedContextPaths, fileItem.path]);
    }

    if (inputRef.current) {
      inputRef.current.focus();
    }
  };

  // Remove context path chip
  const handleRemoveContextPath = (pathToRemove: string) => {
    setSelectedContextPaths(selectedContextPaths.filter(p => p !== pathToRemove));
  };

  // Send Message
  const handleSendMessage = async () => {
    if (!inputPrompt.trim() || loading) return;

    const userMsgText = inputPrompt;
    const userMsg: AIChatMessage = {
      id: `user-${Date.now()}`,
      role: "user",
      content: userMsgText,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    };

    setMessages(prev => [...prev, userMsg]);
    setInputPrompt("");
    setShowAtPopover(false);
    setLoading(true);

    try {
      const res = await aiService.sendChat({
        prompt: userMsgText,
        model: selectedModel,
        provider: "deepseek",
        contextPaths: selectedContextPaths,
        history: messages.map(m => ({ role: m.role, content: m.content })),
        customApiKey,
        customBaseUrl
      });

      const assistantMsg: AIChatMessage = {
        id: `ai-${Date.now()}`,
        role: "assistant",
        content: res.content,
        reasoningContent: res.reasoningContent,
        referencedFiles: res.referencedFiles,
        agenticAction: res.agenticAction,
        provider: res.provider || (selectedModel === "deepseek-v4-pro" ? "DeepSeek-V4 Pro" : "DeepSeek-V4 Flash"),
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
      };

      setMessages(prev => [...prev, assistantMsg]);
      setExpandedReasoning(prev => ({ ...prev, [assistantMsg.id]: true }));
    } catch (err: any) {
      setMessages(prev => [
        ...prev,
        {
          id: `err-${Date.now()}`,
          role: "assistant",
          content: `⚠️ 通讯异常: ${err.message || "无法连接到 AI 智囊服务，请检查 API Key 或网络设置。"}`,
          timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  // Filter VFS files for At-Popover
  const getAllVFSFilesList = (): VFSFileItem[] => {
    if (!vfsTree) return [];
    const list: VFSFileItem[] = [];
    Object.values(vfsTree.categories).forEach(cat => {
      list.push(...cat.files);
    });
    return list.filter(f =>
      f.path.toLowerCase().includes(atQuery) ||
      f.title.toLowerCase().includes(atQuery) ||
      f.filename.toLowerCase().includes(atQuery)
    );
  };

  return (
    <div 
      onClick={onClose}
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 bg-slate-950/60 dark:bg-slate-950/80 backdrop-blur-md sm:backdrop-blur-xl animate-in fade-in duration-200 cursor-pointer"
    >
      
      {/* Centered Main Modal Container */}
      <div 
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-3xl h-[92vh] sm:h-[85vh] bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl dark:shadow-[0_25px_60px_rgba(0,0,0,0.7)] flex flex-col text-slate-800 dark:text-slate-100 overflow-hidden relative cursor-default"
      >
        
        {/* Top Header */}
        <div className="px-3.5 sm:px-5 py-3 border-b border-slate-200 dark:border-slate-800 bg-slate-100/90 dark:bg-slate-950/90 flex items-center justify-between shrink-0 gap-2">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="p-1.5 sm:p-2 rounded-xl bg-teal-500/10 dark:bg-gradient-to-br dark:from-teal-500/20 dark:to-indigo-500/20 border border-teal-500/30 text-teal-600 dark:text-teal-300 shrink-0">
              <Bot className="w-4 h-4 sm:w-5 sm:h-5 text-teal-600 dark:text-teal-400 animate-pulse" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-1.5">
                <h2 className="font-bold text-xs sm:text-sm text-slate-800 dark:text-slate-100 truncate">星云智囊 · 全局 Copilot</h2>
                <span className="hidden xs:inline-block px-2 py-0.5 text-[10px] font-mono rounded-full bg-teal-500/10 text-teal-700 dark:text-teal-300 border border-teal-500/30 shrink-0">
                  DeepSeek-V4
                </span>
              </div>
              <p className="text-[11px] sm:text-xs text-slate-500 dark:text-slate-400 font-mono flex items-center gap-1 truncate">
                <Layers className="w-3 h-3 text-teal-600 dark:text-teal-400 shrink-0" />
                <span className="truncate">VFS 全局索引: {vfsTree ? `${vfsTree.totalCount} 篇` : "挂载中..."}</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            {/* Model Selector */}
            <select
              value={selectedModel}
              onChange={(e) => setSelectedModel(e.target.value)}
              className="bg-slate-200/80 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-[11px] sm:text-xs font-mono px-2 py-1 text-teal-800 dark:text-teal-300 focus:outline-none focus:border-teal-500 transition-colors max-w-[110px] sm:max-w-none"
            >
              {AI_MODELS.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name} ({m.badge})
                </option>
              ))}
            </select>

            {/* API Config Gear Button (Icon Only) */}
            <button
              onClick={() => setShowSettings(!showSettings)}
              className={`p-1.5 sm:p-2 rounded-lg border text-xs font-mono transition-all flex items-center justify-center ${
                showSettings || customApiKey
                  ? "bg-teal-500/20 border-teal-500/40 text-teal-700 dark:text-teal-300"
                  : "bg-slate-200/80 dark:bg-slate-800 border-slate-300 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200"
              }`}
              title="API 密钥配置与连通性测试"
            >
              <Settings className={`w-4 h-4 ${showSettings ? "animate-spin text-teal-600 dark:text-teal-400" : ""}`} />
            </button>

            {/* Close Button */}
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 hover:bg-slate-200/80 dark:hover:bg-slate-800 transition-colors"
              title="关闭智囊 (Esc)"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Message Stream Area */}
        <div ref={chatContainerRef} className="flex-1 overflow-y-auto p-3.5 sm:p-5 space-y-4 sm:space-y-5 bg-slate-50/50 dark:bg-transparent">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex flex-col ${msg.role === "user" ? "items-end" : "items-start"}`}
            >
              {/* Role Header */}
              <div className="flex items-center gap-2 text-[11px] font-mono text-slate-500 dark:text-slate-400 mb-1 px-1">
                {msg.role === "assistant" ? (
                  <>
                    <Cpu className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                    <span className="text-teal-700 dark:text-teal-300 font-semibold">{msg.provider || "DeepSeek-V4"}</span>
                  </>
                ) : (
                  <span>你</span>
                )}
                <span>·</span>
                <span>{msg.timestamp}</span>
              </div>

              {/* Message Box */}
              <div
                className={`max-w-[95%] sm:max-w-[88%] rounded-2xl p-3.5 sm:p-4 text-xs sm:text-sm leading-relaxed ${
                  msg.role === "user"
                    ? "bg-gradient-to-r from-teal-600 to-indigo-600 text-white shadow-md rounded-tr-none"
                    : "bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-200 shadow-md rounded-tl-none"
                }`}
              >
                {/* DeepSeek Reasoning Accordion */}
                {msg.reasoningContent && (
                  <div className="mb-3 border border-teal-500/30 bg-slate-100/80 dark:bg-slate-900/90 rounded-xl overflow-hidden">
                    <button
                      onClick={() =>
                        setExpandedReasoning(prev => ({ ...prev, [msg.id]: !prev[msg.id] }))
                      }
                      className="w-full px-3 py-2 bg-teal-500/10 flex items-center justify-between text-[11px] font-mono text-teal-700 dark:text-teal-300 hover:bg-teal-500/20 transition-colors"
                    >
                      <div className="flex items-center gap-2">
                        <Brain className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400 animate-pulse" />
                        <span>DeepSeek 推理链 (Reasoning Process)</span>
                      </div>
                      {expandedReasoning[msg.id] ? (
                        <ChevronUp className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                      ) : (
                        <ChevronDown className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                      )}
                    </button>
                    {expandedReasoning[msg.id] && (
                      <div className="p-3 bg-slate-100 dark:bg-slate-950 font-mono text-[11px] text-slate-600 dark:text-slate-400 whitespace-pre-wrap border-t border-slate-200 dark:border-slate-800/80 leading-relaxed">
                        {msg.reasoningContent}
                      </div>
                    )}
                  </div>
                )}

                {/* Main Content with Full Markdown Rendering */}
                <div className="markdown-body font-sans text-xs sm:text-sm text-slate-800 dark:text-slate-200 selection:bg-teal-500/30 selection:text-teal-800 dark:selection:text-teal-200 space-y-2 [&_h3]:text-sm [&_h3]:font-bold [&_h3]:text-teal-700 dark:[&_h3]:text-teal-300 [&_h3]:mt-3 [&_h3]:mb-1 [&_h4]:text-xs [&_h4]:font-semibold [&_h4]:text-slate-900 dark:[&_h4]:text-slate-100 [&_h4]:mt-2 [&_p]:leading-relaxed [&_ul]:list-disc [&_ul]:pl-4 [&_ol]:list-decimal [&_ol]:pl-4 [&_code]:bg-slate-100 dark:[&_code]:bg-slate-800/80 [&_code]:px-1.5 [&_code]:py-0.5 [&_code]:rounded [&_code]:font-mono [&_code]:text-[11px] [&_code]:text-teal-700 dark:[&_code]:text-teal-300 [&_pre]:bg-slate-100 dark:[&_pre]:bg-slate-900 [&_pre]:p-3 [&_pre]:rounded-lg [&_pre]:overflow-x-auto [&_blockquote]:border-l-2 [&_blockquote]:border-teal-500 [&_blockquote]:pl-3 [&_blockquote]:italic [&_blockquote]:text-slate-500 dark:[&_blockquote]:text-slate-400">
                  <Markdown>{msg.content}</Markdown>
                </div>

                {/* Agentic Action Interactive Trigger Card */}
                {msg.agenticAction && (
                  <div className="mt-3 p-3 rounded-xl bg-gradient-to-r from-teal-500/10 to-indigo-500/10 border border-teal-500/30 flex flex-col gap-2">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                      <div className="flex items-center gap-2 min-w-0">
                        <div className="p-1.5 rounded-lg bg-teal-500/20 text-teal-600 dark:text-teal-300 shrink-0">
                          <Wand2 className="w-4 h-4" />
                        </div>
                        <div className="min-w-0">
                          <div className="font-semibold text-xs text-teal-900 dark:text-teal-200 truncate">
                            {msg.agenticAction.label}
                          </div>
                          <div className="text-[10px] font-mono text-slate-500 dark:text-slate-400 truncate">
                            目标: {msg.agenticAction.payload.title || msg.agenticAction.payload.name || "全栈实体"}
                          </div>
                        </div>
                      </div>

                      <button
                        onClick={() => handleExecuteAgenticAction(msg.id, msg.agenticAction!)}
                        disabled={actionExecuted[msg.id]}
                        className={`px-3 py-1.5 rounded-lg text-xs font-medium shrink-0 flex items-center justify-center gap-1.5 shadow transition-all ${
                          actionExecuted[msg.id]
                            ? "bg-teal-500/20 text-teal-700 dark:text-teal-300 cursor-default"
                            : "bg-teal-600 hover:bg-teal-500 text-white"
                        }`}
                      >
                        {actionExecuted[msg.id] ? (
                          <>
                            <Check className="w-3.5 h-3.5" />
                            <span>指令已自动执行</span>
                          </>
                        ) : (
                          <>
                            <Zap className="w-3.5 h-3.5" />
                            <span>一键运行 Agent 指令</span>
                          </>
                        )}
                      </button>
                    </div>

                    {/* Reflection Healing Badge */}
                    {msg.agenticAction.healingMetadata?.healed && (
                      <div className="pt-1.5 border-t border-teal-500/20 flex items-center gap-1.5 text-[10px] text-teal-700 dark:text-teal-300 font-mono">
                        <Sparkles className="w-3 h-3 text-teal-500 shrink-0 animate-pulse" />
                        <span>[Agent Reflection] 自动完成 Payload 参数与格式自愈校准 (Attempts: {msg.agenticAction.healingMetadata.attempts})</span>
                      </div>
                    )}
                  </div>
                )}

                {/* Referenced Files Chips */}
                {msg.referencedFiles && msg.referencedFiles.length > 0 && (
                  <div className="mt-3.5 pt-2.5 border-t border-slate-200 dark:border-slate-800/80 flex flex-wrap items-center gap-1.5">
                    <span className="text-[10px] font-mono text-slate-500 dark:text-slate-400 mr-1">引用的 VFS 节点:</span>
                    {msg.referencedFiles.map((rf, idx) => (
                      <button
                        key={idx}
                        onClick={() => setPreviewFilePath(rf.path)}
                        className="px-2 py-0.5 rounded-md bg-teal-500/10 hover:bg-teal-500/20 text-teal-700 dark:text-teal-300 border border-teal-500/30 text-[11px] font-mono flex items-center gap-1 transition-colors"
                      >
                        <FileText className="w-3 h-3 text-teal-600 dark:text-teal-400" />
                        <span>{rf.path}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex items-center gap-2 text-xs font-mono text-teal-600 dark:text-teal-400 animate-pulse p-2">
              <Brain className="w-4 h-4 text-teal-600 dark:text-teal-400 animate-spin" />
              <span>DeepSeek-V4 推理链计算与全栈数据匹配中...</span>
            </div>
          )}
        </div>

        {/* Input & Context Action Section */}
        <div className="p-3 sm:p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50/90 dark:bg-slate-950/90 relative shrink-0">
          
          {/* Active Context Chips */}
          {selectedContextPaths.length > 0 && (
            <div className="mb-2 flex flex-wrap items-center gap-1.5">
              <span className="text-[10px] font-mono text-slate-500 dark:text-slate-400">已包含语境:</span>
              {selectedContextPaths.map((p) => (
                <div
                  key={p}
                  className="px-2 py-0.5 rounded-md bg-slate-200 dark:bg-slate-800 text-teal-700 dark:text-teal-300 border border-teal-500/30 text-[11px] font-mono flex items-center gap-1.5"
                >
                  <FileText className="w-3 h-3 text-teal-600 dark:text-teal-400" />
                  <span>{p}</span>
                  <button
                    onClick={() => handleRemoveContextPath(p)}
                    className="p-0.5 rounded hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* At-Mention Popover */}
          {showAtPopover && (
            <div className="absolute bottom-full left-3 right-3 sm:left-4 sm:right-4 mb-2 max-h-56 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl shadow-2xl overflow-y-auto z-50 p-2 text-xs font-mono">
              <div className="px-2 py-1 text-[10px] uppercase text-slate-500 dark:text-slate-400 font-semibold border-b border-slate-200 dark:border-slate-800 mb-1 flex items-center justify-between">
                <span>选择 VFS 节点文件 (@引用)</span>
                <span>输入筛选</span>
              </div>
              {getAllVFSFilesList().length > 0 ? (
                getAllVFSFilesList().map((f) => (
                  <button
                    key={f.path}
                    onClick={() => handleSelectVFSFile(f)}
                    className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-teal-500/10 dark:hover:bg-teal-500/20 hover:text-teal-700 dark:hover:text-teal-200 text-slate-700 dark:text-slate-300 flex items-center justify-between transition-colors my-0.5"
                  >
                    <span className="truncate font-mono">{f.path}</span>
                    <span className="px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-[10px] text-slate-500 dark:text-slate-400 border border-slate-200 dark:border-slate-700/60 shrink-0">
                      {f.title}
                    </span>
                  </button>
                ))
              ) : (
                <div className="p-3 text-center text-slate-400 dark:text-slate-500 text-xs">
                  未找到匹配的 VFS 节点文件
                </div>
              )}
            </div>
          )}

          {/* Text Area Input */}
          <div className="relative flex items-end gap-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl p-2 focus-within:border-teal-500 transition-all shadow-inner">
            <textarea
              ref={inputRef}
              value={inputPrompt}
              onChange={handleInputChange}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
              placeholder="向 DeepSeek AI 提问，按 @ 可引用站内文章与开源项目文件..."
              rows={2}
              className="flex-1 bg-transparent border-0 focus:outline-none text-slate-800 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-500 text-xs sm:text-sm resize-none font-sans"
            />

            <div className="flex items-center gap-1.5 shrink-0">
              <button
                onClick={() => setShowAtPopover(!showAtPopover)}
                className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-teal-700 dark:text-teal-300 text-xs font-mono border border-slate-200 dark:border-slate-700/80 flex items-center gap-1 transition-colors"
                title="引用全栈文件"
              >
                <AtSign className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                <span className="hidden sm:inline">文件</span>
              </button>

              <button
                onClick={handleSendMessage}
                disabled={!inputPrompt.trim() || loading}
                className="p-2 rounded-lg bg-gradient-to-r from-teal-600 to-indigo-600 hover:from-teal-500 hover:to-indigo-500 disabled:opacity-50 text-white font-semibold shadow-md transition-all flex items-center justify-center"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Footer Quick Tip */}
          <div className="mt-1.5 flex items-center justify-between text-[10px] font-mono text-slate-500 dark:text-slate-400">
            <span>Enter 发送 / Shift+Enter 换行</span>
            <span className="hidden sm:inline">Esc 或点击背景关闭</span>
          </div>
        </div>
      </div>

      {/* File Preview Side Modal */}
      <FilePreviewModal
        filePath={previewFilePath}
        onClose={() => setPreviewFilePath(null)}
      />

      {/* Standalone Centered Settings Pop-up Modal Card */}
      <ModalOverlay
        isOpen={showSettings}
        onClose={() => setShowSettings(false)}
        title="AI 引擎与 API 密钥设置"
        subtitle="配置自定义 DeepSeek / OpenAI 接口与连通性测试"
        icon={<Settings className="w-5 h-5 animate-spin text-teal-600 dark:text-teal-400" />}
        maxWidthClass="max-w-lg"
        zIndexClass="z-[70]"
      >
        <div className="space-y-4 text-xs font-mono">
          {/* Model preset */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              当前 AI 引擎模型 (Model):
            </label>
            <select
              value={selectedModel}
              onChange={(e) => setSelectedModel(e.target.value)}
              className="w-full bg-slate-100 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-xs font-mono px-3 py-2 text-teal-800 dark:text-teal-300 focus:outline-none focus:border-teal-500 transition-colors"
            >
              {AI_MODELS.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name} ({m.badge})
                </option>
              ))}
            </select>
          </div>

          {/* API Key */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              DeepSeek / OpenAI Compatible API Key:
            </label>
            <input
              type="password"
              value={customApiKey}
              onChange={(e) => setCustomApiKey(e.target.value)}
              placeholder="sk-xxxxxxxxxxxxxxxx"
              className="w-full bg-slate-100 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-800 dark:text-slate-200 focus:outline-none focus:border-teal-500 text-xs font-mono placeholder:text-slate-400 dark:placeholder:text-slate-600"
            />
            <p className="mt-1 text-[10px] text-slate-500 dark:text-slate-400">留空则自动使用系统内置引擎，无需配置外部 Key</p>
          </div>

          {/* Base Endpoint URL */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Base Endpoint URL (如使用中转服务):
            </label>
            <input
              type="text"
              value={customBaseUrl}
              onChange={(e) => setCustomBaseUrl(e.target.value)}
              placeholder="https://api.deepseek.com/v1/chat/completions"
              className="w-full bg-slate-100 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-800 dark:text-slate-200 focus:outline-none focus:border-teal-500 text-xs font-mono placeholder:text-slate-400 dark:placeholder:text-slate-600"
            />
          </div>

          {/* Connection Test & Result */}
          <div className="pt-2 border-t border-slate-200 dark:border-slate-800 space-y-2.5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <button
                onClick={handleTestConnection}
                disabled={testingConnection}
                className="px-3.5 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-500 text-white font-sans text-xs font-medium flex items-center justify-center gap-1.5 shadow transition-all disabled:opacity-50"
              >
                {testingConnection ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>正在测试连通性...</span>
                  </>
                ) : (
                  <>
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>测试接口连通性</span>
                  </>
                )}
              </button>

              {testResult && (
                <div className={`flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg border ${
                  testResult.success
                    ? "bg-teal-500/10 text-teal-700 dark:text-teal-300 border-teal-500/30"
                    : "bg-red-500/10 text-red-700 dark:text-red-300 border-red-500/30"
                }`}>
                  {testResult.success ? (
                    <CheckCircle2 className="w-4 h-4 text-teal-600 dark:text-teal-400 shrink-0" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-red-600 dark:text-red-400 shrink-0" />
                  )}
                  <span className="truncate max-w-[180px] sm:max-w-xs">{testResult.message}</span>
                </div>
              )}
            </div>
          </div>

          {/* Footer Save Button */}
          <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <span className="text-[10px] text-slate-500 dark:text-slate-400 font-mono">点击卡片外部或按 Esc 即可退出</span>
            <button
              onClick={() => setShowSettings(false)}
              className="px-4 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-500 text-white font-sans text-xs font-medium shadow transition-all"
            >
              保存并关闭
            </button>
          </div>
        </div>
      </ModalOverlay>
    </div>
  );
};
