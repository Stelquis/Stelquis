import { Post, ThoughtFragment, TideReview, WeavingGoal, ProjectItem, MindModel } from '../types';

export const USER_PROFILE = {
  name: "Niu",
  handle: "Stelquis",
  university: "CSU (中南大学)",
  fields: ["Artificial Intelligence", "Data Science", "Cloud-Native"],
  motto: "Always a learner, always learning from the best.",
  bio: "专注于 AI Agent、数据科学、云原生高并发架构与复杂数据可视化。追求第一性原理，在系统的混沌与自然的潮汐间编织代码与思想。",
  avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=300&auto=format&fit=crop",
  socials: {
    github: { name: "GitHub", url: "https://github.com/Stelquis", username: "Stelquis" },
    cnb: { name: "CNB", url: "https://cnb.cool/u/Stelquis", username: "Stelquis" },
    gitee: { name: "Gitee", url: "https://gitee.com/star-n", username: "star-n" },
    linkedin: { name: "LinkedIn", url: "https://www.linkedin.com/in/chenxun-niu-3420ba401/", username: "Chenxun Niu" },
    emails: [
      { type: "Gmail", address: "stelquis@gmail.com", badgeBg: "from-red-500/20 to-orange-500/20", borderColor: "border-red-500/40" },
      { type: "QQ Mail", address: "3420761503@qq.com", badgeBg: "from-purple-500/20 to-indigo-500/20", borderColor: "border-purple-500/40" },
      { type: "163 Mail", address: "17837343195@163.com", badgeBg: "from-rose-500/20 to-red-500/20", borderColor: "border-rose-500/40" }
    ]
  }
};

export const MIND_MODELS: MindModel[] = [
  {
    title: "第一性原理",
    formula: "拆解 → 重构",
    description: "剥离表象与传统经验，回归物理与事物最基本的真相，从零构建认知。",
    icon: "Atom"
  },
  {
    title: "建立连接",
    formula: "散沙 → 网络",
    description: "知识碎片如茫茫散沙，唯有通过关系图谱与逻辑节点将其交织成网。",
    icon: "Network"
  },
  {
    title: "持续迭代",
    formula: "v0.1 → v1.0",
    description: "不追求完美开局，先在混沌中完成 MVP，通过实战潮汐不断完善升级。",
    icon: "GitBranch"
  },
  {
    title: "复利效应",
    formula: "每天 × 365 = 37×",
    description: "1.01^365 ≈ 37.8。每个微小的 Commit 都在时间的杠杆下滚动爆发。",
    icon: "TrendingUp"
  },
  {
    title: "熵减整理",
    formula: "不整理 → 遗忘",
    description: "系统天然趋于混乱。定期退潮复盘与提炼珍珠是对抗心智高熵的唯一方式。",
    icon: "Sparkles"
  },
  {
    title: "反脆弱",
    formula: "风灭烛，却旺火",
    description: "在波折与意外中汲取滋养，越是动荡与不确定，越能激发生命的韧性。",
    icon: "Flame"
  }
];

export const PROJECTS_DATA: ProjectItem[] = [
  {
    id: "proj-1",
    title: "🎭 梨园星图 (HumanVIZ)",
    subtitle: "京剧剧本多维可视分析系统",
    category: "可视化分析",
    period: "2026.03 ~ 06",
    description: "针对 1,473 部传统京剧剧本提取角色关系、叙事冲突与模式演变，ChinaVis 2026 参赛作品。融合复杂网络图与时空叙事链，重塑传统戏曲知识大纲。",
    highlights: [
      "1,473 部剧本语义解析",
      " ChinaVis 2026 参赛作品",
      "角色关系图谱与叙事节点提取"
    ],
    tags: ["D3.js", "Knowledge Graph", "ChinaVis", "NLP", "Data Visualization"],
    repoUrl: "https://cnb.cool/OrionDawn/HumanVIZ",
    iconName: "theater",
    philosophicalLink: "散沙般流传的戏曲剧本，经过知识图谱交织成恢弘的星图网络。"
  },
  {
    id: "proj-2",
    title: "📹 短视频流自适应预加载算法",
    subtitle: "ACM Multimedia 2022 挑战赛优化方案",
    category: "算法&网络",
    period: "2025.12 ~ 2026.01",
    description: "面向弱网与高动态播放场景的短视频预加载算法。结合用户滑动行为预测与带宽感知，显著降低卡顿率并优化带宽消耗。",
    highlights: [
      "综合得分 +45%",
      "QoE 体验指标提升 +7.5%",
      "带宽浪费降低 -21%"
    ],
    tags: ["ACM MM Challenge", "Bandwidth Prediction", "QoE", "Dynamic Preload"],
    repoUrl: "https://cnb.cool/OrionSeeker/Data-processing-method-Project",
    iconName: "video",
    philosophicalLink: "像潮汐预测涨落一样，精确感知网络带宽与用户行为的未来流向。"
  },
  {
    id: "proj-3",
    title: "🤖 DeepAstraDraft",
    subtitle: "生产级 CAD 图纸智能问答 Agent",
    category: "AI Agent",
    period: "2026.06 ~ 07",
    description: "基于 RAG 与多模态 Spatial Agent 架构，深度解析 DWG/DXF 工艺图纸，自动化提取 123 项工程参数并构建图结构语义索引，支持复杂自然语言工程问答。",
    highlights: [
      "解析 DWG/DXF 图纸结构",
      "123 项参数语义索引",
      "自然语言问答准确率 93.1%"
    ],
    tags: ["CAD Parse", "LLM Agent", "DWG/DXF", "RAG", "Engineering Q&A"],
    repoUrl: "https://cnb.cool/OrionDawn/AstraDraft",
    iconName: "robot",
    philosophicalLink: "从冷冰冰的几何图线中，提取出蕴含人类工业智慧的深层语义珍珠。"
  },
  {
    id: "proj-4",
    title: "🐦 Starling（椋鸟）",
    subtitle: "AI 同声传译助手与音视频卡片",
    category: "AI Agent",
    period: "2026.05 ~ 06",
    description: "输入 B 站/YouTube 英文视频链接，自动进行流式音频抽取、Whisper ASR 识别、大模型上下文翻译与双语卡片字幕生成。",
    highlights: [
      "B 站/外网视频链接一键解析",
      "流式实时 ASR + LLM 翻译",
      "双语精美字幕卡片渲染"
    ],
    tags: ["Voice AI", "ASR", "Stream Translation", "Bilibili API", "React"],
    repoUrl: "https://cnb.cool/OrionDawn/Starling",
    iconName: "bird",
    philosophicalLink: "消除不同语言之间的障壁，让思想在不同文化洋流中无缝穿梭。"
  },
  {
    id: "proj-5",
    title: "🧠 Neural-Link OS Agent",
    subtitle: "自然语言驱动的智能系统管理代理",
    category: "系统&安全",
    period: "2026.05 ~ 07",
    description: "跨平台智能运维代理，通过自然语言自动翻译为 Shell/Bash 命令，配备四级危险指令沙箱拦截、本地及 SSH 远程集群统一管控。",
    highlights: [
      "自然语言驱动命令生成",
      "四级风险评估与沙箱隔离",
      "支持本地与 SSH 远程并发管理"
    ],
    tags: ["OS Agent", "SSH Remote", "Risk Control", "Automation", "Terminal"],
    repoUrl: "https://cnb.cool/OrionSeeker/SuperFusion",
    iconName: "brain",
    philosophicalLink: "将复杂的系统状态转化为人类自然意图，赋予操作系统直觉般的大脑神经感应。"
  },
  {
    id: "proj-6",
    title: "🕷️ PySpider",
    subtitle: "高性能分布式异步网络爬虫引擎",
    category: "分布式&爬虫",
    period: "2025.09 ~ 12",
    description: "采用 Python Asyncio + Redis Cluster 构建的高吞吐分布式爬虫，拥有高效的动态锁粒度调节机制与自动化反爬规避。",
    highlights: [
      "44 线程高并发协作",
      "160,000+ 网页稳定抓取",
      "锁竞争大幅降低 -98%"
    ],
    tags: ["Python Asyncio", "Distributed Spider", "Redis Cluster", "High Concurrency"],
    repoUrl: "https://cnb.cool/OrionSeeker/WebSpider",
    iconName: "spider",
    philosophicalLink: "像千丝万缕的蜘蛛网伸入互联网大海，将数据贝壳捞回干热的陆地。"
  },
  {
    id: "proj-7",
    title: "🧬 GeneX",
    subtitle: "生物信息学复现与计算生物学实验",
    category: "生物信息",
    period: "2026.04 ~ 07",
    description: "涵盖分子性质预测 (GCN + EGNN 图神经网络)、DNA 甲基化到基因表达量的深度图映射模型，以及药物重定位计算研究。",
    highlights: [
      "分子性质预测 (GCN + EGNN)",
      "DNA 甲基化 → 基因表达预测",
      "药物重定位与计算生物学"
    ],
    tags: ["Bioinformatics", "GCN/EGNN", "DNA Methylation", "Drug Discovery"],
    repoUrl: "https://cnb.cool/OrionSeeker/GeneX",
    iconName: "gene",
    philosophicalLink: "在生命分子结构的微观宇宙中，探寻四种碱基编织出的深邃密码。"
  }
];

export const MANIFESTO_TEXT = {
  title: "NebulaTide 哲学：一个关于混沌与潮汐的故事",
  subtitle: "清晰不是混沌的对立面，而是混沌的沉积物。",
  author: "Niu (Stelquis)",
  date: "2026-07-23",
  sections: [
    {
      id: "part-1",
      title: "一、星云之境：承认混沌是起点",
      icon: "Cloud",
      content: `思绪初生时，从来不是条理分明的。

它像星云 ☁️ 弥漫、缠绕、没有边界。一个灵感与另一个焦虑碰撞，待办事项和深夜emo共存。我们习惯急着整理，急着"想清楚"，却忘了 🌱 **混沌本身就是创造的温床**。

NebulaTide 的第一层邀请 👋 **停下来，让雾气停留一会儿**。

不急着开灯。在星云的暗处 ✨ 有些东西正在缓慢发光。`
    },
    {
      id: "part-2",
      title: "二、潮汐之律：复盘是自然的呼吸",
      icon: "Waves",
      content: `星云不会自己变成星座，但也不会永远混沌。

它需要 🧘‍♂️ **潮汐** ——那种周期性的回望，那种"退后一步"的姿态。

> **涨潮时** 🌊 我们向外奔涌，执行、碰撞、试错  
> **退潮时** 🐚 我们弯腰捡拾，那些散落的贝壳开始显形

复盘不是自责的仪式，不是KPI的清算。它是 👋 **呼吸** ——吸气时扩张，呼气时沉淀。没有对错，只有节律。

每周、每月、每季 🏖️ 潮水会带走沙砾，留下真正属于你的东西。`
    },
    {
      id: "part-3",
      title: "三、织网之时：规划是顺势的编织",
      icon: "Compass",
      content: `当贝壳足够多，你会看见隐形的线。

不是强行画一条 🚫 "正确道路"，而是像潮汐编织海岸一样 🌅 让方向**自然浮现**。

**NebulaTide 的规划观：**
- 🔮 **不预测遥远的未来**
- 🌊 **只感知此刻的流向**
- 🧭 **把复盘得到的珍珠，串成下一程的罗盘**

规划不是对抗不确定性 💃 而是**与不确定性共舞**。`
    },
    {
      id: "part-4",
      title: "四、一个人的仪式与节奏",
      icon: "Moon",
      content: `这就是 NebulaTide 想陪伴你的时刻：

> 🌙 **深夜**，打开页面，星云般的思绪倾泻而出，不加修饰。  
> ☕ **周末**，潮水退去，你静静回看，标记那些闪光的碎片。  
> 🌅 **月初**，新的周期开始，你把贝壳摆成大致的形状，然后—— 👋 **再次踏入雾中，但心里多了一些确信**。

每个 commit 都微小到几乎看不见，但在时间的杠杆下，它会自己滚起来。`
    }
  ],
  quote: "潮起时航行，潮落时织网。—— 星云深处，自有暗流指引。"
};

import { RAW_FALLBACK_POSTS } from '../services/markdownService';

export const INITIAL_POSTS: Post[] = RAW_FALLBACK_POSTS;


export const INITIAL_THOUGHTS: ThoughtFragment[] = [
  {
    id: "frag-1",
    content: "第一性原理与 NebulaTide：拆解表象，重构本质。每一个 commit 都微小到几乎看不见，但是在时间的杠杆下，它会自己滚起来。",
    createdAt: "2026-07-23 18:30",
    moodTag: "微光",
    likes: 38,
    isStarred: true
  },
  {
    id: "frag-2",
    content: "DeepAstraDraft CAD Agent 测试跑通了 123 项参数索引。将 DXF 散落的图元线段连接成逻辑网络，这种感觉就像在星云暗处看到了极光。",
    createdAt: "2026-07-22 23:14",
    moodTag: "珍珠",
    likes: 45,
    isStarred: true
  },
  {
    id: "frag-3",
    content: "风灭烛，却旺火。反脆弱不是战胜不确定性，而是与不确定性共舞。",
    createdAt: "2026-07-21 14:05",
    moodTag: "潮汐",
    likes: 29,
    isStarred: false
  },
  {
    id: "frag-4",
    content: "深夜在极简终端写 PySpider 的 44 线程锁竞争优化。不急着开灯，在星云的暗处，有些东西正在缓慢发光。",
    createdAt: "2026-07-19 01:20",
    moodTag: "混沌",
    likes: 52,
    isStarred: true
  }
];

export const INITIAL_REVIEWS: TideReview[] = [
  {
    id: "review-1",
    title: "2026年7月第三周潮汐复盘与硬核突破",
    dateRange: "07.15 - 07.21",
    highTideWins: [
      "完成 DeepAstraDraft CAD Agent 参数索引优化，精度达 93.1%",
      "优化 NebulaTide 交互界面与 Web Audio 潮汐白噪音",
      "重构项目仓库星图，将 7 大硬核项目融合进第一性原理视角"
    ],
    lowTideLearnings: [
      {
        id: "shell-1",
        title: "认知的界限与降熵",
        type: "learning",
        description: "高并发与系统设计遇到难点时，强行陷入细枝末节会增加熵；降低负荷、退后一步，更容易看透全貌。",
        date: "07.18"
      },
      {
        id: "shell-2",
        title: "复利与节律",
        type: "pearl",
        description: "节奏是不快，但别停。每天 × 365 = 37×，积累终将战胜焦虑。",
        date: "07.20"
      }
    ],
    insightPearl: "第一性原理剥离伪需求，NebulaTide 潮汐掌控主节奏。混沌是创造的温床，沉淀方能见真章。",
    createdAt: "2026-07-21"
  }
];

export const INITIAL_WEAVING: WeavingGoal[] = [
  {
    id: "weave-1",
    title: "推进 ChinaVis 2026 梨园星图可视分析论文与系统完善",
    direction: "数据可视化与传统文化",
    flowLevel: "高能涨潮",
    status: "in_flow",
    shellsLinked: ["认知的界限与降熵"]
  },
  {
    id: "weave-2",
    title: "深化 Neural-Link OS Agent 本地沙箱与 SSH 多端集群管控",
    direction: "云原生与系统运维",
    flowLevel: "高能涨潮",
    status: "in_flow",
    shellsLinked: ["复利与节律"]
  },
  {
    id: "weave-3",
    title: "探索云原生与 GNN 在 GeneX 生物信息领域的融合创新",
    direction: "AI + 计算生物",
    flowLevel: "微光试探",
    status: "planning",
    shellsLinked: ["认知的界限与降熵"]
  }
];
