export const APP_CONFIG = {
  name: "星潮 NebulaTide",
  version: "1.2.0",
  description: "全栈个人灵感与思维潮汐管理系统",
  ui: {
    backdropBlur: "backdrop-blur-md sm:backdrop-blur-xl",
    modalAnimation: "animate-in fade-in zoom-in-95 duration-200",
    maxContentWidth: "max-w-7xl",
  },
  ai: {
    defaultModel: "deepseek-v4-flash",
    systemPromptPrefix: "你是星潮 NebulaTide 的 AI 智囊助理，负责帮助用户整理想法、发掘灵感与重构知识结构。",
  }
};
