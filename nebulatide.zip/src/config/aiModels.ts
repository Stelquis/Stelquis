export interface AIModelConfig {
  id: string;
  name: string;
  description: string;
  provider: "deepseek" | "google" | "custom";
  badge?: string;
  isDefault?: boolean;
  recommended?: boolean;
}

export const AI_MODELS: AIModelConfig[] = [
  {
    id: "deepseek-v4-flash",
    name: "DeepSeek-V4 Flash",
    description: "极速响应，适合日常对话、想法记录与即时整理",
    provider: "deepseek",
    badge: "极速推荐",
    isDefault: true,
    recommended: true,
  },
  {
    id: "deepseek-v4-pro",
    name: "DeepSeek-V4 Pro",
    description: "深度推理，适合复杂逻辑推导、长文写作与结构化建模",
    provider: "deepseek",
    badge: "深度推理",
  },
];

export const DEFAULT_AI_MODEL_ID = "deepseek-v4-flash";

export const getAIModelById = (id: string): AIModelConfig => {
  return (
    AI_MODELS.find((m) => m.id === id) ||
    AI_MODELS.find((m) => m.isDefault) ||
    AI_MODELS[0]
  );
};
