/**
 * 🖋️ NebulaTide (星云潮汐) - 全局字体与排版配置系统 (Typography System)
 * 完美适配 Claude 官方典雅衬线体、现代无衬线体、极客等宽体与古典楷体
 */

export interface FontOption {
  id: string;
  name: string;
  category: 'en' | 'cn' | 'combo';
  family: string;
  description: string;
  preview: string;
}

export const ENGLISH_FONTS: FontOption[] = [
  {
    id: 'newsreader',
    name: 'Claude 典雅衬线 (Newsreader & Source Serif)',
    category: 'en',
    family: '"Newsreader", "Source Serif 4", "Georgia", serif',
    description: 'Anthropic Claude 官方风格，极其典雅温润的阅读体验',
    preview: 'The quick brown fox jumps over the lazy dog.'
  },
  {
    id: 'modern-sans',
    name: '极简现代黑体 (Inter & SF Pro)',
    category: 'en',
    family: 'system-ui, -apple-system, BlinkMacSystemFont, "SF Pro Text", "Inter", sans-serif',
    description: '现代科技 SaaS UI 极简无衬线风格',
    preview: 'The quick brown fox jumps over the lazy dog.'
  },
  {
    id: 'fira-code',
    name: '极客等宽体 (Fira Code & JetBrains Mono)',
    category: 'en',
    family: '"Fira Code", "JetBrains Mono", ui-monospace, SFMono-Regular, monospace',
    description: '程序员特有的代码与数据美学',
    preview: 'const tide = new NebulaTide({ status: "alive" });'
  }
];

export const CHINESE_FONTS: FontOption[] = [
  {
    id: 'noto-serif-sc',
    name: '思源宋体 / 华文宋体 (Claude 典雅衬线)',
    category: 'cn',
    family: '"Noto Serif SC", "STSong", "Songti SC", "Source Han Serif SC", "SimSun", serif',
    description: '传统宋体排版，如沉静书墨，最适合深度长文与思考笔记',
    preview: '潮起时航行，潮落时织网。第一性原理 × 每日复利。'
  },
  {
    id: 'pingfang-sc',
    name: '苹方 / 微软雅黑 (现代黑体)',
    category: 'cn',
    family: '"PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", "Noto Sans SC", sans-serif',
    description: '清晰简练，高辨识度的现代数字屏显字体',
    preview: '潮起时航行，潮落时织网。第一性原理 × 每日复利。'
  },
  {
    id: 'kaiti-cn',
    name: '华文楷体 / 楷体 (古典人文手写)',
    category: 'cn',
    family: '"STKaiti", "KaiTi", "DFKai-SB", "Noto Serif SC", serif',
    description: '带有手书韵味的人文感楷体，极具个人思维沙盒温度',
    preview: '潮起时航行，潮落时织网。第一性原理 × 每日复利。'
  }
];

export interface FontComboPreset {
  id: string;
  name: string;
  enFontId: string;
  cnFontId: string;
  description: string;
  badge: string;
}

export const FONT_COMBO_PRESETS: FontComboPreset[] = [
  {
    id: 'claude-elegance',
    name: 'Claude 官方典雅衬线 (推荐)',
    enFontId: 'newsreader',
    cnFontId: 'noto-serif-sc',
    description: 'Newsreader 衬线体 × 思源宋体 · 最具文学沉浸感的全站主推风格',
    badge: 'DEFAULT'
  },
  {
    id: 'modern-tech',
    name: '现代极简数字科技',
    enFontId: 'modern-sans',
    cnFontId: 'pingfang-sc',
    description: 'SF Pro / Inter × 苹方黑体 · 高密度与清晰可读的现代科技视觉',
    badge: 'CLEAN'
  },
  {
    id: 'cyber-geek',
    name: '赛博极客代码风格',
    enFontId: 'fira-code',
    cnFontId: 'noto-serif-sc',
    description: 'Fira Code 等宽体 × 思源宋体 · 硬核代码与哲学深思交融',
    badge: 'GEEK'
  },
  {
    id: 'literary-kaiti',
    name: '文人手稿与人文楷体',
    enFontId: 'newsreader',
    cnFontId: 'kaiti-cn',
    description: 'Newsreader × 华文楷体 · 充满手写笔记感与私密花园温度',
    badge: 'HUMAN'
  }
];

export const DEFAULT_EN_FONT = 'newsreader';
export const DEFAULT_CN_FONT = 'noto-serif-sc';

/**
 * 实时修改全局 CSS 字体变量
 */
export function applyFontPreference(enFontId: string, cnFontId: string) {
  const enObj = ENGLISH_FONTS.find(f => f.id === enFontId) || ENGLISH_FONTS[0];
  const cnObj = CHINESE_FONTS.find(f => f.id === cnFontId) || CHINESE_FONTS[0];

  const fullFontStack = `${enObj.family}, ${cnObj.family}`;
  const root = document.documentElement;

  // 设置 CSS 变量与 Document Root / Body 样式
  root.style.setProperty('--font-serif', fullFontStack);
  root.style.setProperty('--font-sans', fullFontStack);
  root.style.fontFamily = fullFontStack;
  
  if (document.body) {
    document.body.style.fontFamily = fullFontStack;
  }

  // 写入 localStorage
  localStorage.setItem('tide-font-en', enFontId);
  localStorage.setItem('tide-font-cn', cnFontId);
}
