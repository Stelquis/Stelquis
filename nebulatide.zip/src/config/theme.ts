/**
 * 🌌 NebulaTide (星云潮汐) - 统一主题与设计 Token 配置系统
 * (Unified Design Tokens & Color Themes Registration)
 */

export type ThemeMode = "light" | "dark" | "system";

export interface ColorTokenGroup {
  pageBg: string;
  cardBg: string;
  cardHoverBg: string;
  modalBg: string;
  inputBg: string;
  borderColor: string;
  borderHoverColor: string;
  borderAccentColor: string;
  textPrimary: string;
  textSecondary: string;
  textMuted: string;
  glassBg: string;
  glassBorder: string;
  glassShadow: string;
  brandPrimary: string;
  brandAccent: string;
}

export interface ThemePreset {
  id: string;
  name: string;
  mode: "light" | "dark";
  colorName: string;
  previewBg: string;
  previewAccent: string;
  tokens: ColorTokenGroup;
}

export const THEME_PRESETS: Record<string, ThemePreset> = {
  "cosmic-dark": {
    id: "cosmic-dark",
    name: "星空深蓝 (Cosmic Dark)",
    mode: "dark",
    colorName: "青碧与夜色",
    previewBg: "#070a12",
    previewAccent: "#14b8a6",
    tokens: {
      pageBg: "#070a12",
      cardBg: "#0f172a",
      cardHoverBg: "#1e293b",
      modalBg: "#0f172a",
      inputBg: "#1e293b",
      borderColor: "rgba(255, 255, 255, 0.08)",
      borderHoverColor: "rgba(255, 255, 255, 0.18)",
      borderAccentColor: "rgba(45, 212, 191, 0.4)",
      textPrimary: "#f8fafc",
      textSecondary: "#94a3b8",
      textMuted: "#64748b",
      glassBg: "rgba(15, 23, 42, 0.75)",
      glassBorder: "rgba(255, 255, 255, 0.08)",
      glassShadow: "0 8px 32px 0 rgba(0, 0, 0, 0.37)",
      brandPrimary: "#0d9488",
      brandAccent: "#14b8a6"
    }
  },
  "morning-light": {
    id: "morning-light",
    name: "晨曦白昼 (Morning Light)",
    mode: "light",
    colorName: "暖光与青瓷",
    previewBg: "#f8fafc",
    previewAccent: "#0d9488",
    tokens: {
      pageBg: "#f8fafc",
      cardBg: "#ffffff",
      cardHoverBg: "#f1f5f9",
      modalBg: "#ffffff",
      inputBg: "#f1f5f9",
      borderColor: "#e2e8f0",
      borderHoverColor: "#cbd5e1",
      borderAccentColor: "rgba(20, 184, 166, 0.5)",
      textPrimary: "#0f172a",
      textSecondary: "#475569",
      textMuted: "#64748b",
      glassBg: "rgba(255, 255, 255, 0.82)",
      glassBorder: "rgba(226, 232, 240, 0.8)",
      glassShadow: "0 8px 30px 0 rgba(0, 0, 0, 0.05)",
      brandPrimary: "#0d9488",
      brandAccent: "#14b8a6"
    }
  },
  "abyssal-teal": {
    id: "abyssal-teal",
    name: "深海潮汐 (Abyssal Teal)",
    mode: "dark",
    colorName: "深邃蓝绿",
    previewBg: "#031716",
    previewAccent: "#2dd4bf",
    tokens: {
      pageBg: "#031716",
      cardBg: "#0a2928",
      cardHoverBg: "#123b3a",
      modalBg: "#0a2928",
      inputBg: "#123b3a",
      borderColor: "rgba(45, 212, 191, 0.15)",
      borderHoverColor: "rgba(45, 212, 191, 0.3)",
      borderAccentColor: "rgba(45, 212, 191, 0.6)",
      textPrimary: "#f0fdfa",
      textSecondary: "#99f6e4",
      textMuted: "#5eead4",
      glassBg: "rgba(10, 41, 40, 0.8)",
      glassBorder: "rgba(45, 212, 191, 0.2)",
      glassShadow: "0 8px 32px 0 rgba(0, 20, 20, 0.5)",
      brandPrimary: "#0d9488",
      brandAccent: "#2dd4bf"
    }
  },
  "cyber-emerald": {
    id: "cyber-emerald",
    name: "黑曜极光 (Cyber Emerald)",
    mode: "dark",
    colorName: "极客黑与荧光绿",
    previewBg: "#050607",
    previewAccent: "#00FF88",
    tokens: {
      pageBg: "#050607",
      cardBg: "#0c1015",
      cardHoverBg: "#141c24",
      modalBg: "#0c1015",
      inputBg: "#141c24",
      borderColor: "rgba(0, 255, 136, 0.15)",
      borderHoverColor: "rgba(0, 255, 136, 0.35)",
      borderAccentColor: "rgba(0, 255, 136, 0.8)",
      textPrimary: "#f0fdf4",
      textSecondary: "#86efac",
      textMuted: "#4ade80",
      glassBg: "rgba(12, 16, 21, 0.82)",
      glassBorder: "rgba(0, 255, 136, 0.2)",
      glassShadow: "0 8px 32px 0 rgba(0, 255, 136, 0.15)",
      brandPrimary: "#00cc6a",
      brandAccent: "#00FF88"
    }
  },
  "obsidian-purple": {
    id: "obsidian-purple",
    name: "黑曜星紫 (Obsidian Purple)",
    mode: "dark",
    colorName: "紫罗兰夜空",
    previewBg: "#0d0b18",
    previewAccent: "#a855f7",
    tokens: {
      pageBg: "#0d0b18",
      cardBg: "#18142a",
      cardHoverBg: "#241e3e",
      modalBg: "#18142a",
      inputBg: "#241e3e",
      borderColor: "rgba(168, 85, 247, 0.15)",
      borderHoverColor: "rgba(168, 85, 247, 0.3)",
      borderAccentColor: "rgba(168, 85, 247, 0.6)",
      textPrimary: "#faf5ff",
      textSecondary: "#e9d5ff",
      textMuted: "#c084fc",
      glassBg: "rgba(24, 20, 42, 0.8)",
      glassBorder: "rgba(168, 85, 247, 0.2)",
      glassShadow: "0 8px 32px 0 rgba(15, 5, 30, 0.6)",
      brandPrimary: "#9333ea",
      brandAccent: "#c084fc"
    }
  }
};

export const DEFAULT_THEME_ID = "cosmic-dark";

/**
 * 动态将主题预设中的 CSS 变量注入至 HTML 根元素
 */
export function applyThemePreset(presetId: string) {
  const preset = THEME_PRESETS[presetId] || THEME_PRESETS[DEFAULT_THEME_ID];
  const root = document.documentElement;
  const body = document.body;

  // 1. 设置 HTML class 与 data-theme
  if (preset.mode === "dark") {
    root.classList.add("dark");
    root.classList.remove("light");
  } else {
    root.classList.add("light");
    root.classList.remove("dark");
  }
  root.setAttribute("data-theme", preset.mode);
  root.setAttribute("data-preset", preset.id);

  // 2. 注入 CSS 变量
  const t = preset.tokens;
  root.style.setProperty("--color-bg-page", t.pageBg);
  root.style.setProperty("--color-bg-card", t.cardBg);
  root.style.setProperty("--color-bg-card-hover", t.cardHoverBg);
  root.style.setProperty("--color-bg-modal", t.modalBg);
  root.style.setProperty("--color-bg-input", t.inputBg);

  root.style.setProperty("--color-border", t.borderColor);
  root.style.setProperty("--color-border-hover", t.borderHoverColor);
  root.style.setProperty("--color-border-accent", t.borderAccentColor);

  root.style.setProperty("--color-text-primary", t.textPrimary);
  root.style.setProperty("--color-text-secondary", t.textSecondary);
  root.style.setProperty("--color-text-muted", t.textMuted);

  root.style.setProperty("--glass-bg", t.glassBg);
  root.style.setProperty("--glass-border", t.glassBorder);
  root.style.setProperty("--glass-shadow", t.glassShadow);

  root.style.setProperty("--brand-primary", t.brandPrimary);
  root.style.setProperty("--brand-accent", t.brandAccent);

  // 直接作用于 root 与 body 样式，确保调色板无延时切换
  if (body) {
    body.style.backgroundColor = t.pageBg;
    body.style.color = t.textPrimary;
  }
}
