import React, { useState, useEffect } from 'react';
import { Post, ThoughtFragment, TideReview, WeavingGoal, ProjectItem, MindModel } from './types';
import {
  INITIAL_POSTS,
  INITIAL_THOUGHTS,
  INITIAL_REVIEWS,
  INITIAL_WEAVING,
  PROJECTS_DATA,
  MIND_MODELS
} from './data/initialData';

import { CosmicCanvas } from './components/widgets/CosmicCanvas';
import { Navbar } from './components/layout/Navbar';
import { ManifestoHero } from './components/views/ManifestoHero';
import { ArticleCard } from './components/widgets/ArticleCard';
import { ArticleDetailModal } from './components/modals/ArticleDetailModal';
import { FragmentStream } from './components/views/FragmentStream';
import { TideRitual } from './components/views/TideRitual';
import { AboutView } from './components/views/AboutView';
import { ProjectsView } from './components/views/ProjectsView';
import { CreatePostModal } from './components/modals/CreatePostModal';
import { CategoryManagerModal } from './components/modals/CategoryManagerModal';
import { DevLogsAndStorageModal } from './components/modals/DevLogsAndStorageModal';
import { ThemeSelectorModal } from './components/modals/ThemeSelectorModal';
import { VFSTimeTravelModal } from './components/modals/VFSTimeTravelModal';
import { MCPSkillHubModal } from './components/modals/MCPSkillHubModal';
import { KnowledgeGraphModal } from './components/widgets/KnowledgeGraphModal';
import { ArchitectureControlModal } from './components/modals/ArchitectureControlModal';
import { SearchModal } from './components/modals/SearchModal';
import { GlobalAIAssistant } from './components/ai/GlobalAIAssistant';
import { Footer } from './components/layout/Footer';
import { applyThemePreset, DEFAULT_THEME_ID, THEME_PRESETS } from './config/theme';
import { applyFontPreference, DEFAULT_EN_FONT, DEFAULT_CN_FONT } from './config/typography';

import { BookOpen, Sparkles, Filter, Plus, Database, Tag, Settings, Edit3, FileCode, ArrowUp, Bot } from 'lucide-react';

export default function App() {
  const [themePreset, setThemePreset] = useState<string>(() => {
    return localStorage.getItem('tide-theme-preset') || DEFAULT_THEME_ID;
  });

  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    const currentPreset = THEME_PRESETS[localStorage.getItem('tide-theme-preset') || DEFAULT_THEME_ID];
    return currentPreset ? currentPreset.mode : 'dark';
  });

  const [currentEnFont, setCurrentEnFont] = useState<string>(() => {
    return localStorage.getItem('tide-font-en') || DEFAULT_EN_FONT;
  });

  const [currentCnFont, setCurrentCnFont] = useState<string>(() => {
    return localStorage.getItem('tide-font-cn') || DEFAULT_CN_FONT;
  });

  const [activeTab, setActiveTab] = useState('manifesto');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('全部');
  const [dbStatus, setDbStatus] = useState<'loading' | 'ready' | 'fallback'>('loading');
  const [dbStatusText, setDbStatusText] = useState('SQLite 后端持久化已就绪 (Storage: SQLite File DB)');
  const [showDevLogsModal, setShowDevLogsModal] = useState(false);
  const [showSearchModal, setShowSearchModal] = useState(false);
  const [showThemeModal, setShowThemeModal] = useState(false);
  const [showTimeTravelModal, setShowTimeTravelModal] = useState(false);
  const [showMcpSkillModal, setShowMcpSkillModal] = useState(false);
  const [showKnowledgeGraphModal, setShowKnowledgeGraphModal] = useState(false);
  const [showArchModal, setShowArchModal] = useState(false);
  const [showAIAssistant, setShowAIAssistant] = useState(false);
  const [showScrollTop, setShowScrollTop] = useState(false);

  // Apply Theme Preset Tokens
  useEffect(() => {
    localStorage.setItem('tide-theme-preset', themePreset);
    applyThemePreset(themePreset);
    const presetObj = THEME_PRESETS[themePreset];
    if (presetObj) {
      setTheme(presetObj.mode);
    }
  }, [themePreset]);

  // Apply Font Preferences
  useEffect(() => {
    applyFontPreference(currentEnFont, currentCnFont);
  }, [currentEnFont, currentCnFont]);

  const handleSelectFonts = (enFontId: string, cnFontId: string) => {
    setCurrentEnFont(enFontId);
    setCurrentCnFont(cnFontId);
    applyFontPreference(enFontId, cnFontId);
  };

  // Handle direct mode toggle (Sun/Moon button)
  const handleToggleTheme = (newMode: 'dark' | 'light') => {
    setTheme(newMode);
    // Find matching preset for new mode or toggle to default light/dark preset
    if (newMode === 'light') {
      setThemePreset('morning-light');
    } else {
      setThemePreset('cosmic-dark');
    }
  };

  // Monitor scroll for Back-to-Top button
  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 280);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Sync theme with html document element
  useEffect(() => {
    localStorage.setItem('tide-theme', theme);
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
      document.documentElement.classList.remove('light');
    } else {
      document.documentElement.classList.add('light');
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  // --- States ---
  const [posts, setPosts] = useState<Post[]>(INITIAL_POSTS);
  const [selectedPost, setSelectedPost] = useState<Post | null>(null);
  const [projects, setProjects] = useState<ProjectItem[]>(PROJECTS_DATA);
  const [fragments, setFragments] = useState<ThoughtFragment[]>(INITIAL_THOUGHTS);
  const [reviews, setReviews] = useState<TideReview[]>(INITIAL_REVIEWS);
  const [weavingGoals, setWeavingGoals] = useState<WeavingGoal[]>(INITIAL_WEAVING);
  const [mindModels, setMindModels] = useState<MindModel[]>(MIND_MODELS);

  const [showCreatePostModal, setShowCreatePostModal] = useState(false);
  const [showCategoryManagerModal, setShowCategoryManagerModal] = useState(false);

  // Custom Categories state
  const [customCategories, setCustomCategories] = useState<string[]>([
    '哲学宣言',
    '心智复盘',
    '潮汐随笔',
    '深度思考',
    '系统构建',
  ]);

  // --- Fetch Initial Data from SQLite REST API ---
  const loadBackendData = async () => {
    try {
      const [projRes, postRes, fragRes, ritRes, modelRes] = await Promise.all([
        fetch('/api/projects').catch(() => null),
        fetch('/api/posts').catch(() => null),
        fetch('/api/fragments').catch(() => null),
        fetch('/api/rituals').catch(() => null),
        fetch('/api/mind-models').catch(() => null),
      ]);

      if (projRes && projRes.ok) {
        const data = await projRes.json();
        if (Array.isArray(data) && data.length > 0) setProjects(data);
      }
      if (postRes && postRes.ok) {
        const data = await postRes.json();
        if (Array.isArray(data) && data.length > 0) setPosts(data);
      }
      if (fragRes && fragRes.ok) {
        const data = await fragRes.json();
        if (Array.isArray(data) && data.length > 0) setFragments(data);
      }
      if (ritRes && ritRes.ok) {
        const data = await ritRes.json();
        if (Array.isArray(data) && data.length > 0) setReviews(data);
      }
      if (modelRes && modelRes.ok) {
        const data = await modelRes.json();
        if (Array.isArray(data) && data.length > 0) setMindModels(data);
      }
      setDbStatus('ready');
    } catch (err) {
      console.warn('Backend SQLite load failed, fallbacking to local memory:', err);
      setDbStatus('fallback');
    }
  };

  useEffect(() => {
    loadBackendData();
  }, []);

  // --- Project Handlers ---
  const handleAddProject = async (newProj: ProjectItem) => {
    setProjects((prev) => [newProj, ...prev]);
    fetch('/api/projects', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newProj),
    }).catch((err) => console.error('Failed to sync project to SQLite:', err));
  };

  const handleUpdateProject = async (updatedProj: ProjectItem) => {
    setProjects((prev) => prev.map((p) => (p.id === updatedProj.id ? updatedProj : p)));
    fetch('/api/projects', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updatedProj),
    }).catch((err) => console.error('Failed to sync project update to SQLite:', err));
  };

  const handleDeleteProject = async (projId: string) => {
    setProjects((prev) => prev.filter((p) => p.id !== projId));
    fetch(`/api/projects/${projId}`, { method: 'DELETE' }).catch((err) =>
      console.error('Failed to delete project from SQLite:', err)
    );
  };

  // --- Post Handlers ---
  const handleLikePost = (postId: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setPosts((prev) => {
      const next = prev.map((p) => (p.id === postId ? { ...p, likes: p.likes + 1 } : p));
      const target = next.find((p) => p.id === postId);
      if (target) {
        fetch('/api/posts', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(target),
        }).catch(() => null);
      }
      return next;
    });

    if (selectedPost && selectedPost.id === postId) {
      setSelectedPost((prev) => (prev ? { ...prev, likes: prev.likes + 1 } : null));
    }
  };

  const handleAddPost = (newPostData: Omit<Post, 'id' | 'date' | 'likes'>) => {
    const newPost: Post = {
      ...newPostData,
      id: `post-${Date.now()}`,
      date: new Date().toISOString().split('T')[0],
      likes: 1,
    };
    setPosts((prev) => [newPost, ...prev]);
    fetch('/api/posts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newPost),
    }).catch(() => null);
    setActiveTab('articles');
  };

  const handleDeletePost = (postId: string) => {
    setPosts((prev) => prev.filter((p) => p.id !== postId));
    fetch(`/api/posts/${postId}`, { method: 'DELETE' }).catch(() => null);
  };

  // --- Fragment Handlers ---
  const handleAddFragment = (content: string, moodTag: ThoughtFragment['moodTag']) => {
    const newFrag: ThoughtFragment = {
      id: `frag-${Date.now()}`,
      content,
      moodTag,
      createdAt: new Date().toLocaleString('zh-CN', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
      }),
      likes: 0,
      isStarred: false,
    };
    setFragments((prev) => [newFrag, ...prev]);
    fetch('/api/fragments', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newFrag),
    }).catch(() => null);
  };

  const handleDeleteFragment = (id: string) => {
    setFragments((prev) => prev.filter((f) => f.id !== id));
    fetch(`/api/fragments/${id}`, { method: 'DELETE' }).catch(() => null);
  };

  const handleLikeFragment = (id: string) => {
    setFragments((prev) => {
      const next = prev.map((f) => (f.id === id ? { ...f, likes: f.likes + 1 } : f));
      const target = next.find((f) => f.id === id);
      if (target) {
        fetch('/api/fragments', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(target),
        }).catch(() => null);
      }
      return next;
    });
  };

  const handleStarFragment = (id: string) => {
    setFragments((prev) => {
      const next = prev.map((f) => (f.id === id ? { ...f, isStarred: !f.isStarred } : f));
      const target = next.find((f) => f.id === id);
      if (target) {
        fetch('/api/fragments', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(target),
        }).catch(() => null);
      }
      return next;
    });
  };

  // --- Ritual & Weaving Handlers ---
  const handleAddReview = (reviewData: Omit<TideReview, 'id' | 'createdAt'>) => {
    const newReview: TideReview = {
      ...reviewData,
      id: `review-${Date.now()}`,
      createdAt: new Date().toISOString().split('T')[0],
    };
    setReviews((prev) => [newReview, ...prev]);
    fetch('/api/rituals', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newReview),
    }).catch(() => null);
  };

  const handleDeleteReview = (id: string) => {
    setReviews((prev) => prev.filter((r) => r.id !== id));
    fetch(`/api/rituals/${id}`, { method: 'DELETE' }).catch(() => null);
  };

  const handleAddWeavingGoal = (goalData: Omit<WeavingGoal, 'id'>) => {
    const newGoal: WeavingGoal = {
      ...goalData,
      id: `weave-${Date.now()}`,
    };
    setWeavingGoals((prev) => [...prev, newGoal]);
  };

  const handleDeleteGoal = (id: string) => {
    setWeavingGoals((prev) => prev.filter((g) => g.id !== id));
  };

  const handleToggleGoalStatus = (id: string) => {
    setWeavingGoals((prev) =>
      prev.map((g) =>
        g.id === id
          ? {
              ...g,
              status: g.status === 'completed' ? 'in_flow' : 'completed',
            }
          : g
      )
    );
  };

  // --- Mind Models Handlers ---
  const handleAddMindModel = (model: MindModel) => {
    setMindModels((prev) => [...prev, model]);
    fetch('/api/mind-models', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(model),
    }).catch(() => null);
  };

  const handleDeleteMindModel = (idOrTitle: string) => {
    setMindModels((prev) => prev.filter((m: any) => (m.id || m.title) !== idOrTitle));
    fetch(`/api/mind-models/${idOrTitle}`, { method: 'DELETE' }).catch(() => null);
  };

  // --- Category Handlers ---
  const handleAddCategory = (newCatName: string) => {
    if (!customCategories.includes(newCatName)) {
      setCustomCategories((prev) => [...prev, newCatName]);
    }
  };

  const handleRenameCategory = (oldName: string, newName: string) => {
    setCustomCategories((prev) => prev.map((c) => (c === oldName ? newName : c)));
    if (selectedCategory === oldName) {
      setSelectedCategory(newName);
    }
    setPosts((prev) => {
      const next = prev.map((p) => (p.category === oldName ? { ...p, category: newName } : p));
      next.forEach((p) => {
        if (p.category === newName) {
          fetch('/api/posts', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(p),
          }).catch(() => null);
        }
      });
      return next;
    });
  };

  const handleDeleteCategory = (catName: string) => {
    setCustomCategories((prev) => prev.filter((c) => c !== catName));
    if (selectedCategory === catName) {
      setSelectedCategory('全部');
    }
    setPosts((prev) => {
      const next = prev.map((p) => (p.category === catName ? { ...p, category: '潮汐随笔' } : p));
      next.forEach((p) => {
        if (p.category === '潮汐随笔') {
          fetch('/api/posts', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(p),
          }).catch(() => null);
        }
      });
      return next;
    });
  };

  // Filter posts by search & category
  const postsCategories = posts.map((p) => p.category);
  const categoriesList = Array.from(new Set(['全部', ...customCategories, ...postsCategories]));

  const filteredPosts = (Array.isArray(posts) ? posts : []).filter((post) => {
    if (!post) return false;
    const matchesCategory = selectedCategory === '全部' || post.category === selectedCategory;
    const matchesSearch =
      !searchQuery ||
      searchQuery.trim() === '' ||
      (post.title && post.title.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (post.content && post.content.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (post.tags && Array.isArray(post.tags) && post.tags.some((t) => typeof t === 'string' && t.toLowerCase().includes(searchQuery.toLowerCase())));

    return matchesCategory && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-[#f8fafc] dark:bg-[#070a12] text-slate-900 dark:text-slate-100 relative font-sans selection:bg-teal-500/30 selection:text-teal-700 dark:selection:text-teal-200 transition-colors duration-300">
      {/* Background canvas */}
      <CosmicCanvas theme={theme} />

      {/* Main Layout Container */}
      <div className="relative z-10 flex flex-col min-h-screen">
        {/* Navbar */}
        <Navbar
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          onOpenNewPostModal={() => setShowCreatePostModal(true)}
          onOpenNewThoughtModal={() => setActiveTab('fragments')}
          onOpenSearchModal={() => setShowSearchModal(true)}
          onOpenAIAssistant={() => setShowAIAssistant(true)}
          onOpenThemeModal={() => setShowThemeModal(true)}
          onOpenTimeTravelModal={() => setShowTimeTravelModal(true)}
          onOpenMcpSkillModal={() => setShowMcpSkillModal(true)}
          onOpenKnowledgeGraph={() => setShowKnowledgeGraphModal(true)}
          onOpenArchModal={() => setShowArchModal(true)}
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          theme={theme}
          setTheme={handleToggleTheme}
        />

        {/* Database Sync Status Indicator (Clickable for Dev Logs & Storage Config) */}
        <div
          onClick={() => setShowDevLogsModal(true)}
          className="bg-slate-200/80 dark:bg-slate-950/80 border-b border-slate-300 dark:border-slate-900 py-1.5 px-4 text-center text-[11px] font-mono text-slate-600 dark:text-slate-400 flex items-center justify-center gap-2 cursor-pointer hover:bg-slate-300/80 dark:hover:bg-slate-900/90 hover:text-teal-600 dark:hover:text-teal-300 transition-all group"
          title="点击查看 SQLite 存储配置与系统开发日志 (Dev Changelogs)"
        >
          <Database className={`w-3.5 h-3.5 ${dbStatus === 'ready' ? 'text-teal-600 dark:text-teal-400' : 'text-amber-500 animate-pulse'}`} />
          <span>
            {dbStatus === 'ready'
              ? dbStatusText
              : '正在同步与初始化后端 SQLite 存储库...'}
          </span>
          <span className="text-[10px] text-teal-700 dark:text-teal-400/80 bg-slate-100 dark:bg-slate-900 px-2 py-0.5 rounded-full border border-slate-300 dark:border-slate-800 group-hover:border-teal-500/40 transition-colors flex items-center gap-1">
            <FileCode className="w-3 h-3 text-teal-600 dark:text-teal-400" />
            <span>开发日志/编辑</span>
          </span>
        </div>

        {/* Content View Switcher */}
        <main className="flex-1">
          <div key={activeTab} className="animate-in fade-in slide-in-from-bottom-2 duration-300">
            {activeTab === 'manifesto' && (
              <ManifestoHero
                onNavigateToArticles={() => setActiveTab('articles')}
                onNavigateToRituals={() => setActiveTab('rituals')}
                onNavigateToThoughts={() => setActiveTab('fragments')}
              />
            )}

            {activeTab === 'projects' && (
              <ProjectsView
                projects={projects}
                onAddProject={handleAddProject}
                onUpdateProject={handleUpdateProject}
                onDeleteProject={handleDeleteProject}
              />
            )}

            {activeTab === 'articles' && (
              <div className="max-w-7xl xl:max-w-[1440px] 2xl:max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
                {/* Category Header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-200 dark:border-slate-800/80">
                  <div>
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-100 dark:bg-teal-950/60 border border-teal-300 dark:border-teal-500/30 text-teal-800 dark:text-teal-300 text-xs font-mono mb-2">
                      <BookOpen className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                      <span>EXPLORE ARTICLES · 潮汐文章库</span>
                    </div>
                    <h2 className="text-2xl sm:text-3xl font-bold font-serif text-slate-900 dark:text-white">
                      思想与技术专栏
                    </h2>
                  </div>

                  {/* Write Button */}
                  <button
                    id="articles-page-create-post"
                    onClick={() => setShowCreatePostModal(true)}
                    className="px-4 py-2 rounded-xl text-xs font-semibold text-white bg-gradient-to-r from-teal-600 to-indigo-600 hover:from-teal-500 hover:to-indigo-500 transition-all shadow-md self-start sm:self-auto flex items-center gap-1.5"
                  >
                    <Plus className="w-4 h-4" />
                    <span>撰写新文章</span>
                  </button>
                </div>

                {/* Filter Tabs with Interactive Filter Management Button */}
                <div className="flex items-center gap-1.5 overflow-x-auto custom-scrollbar py-1">
                  <button
                    onClick={() => setShowCategoryManagerModal(true)}
                    className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-teal-500/60 hover:bg-slate-100 dark:hover:bg-slate-800 text-teal-600 dark:text-teal-400 shrink-0 transition-all flex items-center justify-center group shadow-sm mr-1"
                    title="管理与编辑分类模版 (新增/重命名/删除分类)"
                  >
                    <Filter className="w-4 h-4 text-teal-600 dark:text-teal-400 group-hover:rotate-12 transition-transform" />
                  </button>
                  {categoriesList.map((cat) => {
                    const count = cat === '全部' ? posts.length : posts.filter((p) => p.category === cat).length;
                    return (
                      <button
                        key={cat}
                        id={`category-filter-${cat}`}
                        onClick={() => setSelectedCategory(cat)}
                        className={`px-3.5 py-1.5 rounded-full text-xs font-medium shrink-0 transition-all flex items-center gap-1.5 ${
                          selectedCategory === cat
                            ? 'bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-300 border border-teal-400 dark:border-teal-500/50 font-semibold shadow-sm'
                            : 'bg-white/80 dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 border border-slate-200 dark:border-slate-800'
                        }`}
                      >
                        <span>{cat}</span>
                        <span
                          className={`text-[10px] font-mono px-1.5 py-0.2 rounded-full ${
                            selectedCategory === cat ? 'bg-teal-200 dark:bg-teal-900/80 text-teal-900 dark:text-teal-200' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400'
                          }`}
                        >
                          {count}
                        </span>
                      </button>
                    );
                  })}
                </div>

                {/* Articles Grid */}
                {filteredPosts.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4 gap-6">
                    {filteredPosts.map((post) => (
                      <ArticleCard
                        key={post.id}
                        post={post}
                        onSelect={(p) => setSelectedPost(p)}
                        onLike={handleLikePost}
                      />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-16 bg-white/60 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3">
                    <Sparkles className="w-8 h-8 text-slate-400 dark:text-slate-600 mx-auto" />
                    <p className="text-sm text-slate-500 dark:text-slate-400 font-light">未搜索到匹配的潮汐文章</p>
                    <button
                      onClick={() => {
                        setSearchQuery('');
                        setSelectedCategory('全部');
                      }}
                      className="text-xs text-teal-600 dark:text-teal-400 hover:underline"
                    >
                      重置筛选条件
                    </button>
                  </div>
                )}
              </div>
            )}

            {activeTab === 'fragments' && (
              <FragmentStream
                fragments={fragments}
                onAddFragment={handleAddFragment}
                onDeleteFragment={handleDeleteFragment}
                onLikeFragment={handleLikeFragment}
                onStarFragment={handleStarFragment}
              />
            )}

            {activeTab === 'rituals' && (
              <TideRitual
                reviews={reviews}
                weavingGoals={weavingGoals}
                onAddReview={handleAddReview}
                onDeleteReview={handleDeleteReview}
                onAddWeavingGoal={handleAddWeavingGoal}
                onToggleGoalStatus={handleToggleGoalStatus}
                onDeleteGoal={handleDeleteGoal}
              />
            )}

            {activeTab === 'about' && (
              <AboutView
                stats={{
                  postsCount: posts.length,
                  fragmentsCount: fragments.length,
                  reviewsCount: reviews.length,
                }}
                onNavigateToProjects={() => setActiveTab('projects')}
                mindModels={mindModels}
                onAddMindModel={handleAddMindModel}
                onDeleteMindModel={handleDeleteMindModel}
              />
            )}
          </div>
        </main>

        {/* Floating Control Dock (AI Copilot + Back to Top Unified Pure Icon Bar) */}
        <div className="fixed bottom-5 right-4 sm:right-6 z-40 flex items-center gap-1 p-1.5 rounded-full bg-white/90 dark:bg-slate-950/90 border border-slate-200/90 dark:border-teal-500/30 shadow-lg dark:shadow-[0_10px_30px_rgba(0,0,0,0.5)] backdrop-blur-xl animate-in fade-in slide-in-from-bottom-3 duration-300">
          {/* AI Copilot Trigger */}
          <button
            id="floating-ai-copilot-trigger"
            onClick={() => setShowAIAssistant(true)}
            className="p-2 sm:p-2.5 rounded-full bg-gradient-to-r from-teal-600 to-indigo-600 hover:from-teal-500 hover:to-indigo-500 text-white shadow-md transition-all active:scale-90 flex items-center justify-center"
            title="开启星云智囊 · AI Copilot"
          >
            <Bot className="w-4 h-4 sm:w-5 sm:h-5 animate-pulse text-teal-100 shrink-0" />
          </button>

          {/* Divider if scroll-top button is visible */}
          {showScrollTop && (
            <div className="w-[1px] h-4 bg-slate-200 dark:bg-slate-800 mx-0.5" />
          )}

          {/* Floating Back to Top Button */}
          {showScrollTop && (
            <button
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              className="p-2 sm:p-2.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-teal-600 dark:hover:text-teal-300 transition-colors flex items-center justify-center active:scale-90"
              title="返回顶部"
            >
              <ArrowUp className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Footer */}
        <Footer onNavigate={(tab) => setActiveTab(tab)} />
      </div>

      {/* Article Detail Reading Modal */}
      {selectedPost && (
        <ArticleDetailModal
          post={selectedPost}
          onClose={() => setSelectedPost(null)}
          onLike={(postId) => handleLikePost(postId)}
          onDeletePost={handleDeletePost}
        />
      )}

      {/* Create Post Modal */}
      {showCreatePostModal && (
        <CreatePostModal
          onClose={() => setShowCreatePostModal(false)}
          onAddPost={handleAddPost}
          categories={categoriesList.filter((c) => c !== '全部')}
        />
      )}

      {/* Category Manager Modal */}
      {showCategoryManagerModal && (
        <CategoryManagerModal
          title="文章分类中心与模版管理"
          itemLabel="篇文章"
          getItemCount={(catName) => posts.filter((p) => p.category === catName).length}
          categories={categoriesList}
          onClose={() => setShowCategoryManagerModal(false)}
          onAddCategory={handleAddCategory}
          onRenameCategory={handleRenameCategory}
          onDeleteCategory={handleDeleteCategory}
        />
      )}

      {/* Dev Logs & Storage Configuration Modal */}
      {showDevLogsModal && (
        <DevLogsAndStorageModal
          dbStatusText={dbStatusText}
          onUpdateStatusText={(newText) => setDbStatusText(newText)}
          stats={{
            postsCount: posts.length,
            fragmentsCount: fragments.length,
            reviewsCount: reviews.length,
            projectsCount: projects.length,
          }}
          onClose={() => setShowDevLogsModal(false)}
        />
      )}

      {/* Design Token & Theme Palette Selector Modal */}
      <ThemeSelectorModal
        isOpen={showThemeModal}
        onClose={() => setShowThemeModal(false)}
        currentPresetId={themePreset}
        onSelectPreset={(presetId) => setThemePreset(presetId)}
        currentEnFont={currentEnFont}
        currentCnFont={currentCnFont}
        onSelectFonts={handleSelectFonts}
        theme={theme}
        onToggleTheme={handleToggleTheme}
      />

      {/* VFS Git Time-Travel & Line-by-Line Diff Modal */}
      <VFSTimeTravelModal
        isOpen={showTimeTravelModal}
        onClose={() => setShowTimeTravelModal(false)}
        onRollbackSuccess={() => loadBackendData()}
      />

      {/* MCP Protocol Bridge & Dynamic Skills Center Modal */}
      <MCPSkillHubModal
        isOpen={showMcpSkillModal}
        onClose={() => setShowMcpSkillModal(false)}
      />

      {/* Interactive Knowledge Constellation Topology Graph Modal */}
      <KnowledgeGraphModal
        isOpen={showKnowledgeGraphModal}
        onClose={() => setShowKnowledgeGraphModal(false)}
        posts={posts}
        fragments={fragments}
        projects={projects}
        onSelectPost={(p) => setSelectedPost(p)}
        onAskAIAboutNode={(nodeTitle, nodeCategory) => {
          setShowKnowledgeGraphModal(false);
          setShowAIAssistant(true);
        }}
      />

      {/* Distributed Architecture HA, HP & Extensibility Monitor Modal */}
      <ArchitectureControlModal
        isOpen={showArchModal}
        onClose={() => setShowArchModal(false)}
      />

      {/* Responsive Global Search Card Modal */}
      <SearchModal
        isOpen={showSearchModal}
        onClose={() => setShowSearchModal(false)}
        posts={posts}
        thoughts={fragments}
        projects={projects}
        mindModels={MIND_MODELS}
        setActiveTab={setActiveTab}
        onSelectPost={(p) => setSelectedPost(p)}
      />

      {/* Global AI Copilot (DeepSeek + Linux VFS Architecture) */}
      <GlobalAIAssistant
        isOpen={showAIAssistant}
        onClose={() => setShowAIAssistant(false)}
      />
    </div>
  );
}
