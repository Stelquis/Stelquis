export interface ParsedMarkdown<T = Record<string, any>> {
  data: T;
  content: string;
}

/**
 * 高性能 YAML Frontmatter 轻量级解析器
 * 解析格式：
 * ---
 * title: "..."
 * date: "2026-07-23"
 * tags: ["Tag1", "Tag2"]
 * ---
 * Markdown Content...
 */
export function parseFrontmatter<T = Record<string, any>>(rawMarkdown: string): ParsedMarkdown<T> {
  if (!rawMarkdown) {
    return { data: {} as T, content: '' };
  }

  const frontmatterRegex = /^---\r?\n([\s\S]*?)\r?\n---\r?\n?([\s\S]*)$/;
  const match = rawMarkdown.match(frontmatterRegex);

  if (!match) {
    return { data: {} as T, content: rawMarkdown };
  }

  const yamlBlock = match[1];
  const content = match[2];
  const data: Record<string, any> = {};

  const lines = yamlBlock.split('\n');
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;

    const colonIdx = trimmed.indexOf(':');
    if (colonIdx === -1) continue;

    const key = trimmed.slice(0, colonIdx).trim();
    let valueStr = trimmed.slice(colonIdx + 1).trim();

    // 解析数组格式 [a, b, c]
    if (valueStr.startsWith('[') && valueStr.endsWith(']')) {
      const arrayItems = valueStr
        .slice(1, -1)
        .split(',')
        .map((item) => item.trim().replace(/^['"]|['"]$/g, ''))
        .filter(Boolean);
      data[key] = arrayItems;
    }
    // 解析布尔值
    else if (valueStr === 'true') {
      data[key] = true;
    } else if (valueStr === 'false') {
      data[key] = false;
    }
    // 解析数字
    else if (!isNaN(Number(valueStr)) && valueStr !== '') {
      data[key] = Number(valueStr);
    }
    // 解析带引号的字符串或普通字符串
    else {
      data[key] = valueStr.replace(/^['"]|['"]$/g, '');
    }
  }

  return {
    data: data as T,
    content: content.trim(),
  };
}
