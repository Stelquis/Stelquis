export interface ActiveMedia {
  id: string;
  name: string;
  type: 'audio' | 'video';
  url: string;
  fileType?: string;
  blob?: Blob;
}

export const DEFAULT_MEDIA: ActiveMedia = {
  id: 'preset-ocean-waves',
  name: '潮汐漫涌 (Ocean Ambient)',
  type: 'audio',
  url: 'https://actions.google.com/sounds/v1/water/ocean_waves.ogg',
  fileType: 'audio/ogg',
};

const DB_NAME = 'TideSingleMediaDB';
const DB_VERSION = 1;
const STORE_NAME = 'active_media';

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (!window.indexedDB) {
      reject(new Error('IndexedDB not supported'));
      return;
    }
    const request = window.indexedDB.open(DB_NAME, DB_VERSION);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'key' });
      }
    };
  });
}

export async function saveActiveMedia(file: File): Promise<ActiveMedia> {
  const isVideo = file.type.startsWith('video/');
  const trackName = file.name.replace(/\.[^/.]+$/, '');
  const url = URL.createObjectURL(file);

  const media: ActiveMedia = {
    id: `custom-${Date.now()}`,
    name: trackName,
    type: isVideo ? 'video' : 'audio',
    url,
    fileType: file.type,
    blob: file,
  };

  try {
    const db = await openDb();
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    store.put({
      key: 'current',
      id: media.id,
      name: media.name,
      type: media.type,
      fileType: media.fileType,
      blob: file,
    });
    await new Promise((resolve, reject) => {
      tx.oncomplete = resolve;
      tx.onerror = () => reject(tx.error);
    });
  } catch (err) {
    console.warn('IndexedDB save failed:', err);
  }

  return media;
}

export async function getActiveMedia(): Promise<ActiveMedia | null> {
  try {
    const db = await openDb();
    const tx = db.transaction(STORE_NAME, 'readonly');
    const store = tx.objectStore(STORE_NAME);
    const request = store.get('current');

    const result: any = await new Promise((resolve, reject) => {
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });

    if (result && result.blob) {
      const blob = result.blob as Blob;
      return {
        id: result.id,
        name: result.name,
        type: result.type,
        url: URL.createObjectURL(blob),
        fileType: result.fileType,
        blob,
      };
    }
  } catch (err) {
    console.warn('IndexedDB load failed:', err);
  }
  return null;
}

export async function resetToDefaultMedia(): Promise<ActiveMedia> {
  try {
    const db = await openDb();
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    store.delete('current');
  } catch (err) {
    console.warn('Reset media failed:', err);
  }
  return DEFAULT_MEDIA;
}
