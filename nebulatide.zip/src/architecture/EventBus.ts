/**
 * 📡 NebulaTide (星云潮汐) - 分布式架构解耦事件总线 (Event Bus)
 * 提供低耦合、高性能、异步响应式的组件/模块间消息派发机制
 */

export type EventCallback<T = any> = (payload: T) => void | Promise<void>;

export class EventBus {
  private static instance: EventBus;
  private listeners: Map<string, Set<EventCallback>> = new Map();

  private constructor() {}

  public static getInstance(): EventBus {
    if (!EventBus.instance) {
      EventBus.instance = new EventBus();
    }
    return EventBus.instance;
  }

  public on<T = any>(event: string, callback: EventCallback<T>): () => void {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, new Set());
    }
    this.listeners.get(event)!.add(callback);

    // 返回解绑函数
    return () => {
      this.off(event, callback);
    };
  }

  public off(event: string, callback: EventCallback): void {
    const callbacks = this.listeners.get(event);
    if (callbacks) {
      callbacks.delete(callback);
      if (callbacks.size === 0) {
        this.listeners.delete(event);
      }
    }
  }

  public async emit<T = any>(event: string, payload?: T): Promise<void> {
    const callbacks = this.listeners.get(event);
    if (!callbacks || callbacks.size === 0) return;

    const promises: Promise<void>[] = [];
    callbacks.forEach((cb) => {
      try {
        const res = cb(payload);
        if (res instanceof Promise) {
          promises.push(res.catch((err) => console.error(`[EventBus] ❌ 异步事件处理器出错 [${event}]:`, err)));
        }
      } catch (err) {
        console.error(`[EventBus] ❌ 同步事件处理器出错 [${event}]:`, err);
      }
    });

    if (promises.length > 0) {
      await Promise.allSettled(promises);
    }
  }

  public getMetrics() {
    const events: Record<string, number> = {};
    this.listeners.forEach((set, name) => {
      events[name] = set.size;
    });
    return {
      activeEventTypesCount: this.listeners.size,
      events,
    };
  }
}

export const globalEventBus = EventBus.getInstance();
