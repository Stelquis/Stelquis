/**
 * ⛓️ NebulaTide (星云潮汐) - 责任链管道中间件引擎 (Pipeline Architecture)
 * 提供可扩展的数据加工过滤流 (Data Interception & Middleware Chain)
 */

export type Middleware<T> = (data: T, next: () => Promise<T>) => Promise<T>;

export class Pipeline<T> {
  private middlewares: Middleware<T>[] = [];

  public use(middleware: Middleware<T>): this {
    this.middlewares.push(middleware);
    return this;
  }

  public async execute(initialData: T): Promise<T> {
    let index = -1;

    const dispatch = async (i: number, currentData: T): Promise<T> => {
      if (i <= index) {
        throw new Error('Pipeline middleware next() called multiple times');
      }
      index = i;

      if (i === this.middlewares.length) {
        return currentData;
      }

      const middleware = this.middlewares[i];
      return await middleware(currentData, () => dispatch(i + 1, currentData));
    };

    return await dispatch(0, initialData);
  }

  public getMiddlewareCount(): number {
    return this.middlewares.length;
  }
}
