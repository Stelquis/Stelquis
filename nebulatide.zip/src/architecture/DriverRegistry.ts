/**
 * 🔌 NebulaTide (星云潮汐) - 驱动引擎注册表 (Driver Architecture)
 * 面向接口编程，抽象底层存储 (Storage Driver) 与 AI Copilot 模型提供商 (LLM Driver)
 * 实现系统的最高可扩展性 (Extensibility)
 */

// 1. 存储驱动抽象接口
export interface IStorageDriver {
  id: string;
  name: string;
  type: 'vfs-remote' | 'indexed-db' | 'local-storage' | 'memory';
  isAvailable(): Promise<boolean>;
  get<T>(key: string): Promise<T | null>;
  set<T>(key: string, value: T): Promise<void>;
  delete(key: string): Promise<void>;
  keys(): Promise<string[]>;
}

// 2. AI Copilot 驱动抽象接口
export interface ILLMDriver {
  id: string;
  name: string;
  provider: string;
  supportedModels: string[];
  chat(request: any): Promise<any>;
}

export class DriverRegistry {
  private static instance: DriverRegistry;
  private storageDrivers = new Map<string, IStorageDriver>();
  private llmDrivers = new Map<string, ILLMDriver>();
  private activeStorageDriverId: string = 'vfs-remote';
  private activeLLMDriverId: string = 'deepseek';

  private constructor() {
    this.registerDefaultDrivers();
  }

  public static getInstance(): DriverRegistry {
    if (!DriverRegistry.instance) {
      DriverRegistry.instance = new DriverRegistry();
    }
    return DriverRegistry.instance;
  }

  public registerStorageDriver(driver: IStorageDriver) {
    this.storageDrivers.set(driver.id, driver);
    console.log(`[DriverRegistry] 🔌 注册存储驱动: ${driver.name} (${driver.id})`);
  }

  public registerLLMDriver(driver: ILLMDriver) {
    this.llmDrivers.set(driver.id, driver);
    console.log(`[DriverRegistry] 🧠 注册 LLM 引擎驱动: ${driver.name} (${driver.id})`);
  }

  public getActiveStorageDriver(): IStorageDriver {
    return this.storageDrivers.get(this.activeStorageDriverId) || this.storageDrivers.get('local-storage')!;
  }

  public setActiveStorageDriver(id: string) {
    if (this.storageDrivers.has(id)) {
      this.activeStorageDriverId = id;
      console.log(`[DriverRegistry] 🔀 切换当前活跃存储驱动为: ${id}`);
    }
  }

  public getActiveLLMDriver(): ILLMDriver | undefined {
    return this.llmDrivers.get(this.activeLLMDriverId);
  }

  public getAllStorageDrivers(): IStorageDriver[] {
    return Array.from(this.storageDrivers.values());
  }

  public getAllLLMDrivers(): ILLMDriver[] {
    return Array.from(this.llmDrivers.values());
  }

  private registerDefaultDrivers() {
    // 默认 LocalStorage 存储驱动
    this.registerStorageDriver({
      id: 'local-storage',
      name: '浏览器原生 LocalStorage 引擎',
      type: 'local-storage',
      async isAvailable() { return typeof window !== 'undefined' && !!window.localStorage; },
      async get<T>(key: string) {
        const raw = localStorage.getItem(key);
        return raw ? JSON.parse(raw) : null;
      },
      async set<T>(key: string, value: T) {
        localStorage.setItem(key, JSON.stringify(value));
      },
      async delete(key: string) {
        localStorage.removeItem(key);
      },
      async keys() {
        return Object.keys(localStorage);
      }
    });

    // 默认 VFS 远程 REST/SQLite 存储驱动
    this.registerStorageDriver({
      id: 'vfs-remote',
      name: 'VFS Linux 虚拟文件系统 (REST API)',
      type: 'vfs-remote',
      async isAvailable() { return true; },
      async get<T>(key: string) {
        const res = await fetch(`/api/vfs/file?path=${encodeURIComponent(key)}`);
        if (!res.ok) return null;
        return await res.json();
      },
      async set<T>(key: string, value: T) {
        await fetch(`/api/vfs/save`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ path: key, content: value })
        });
      },
      async delete(key: string) {
        await fetch(`/api/vfs/delete`, {
          method: 'DELETE',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ path: key })
        });
      },
      async keys() {
        const res = await fetch('/api/vfs/tree');
        if (!res.ok) return [];
        const tree = await res.json();
        return Object.values(tree.categories || {}).flatMap((c: any) => (c.files || []).map((f: any) => f.path));
      }
    });
  }
}

export const driverRegistry = DriverRegistry.getInstance();
