/**
 * 📊 NebulaTide (星云潮汐) - 分布式系统健康度与架构控制中心 (System Health & Architecture Monitor)
 * 实时监控高可用 (HA)、高性能 (HP) 与可扩展性 (Extensibility) 状态
 */

import { CircuitBreaker } from './CircuitBreaker';
import { LRUCache } from './LRUCache';
import { globalEventBus } from './EventBus';
import { driverRegistry } from './DriverRegistry';

export interface ArchitectureMetrics {
  healthScore: number; // 0-100 健康综合分
  haStatus: 'HEALTHY' | 'DEGRADED' | 'CRITICAL';
  hpMetrics: {
    cacheSize: number;
    hitRate: string;
    coalescedRequests: number; // 合并减少的并发 API 瓶颈请求数
  };
  circuitBreakers: {
    name: string;
    state: string;
    failureCount: number;
  }[];
  activeDrivers: {
    storage: string;
    llm: string;
  };
  eventBusListenersCount: number;
  uptimeSeconds: number;
}

export class SystemHealthMonitor {
  private static instance: SystemHealthMonitor;
  private startTime = Date.now();
  private circuitBreakers = new Map<string, CircuitBreaker<any>>();
  private lruCacheInstance: LRUCache<any, any> | null = null;

  private constructor() {}

  public static getInstance(): SystemHealthMonitor {
    if (!SystemHealthMonitor.instance) {
      SystemHealthMonitor.instance = new SystemHealthMonitor();
    }
    return SystemHealthMonitor.instance;
  }

  public registerCircuitBreaker(cb: CircuitBreaker<any>) {
    this.circuitBreakers.set(cb.name, cb);
  }

  public registerLRUCache(cache: LRUCache<any, any>) {
    this.lruCacheInstance = cache;
  }

  public getMetrics(): ArchitectureMetrics {
    const cbMetrics = Array.from(this.circuitBreakers.values()).map(cb => cb.getMetrics());
    const openCount = cbMetrics.filter(m => m.state === 'OPEN').length;
    const halfOpenCount = cbMetrics.filter(m => m.state === 'HALF_OPEN').length;

    let haStatus: ArchitectureMetrics['haStatus'] = 'HEALTHY';
    let healthScore = 100;

    if (openCount > 0) {
      haStatus = 'CRITICAL';
      healthScore -= openCount * 30;
    } else if (halfOpenCount > 0) {
      haStatus = 'DEGRADED';
      healthScore -= halfOpenCount * 15;
    }

    const cacheMetrics = this.lruCacheInstance ? this.lruCacheInstance.getMetrics() : { size: 0, hitRate: '100%', coalescedCount: 0 };
    const ebMetrics = globalEventBus.getMetrics();

    return {
      healthScore: Math.max(0, healthScore),
      haStatus,
      hpMetrics: {
        cacheSize: cacheMetrics.size,
        hitRate: cacheMetrics.hitRate,
        coalescedRequests: cacheMetrics.coalescedCount,
      },
      circuitBreakers: cbMetrics.map(m => ({
        name: m.name,
        state: m.state,
        failureCount: m.failureCount,
      })),
      activeDrivers: {
        storage: driverRegistry.getActiveStorageDriver().name,
        llm: driverRegistry.getActiveLLMDriver()?.name || 'DeepSeek Engine',
      },
      eventBusListenersCount: ebMetrics.activeEventTypesCount,
      uptimeSeconds: Math.floor((Date.now() - this.startTime) / 1000),
    };
  }
}

export const systemHealthMonitor = SystemHealthMonitor.getInstance();
