/**
 * ⚡ NebulaTide (星云潮汐) - 高性能 (HP) 双向链表 LRU 缓存与请求合并去重器 (Request Coalescing)
 * 支持 O(1) 淘汰、TTL 过期判定、In-Flight 并发请求去重与击穿防护
 */

export interface CacheNode<K, V> {
  key: K;
  value: V;
  expireAt: number;
  prev: CacheNode<K, V> | null;
  next: CacheNode<K, V> | null;
}

export interface LRUCacheOptions {
  capacity?: number; // 最大缓存节点数，默认 100
  defaultTtlMs?: number; // 默认 TTL，默认 30,000ms (30s)
}

export class LRUCache<K extends string, V> {
  private capacity: number;
  private defaultTtlMs: number;
  private cache = new Map<K, CacheNode<K, V>>();
  private inFlightRequests = new Map<K, Promise<V>>(); // 并发请求去重池

  private head: CacheNode<K, V> | null = null;
  private tail: CacheNode<K, V> | null = null;

  // 架构性能指标统计
  private hits = 0;
  private misses = 0;
  private coalescedCount = 0; // 成功去重的合并请求数

  constructor(options: LRUCacheOptions = {}) {
    this.capacity = options.capacity ?? 100;
    this.defaultTtlMs = options.defaultTtlMs ?? 30000;
  }

  /**
   * 核心防击穿 API: 如果命中 LRU 则直接返回；如果同一 Request Key 有其他请求在进行中，自动合并复用其 Promise！
   */
  public async getOrFetch(key: K, fetcher: () => Promise<V>, ttlMs?: number): Promise<V> {
    // 1. 检查 LRU 缓存
    const cached = this.get(key);
    if (cached !== undefined) {
      return cached;
    }

    // 2. 检查是否有在途 (In-Flight) 请求，实现请求去重 (Request Coalescing)
    if (this.inFlightRequests.has(key)) {
      this.coalescedCount++;
      // console.log(`[LRUCache] ⚡ 检测到在途请求 (${key})，自动合并并发请求，复用同一 IO`);
      return await this.inFlightRequests.get(key)!;
    }

    // 3. 发起新请求并注册到去重池
    const fetchPromise = (async () => {
      try {
        const val = await fetcher();
        this.put(key, val, ttlMs);
        return val;
      } finally {
        this.inFlightRequests.delete(key);
      }
    })();

    this.inFlightRequests.set(key, fetchPromise);
    return await fetchPromise;
  }

  public get(key: K): V | undefined {
    const node = this.cache.get(key);
    if (!node) {
      this.misses++;
      return undefined;
    }

    // 检查 TTL 是否过期
    if (Date.now() > node.expireAt) {
      this.removeNode(node);
      this.cache.delete(key);
      this.misses++;
      return undefined;
    }

    // 命中缓存，提升为头节点
    this.hits++;
    this.moveToHead(node);
    return node.value;
  }

  public put(key: K, value: V, ttlMs?: number): void {
    const effectiveTtl = ttlMs ?? this.defaultTtlMs;
    const expireAt = Date.now() + effectiveTtl;

    const existingNode = this.cache.get(key);
    if (existingNode) {
      existingNode.value = value;
      existingNode.expireAt = expireAt;
      this.moveToHead(existingNode);
      return;
    }

    if (this.cache.size >= this.capacity && this.tail) {
      this.cache.delete(this.tail.key);
      this.removeNode(this.tail);
    }

    const newNode: CacheNode<K, V> = {
      key,
      value,
      expireAt,
      prev: null,
      next: null,
    };

    this.addToHead(newNode);
    this.cache.set(key, newNode);
  }

  public clear(): void {
    this.cache.clear();
    this.inFlightRequests.clear();
    this.head = null;
    this.tail = null;
  }

  public getMetrics() {
    const total = this.hits + this.misses;
    const hitRate = total > 0 ? ((this.hits / total) * 100).toFixed(1) + '%' : '0%';
    return {
      size: this.cache.size,
      capacity: this.capacity,
      hits: this.hits,
      misses: this.misses,
      hitRate,
      coalescedCount: this.coalescedCount,
      inFlightCount: this.inFlightRequests.size,
    };
  }

  private addToHead(node: CacheNode<K, V>): void {
    node.next = this.head;
    node.prev = null;

    if (this.head) {
      this.head.prev = node;
    }
    this.head = node;

    if (!this.tail) {
      this.tail = node;
    }
  }

  private removeNode(node: CacheNode<K, V>): void {
    if (node.prev) {
      node.prev.next = node.next;
    } else {
      this.head = node.next;
    }

    if (node.next) {
      node.next.prev = node.prev;
    } else {
      this.tail = node.prev;
    }
  }

  private moveToHead(node: CacheNode<K, V>): void {
    this.removeNode(node);
    this.addToHead(node);
  }
}
