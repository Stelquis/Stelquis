/**
 * 🛡️ NebulaTide (星云潮汐) - 分布式高可用 (HA) 容错降级断路器 (Circuit Breaker)
 * 采用标准的 CLOSED -> OPEN -> HALF_OPEN 三态熔断降级有限状态机
 */

export type CircuitState = 'CLOSED' | 'OPEN' | 'HALF_OPEN';

export interface CircuitBreakerOptions<T> {
  name: string;
  failureThreshold?: number; // 失败触发熔断的连续或时间窗口内次数，默认 3
  recoveryTimeoutMs?: number; // 熔断后冷却时间，单位 ms，默认 10,000ms
  fallback: (...args: any[]) => T | Promise<T>; // 降级回退函数
  onStateChange?: (state: CircuitState, name: string) => void;
}

export class CircuitBreaker<T> {
  public name: string;
  private state: CircuitState = 'CLOSED';
  private failureCount: number = 0;
  private successCount: number = 0;
  private failureThreshold: number;
  private recoveryTimeoutMs: number;
  private lastStateChangeTime: number = Date.now();
  private fallbackFn: (...args: any[]) => T | Promise<T>;
  private onStateChange?: (state: CircuitState, name: string) => void;

  constructor(options: CircuitBreakerOptions<T>) {
    this.name = options.name;
    this.failureThreshold = options.failureThreshold ?? 3;
    this.recoveryTimeoutMs = options.recoveryTimeoutMs ?? 10000;
    this.fallbackFn = options.fallback;
    this.onStateChange = options.onStateChange;
  }

  public getState(): CircuitState {
    // 检查是否在 OPEN 状态下已经过了冷却期，若是则转换为 HALF_OPEN
    if (this.state === 'OPEN' && Date.now() - this.lastStateChangeTime > this.recoveryTimeoutMs) {
      this.transitionTo('HALF_OPEN');
    }
    return this.state;
  }

  public getMetrics() {
    return {
      name: this.name,
      state: this.getState(),
      failureCount: this.failureCount,
      successCount: this.successCount,
      lastStateChangeTime: this.lastStateChangeTime,
    };
  }

  public async execute(fn: (...args: any[]) => Promise<T>, ...args: any[]): Promise<T> {
    const currentState = this.getState();

    // 如果断路器打开，直接走降级逻辑 (Fast-Fail & Fallback)
    if (currentState === 'OPEN') {
      console.warn(`[CircuitBreaker:${this.name}] 🛡️ 断路器处于熔断 OPEN 状态，触发优雅降级 (Fallback)`);
      return await this.fallbackFn(...args);
    }

    try {
      const result = await fn(...args);
      this.onSuccess();
      return result;
    } catch (error) {
      console.error(`[CircuitBreaker:${this.name}] ⚠️ 请求执行异常:`, error);
      this.onFailure();
      return await this.fallbackFn(...args);
    }
  }

  private onSuccess() {
    this.failureCount = 0;
    this.successCount++;
    if (this.state === 'HALF_OPEN') {
      console.log(`[CircuitBreaker:${this.name}] ✅ 探针重试成功，服务自愈，断路器重置为 CLOSED`);
      this.transitionTo('CLOSED');
    }
  }

  private onFailure() {
    this.failureCount++;
    if (this.state === 'HALF_OPEN' || this.failureCount >= this.failureThreshold) {
      console.warn(`[CircuitBreaker:${this.name}] 🚨 连续失败次数达到阈值 (${this.failureCount})，触发熔断保护 (OPEN)`);
      this.transitionTo('OPEN');
    }
  }

  private transitionTo(newState: CircuitState) {
    if (this.state !== newState) {
      this.state = newState;
      this.lastStateChangeTime = Date.now();
      if (this.onStateChange) {
        this.onStateChange(newState, this.name);
      }
    }
  }

  public forceReset() {
    this.failureCount = 0;
    this.transitionTo('CLOSED');
  }
}
