import { DEFAULT_AI_MODEL_ID } from "../config/aiModels";

export interface AgenticAction {
  type: string;
  label: string;
  payload: Record<string, any>;
  healingMetadata?: {
    healed: boolean;
    attempts: number;
    originalIssue?: string;
    healedAt?: string;
  };
}

export interface AIChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  reasoningContent?: string;
  referencedFiles?: { path: string; title: string; category: string }[];
  provider?: string;
  timestamp: string;
  agenticAction?: AgenticAction | null;
}

export interface AIChatRequest {
  prompt: string;
  provider?: string;
  model?: string;
  contextPaths?: string[];
  history?: { role: string; content: string }[];
  customApiKey?: string;
  customBaseUrl?: string;
}

export interface AIChatResponse {
  reasoningContent?: string;
  content: string;
  referencedFiles?: { path: string; title: string; category: string }[];
  provider?: string;
  agenticAction?: AgenticAction | null;
}

export interface TestConnectionRequest {
  apiKey?: string;
  baseUrl?: string;
  model?: string;
}

export interface TestConnectionResponse {
  success: boolean;
  message: string;
  latencyMs: number;
}

export const aiService = {
  async sendChat(req: AIChatRequest): Promise<AIChatResponse> {
    const res = await fetch("/api/ai/chat", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        prompt: req.prompt,
        provider: req.provider || "deepseek",
        model: req.model || DEFAULT_AI_MODEL_ID,
        contextPaths: req.contextPaths || [],
        history: req.history || [],
        customApiKey: req.customApiKey || "",
        customBaseUrl: req.customBaseUrl || ""
      })
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: "AI Service Error" }));
      throw new Error(err.error || "Failed to communicate with AI Copilot");
    }

    return await res.json();
  },

  async sendChatStream(
    req: AIChatRequest,
    onChunk: (event: { type: string; delta?: string; [key: string]: any }) => void,
    onError: (err: Error) => void,
    onDone: () => void
  ): Promise<void> {
    try {
      const res = await fetch("/api/ai/stream", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          prompt: req.prompt,
          provider: req.provider || "deepseek",
          model: req.model || DEFAULT_AI_MODEL_ID,
          contextPaths: req.contextPaths || []
        })
      });

      if (!res.ok || !res.body) {
        throw new Error("Streaming connection failed");
      }

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n\n");
        buffer = lines.pop() || "";

        for (const line of lines) {
          if (line.startsWith("data: ")) {
            try {
              const data = JSON.parse(line.slice(6));
              if (data.type === "done") {
                onDone();
                return;
              }
              onChunk(data);
            } catch (e) {
              console.warn("Error parsing SSE line:", e);
            }
          }
        }
      }
      onDone();
    } catch (err: any) {
      onError(err);
    }
  },

  async testConnection(req: TestConnectionRequest): Promise<TestConnectionResponse> {
    const res = await fetch("/api/ai/test-connection", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(req)
    });

    if (!res.ok) {
      return {
        success: false,
        message: "测试网络请求失败",
        latencyMs: 0
      };
    }

    return await res.json();
  }
};


