/**
 * MCP Protocol Bridge & Dynamic Skills Center Service
 */

export interface MCPSchema {
  protocol: string;
  serverInfo: { name: string; version: string };
  tools: {
    name: string;
    description: string;
    inputSchema: Record<string, any>;
  }[];
  resources: {
    uri: string;
    name: string;
    description: string;
    mimeType: string;
  }[];
  prompts: {
    name: string;
    description: string;
    arguments?: { name: string; description: string; required?: boolean }[];
  }[];
}

export interface AgentSkill {
  id: string;
  name: string;
  category: "ARCH" | "SEO" | "PHILOSOPHY" | "CODE" | "SYSTEM";
  description: string;
  rules: string[];
  enabled: boolean;
  systemPromptModifier: string;
}

export const mcpSkillService = {
  /**
   * Fetch MCP Protocol Schema
   */
  async getMCPSchema(): Promise<MCPSchema> {
    const res = await fetch("/api/mcp/schema");
    if (!res.ok) throw new Error("Failed to fetch MCP schema");
    return res.json();
  },

  /**
   * Call MCP Tool via JSON-RPC 2.0
   */
  async callMCPTool(toolName: string, args: Record<string, any>): Promise<any> {
    const res = await fetch("/api/mcp", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        jsonrpc: "2.0",
        id: Date.now(),
        method: "tools/call",
        params: { name: toolName, arguments: args }
      })
    });
    if (!res.ok) throw new Error("MCP Tool execution request failed");
    return res.json();
  },

  /**
   * Read MCP Resource
   */
  async readMCPResource(uri: string): Promise<any> {
    const res = await fetch("/api/mcp", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        jsonrpc: "2.0",
        id: Date.now(),
        method: "resources/read",
        params: { uri }
      })
    });
    if (!res.ok) throw new Error("MCP Resource read failed");
    return res.json();
  },

  /**
   * Fetch Installed Dynamic Skills
   */
  async getSkills(): Promise<{ count: number; skills: AgentSkill[] }> {
    const res = await fetch("/api/skills");
    if (!res.ok) throw new Error("Failed to fetch skills");
    return res.json();
  },

  /**
   * Toggle Skill Active State
   */
  async toggleSkill(id: string): Promise<{ success: boolean; skill: AgentSkill }> {
    const res = await fetch(`/api/skills/${id}/toggle`, {
      method: "POST"
    });
    if (!res.ok) throw new Error("Failed to toggle skill");
    return res.json();
  }
};
