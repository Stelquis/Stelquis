import { Post } from '../types';
import { parseFrontmatter } from '../utils/frontmatter';

/**
 * 静态内嵌的 Fallback 文章（防止循环依赖，并为 Node 服务器与极端无 Markdown 环境提供高可用安全支撑）
 */
export const RAW_FALLBACK_POSTS: Post[] = [
  {
    id: "manifesto-post",
    title: "NebulaTide 哲学：一个关于混沌与潮汐的故事",
    subtitle: "清晰不是混沌的对立面，而是混沌的沉积物",
    excerpt: "思绪初生时，从来不是条理分明的。它像星云弥漫、缠绕、没有边界。NebulaTide 的第一层邀请：停下来，让雾气停留一会儿...",
    content: `# 🌌 NebulaTide 哲学：一个关于混沌与潮汐的故事

## 一、🧘 星云之境：承认混沌是起点

思绪初生时，从来不是条理分明的。

它像星云 ☁️ 弥漫、缠绕、没有边界。一个灵感与另一个焦虑碰撞，待办事项和深夜emo共存。我们习惯急着整理，急着"想清楚"，却忘了 🌱 **混沌本身就是创造的温床**。

NebulaTide 的第一层邀请 👋 **停下来，让雾气停留一会儿**。

不急着开灯。在星云的暗处 ✨ 有些东西正在缓慢发光。

---

## 二、🌊 潮汐之律：复盘是自然的呼吸

星云不会自己变成星座，但也不会永远混沌。

它需要 🧘‍♂️ **潮汐** ——那种周期性的回望，那种"退后一步"的姿态。

> 涨潮时 🌊 我们向外奔涌，执行、碰撞、试错  
> 退潮时 🐚 我们弯腰捡拾，那些散落的贝壳开始显形

复盘不是自责的仪式，不是KPI的清算。它是 👋 **呼吸** ——吸气时扩张，呼气时沉淀。没有对错，只有节律。

每周、每月、每季 🏖️ 潮水会带走沙砾，留下真正属于你的东西。

---

## 三、🕸️ 织网之时：规划是顺势的编织

当贝壳足够多，你会看见隐形的线。

不是强行画一条 🚫 "正确道路"，而是像潮汐编织海岸一样 🌅 让方向**自然浮现**。

### NebulaTide 的规划观：
- 🔮 **不预测遥远的未来**
- 🌊 **只感知此刻的流向**
- 🧭 **把复盘得到的珍珠，串成下一程的罗盘**

规划不是对抗不确定性 💃 而是**与不确定性共舞**。

---

## 四、🧘‍♀️ 一个人的仪式

这就是 NebulaTide 想陪伴你的时刻：

> 🌙 **深夜**，打开页面，星云般的思绪倾泻而出，不加修饰  
> ☕ **周末**，潮水退去，你静静回看，标记那些闪光的碎片  
> 🌅 **月初**，新的周期开始，你把贝壳摆成大致的形状，然后—— 👋 **再次踏入雾中，但心里多了一些确信**

---

## ✨ 窝们的相信

🌌 **清晰不是混沌的对立面，而是混沌的沉积物**  
🌊 **复盘不是终点，而是呼吸本身**  
🧭 **规划不是地图，而是感受流向的能力**  

> *"🌌 潮起时航行，潮落时织网。—— 星云深处，自有暗流指引。🌊"*

---

🧘 **NebulaTide** — 你的混沌潮汐，你的方向感 👋
`,
    category: "哲学宣言",
    tags: ["NebulaTide", "心智模式", "混沌哲学", "潮汐复盘"],
    date: "2026-07-23",
    readTime: "4 分钟",
    coverImage: "https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?q=80&w=1200&auto=format&fit=crop",
    featured: true,
    likes: 128,
    author: {
      name: "Niu (Stelquis)",
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=200&auto=format&fit=crop",
      role: "CSU · AI / Data Science / Cloud-Native"
    }
  },
  {
    id: "post-deepastradraft",
    title: "DeepAstraDraft：如何为 DWG/DXF 工业图纸注入 123 项语义索引与自然语言 Agent？",
    subtitle: "从几何图元解析到多模态 CAD 智能问答系统",
    excerpt: "CAD 图纸是工业界的通用语言，但缺乏可计算的结构化语义。本文拆解我们如何通过图结构提取、参数解析与 Agent 索引，实现 93.1% 的高精度问答...",
    content: `# DeepAstraDraft：CAD 图纸智能问答 Agent 架构拆解

在工业设计与工程建设中，DWG/DXF 格式存储了极其丰富的几何与尺寸信息。然而传统 CAD 数据往往呈现“散沙”状态。

## 1. 第一性原理：CAD 图元与工程语义的解耦
图纸表面上是线段、圆弧、块（Block）与文本（MText），但工程人员关心的本质是**“装配关系、极限偏差、材质属性与工序依赖”**。

- **解析层**：精准提取 DXF 实体层级，构建拓扑图。
- **语义层**：将 123 项核心参数（如公差、螺纹规格、倒角）映射至向量与属性图数据库。
- **Agent 交互层**：采用 Prompt-to-Query 生成器，通过多轮校验解决 CAD 专业用语歧义。

## 2. 核心成果
在测试集中，自然语言理解与参数检索准确率达到了 **93.1%**。这是 NebulaTide 哲学中“将散沙凝结成网络”的典型实战应用。`,
    category: "系统构建",
    tags: ["DeepAstraDraft", "CAD", "Agent", "LLM", "RAG"],
    date: "2026-07-05",
    readTime: "8 分钟",
    coverImage: "https://images.unsplash.com/photo-1581092160607-ee22621dd758?q=80&w=1200&auto=format&fit=crop",
    featured: true,
    likes: 112,
    author: {
      name: "Niu (Stelquis)",
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=200&auto=format&fit=crop",
      role: "CSU · AI / Data Science / Cloud-Native"
    }
  },
  {
    id: "post-video-preload",
    title: "短视频流自适应预加载算法：ACM Multimedia 竞赛实践与网络潮汐感知",
    subtitle: "如何在动态弱网下提升 QoE 并大幅削减 21% 的带宽浪费？",
    excerpt: "移动短视频的播放体验依赖预加载策略。过激会导致带宽浪费，滞后会导致卡顿。本文分享 ACM MM Challenge 获奖方案思路...",
    content: `# 短视频流自适应预加载算法：ACM MM 2022 挑战赛实战

短视频播放的预加载挑战，本质上是对用户行为“潮汐”与移动网络“暗流”的预测游戏。

## 核心架构设计

1. **用户滑动意图预测器**：融合快滑、长留、重复观看等上下文特征。
2. **带宽感知与 Q-Learning 调整**：实时评估 RTT 与下行带宽吞吐，动态计算最优预加载分片长度。
3. **成果指标**：
   - 综合得分 **+45%**
   - 用户体验 QoE 提升 **+7.5%**
   - 无效带宽浪费降低 **-21%**`,
    category: "深度思考",
    tags: ["ACM MM", "视频算法", "带宽优化", "QoE"],
    date: "2026-01-15",
    readTime: "7 分钟",
    coverImage: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?q=80&w=1200&auto=format&fit=crop",
    featured: false,
    likes: 95,
    author: {
      name: "Niu (Stelquis)",
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=200&auto=format&fit=crop",
      role: "CSU · AI / Data Science / Cloud-Native"
    }
  },
  {
    id: "post-2",
    title: "在碎片化时代，保留一片星云般的非结构化心智",
    subtitle: "为什么过度分类会扼杀最原始的灵感暗流？",
    excerpt: "现代效率工具教我们把一切打上 Tag、归入文件夹、制成甘特图。但最迷人的创造往往诞生于未归类的混乱交界处...",
    content: `在效率主义至上的时代，各种 Notion 模板、笔记系统都在告诫我们：要把混乱整理成库。

但是，当你太快给一个灵感打上标签（Tag）或放入具体分类时，你其实是在**过早关闭它的可能性**。

### 1. 灵感的星云阶段
概念刚诞生时，它是温热而模糊的。它既像是一个技术架构的构想，又像是一段情绪的隐喻。

如果你强行把它归为“工作/技术/待办”，它就失去了与“哲学/艺术/日常生活”产生化学反应的机会。

### 2. 容忍不确定性的勇气
在 NebulaTide 体系中，我们设置了“星云碎片”这块空间。不要求标题、不要求分类、不要求完美的语法。

**给自己的大脑一个可以犯乱、可以模糊的沙盒**。

真正的清晰，从来不是硬灌进去的结构，而是像潮水退去后，天然沉淀在沙滩上的贝壳纹理。`,
    category: "心智复盘",
    tags: ["非结构化", "灵感孕育", "思考习惯"],
    date: "2026-07-20",
    readTime: "6 分钟",
    coverImage: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?q=80&w=1200&auto=format&fit=crop",
    featured: false,
    likes: 86,
    author: {
      name: "Niu (Stelquis)",
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=200&auto=format&fit=crop",
      role: "CSU · AI / Data Science / Cloud-Native"
    }
  }
];

/**
 * 结构化 Markdown 文章加载与缓存服务 (High Performance & Highly Available Content Service)
 */
class MarkdownService {
  private postsCache: Post[] | null = null;

  /**
   * 载入并解析所有 Markdown 文章文件
   */
  public getAllPosts(): Post[] {
    if (this.postsCache) {
      return this.postsCache;
    }

    try {
      const parsedPosts: Post[] = [];
      let rawMarkdownFiles: Record<string, any> = {};

      // 1. 尝试 Vite 浏览器前端运行环境下的 import.meta.glob
      if (typeof import.meta !== 'undefined' && typeof (import.meta as any)?.glob === 'function') {
        try {
          rawMarkdownFiles = (import.meta as any).glob('/content/posts/*.md', {
            query: '?raw',
            eager: true,
          });
        } catch (e) {
          console.warn('[MarkdownService] Vite import.meta.glob 执行跳过:', e);
        }
      }

      // 2. 解析由 import.meta.glob 读取到的模块内容
      Object.entries(rawMarkdownFiles).forEach(([filePath, fileModule]) => {
        const rawText = typeof fileModule === 'string' ? fileModule : (fileModule as any)?.default || '';
        if (!rawText) return;

        const { data, content } = parseFrontmatter(rawText);

        const post: Post = {
          id: data.id || filePath.replace(/^.*[\\/]/, '').replace(/\.md$/, ''),
          title: data.title || '无标题文章',
          subtitle: data.subtitle || '',
          excerpt: data.excerpt || content.slice(0, 100) + '...',
          content: content,
          category: data.category || '未分类',
          tags: Array.isArray(data.tags) ? data.tags : [],
          date: data.date || new Date().toISOString().split('T')[0],
          readTime: data.readTime || '3 分钟',
          coverImage: data.coverImage || 'https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?q=80&w=1200&auto=format&fit=crop',
          featured: Boolean(data.featured),
          likes: Number(data.likes) || 0,
          author: {
            name: data.authorName || 'Niu (Stelquis)',
            avatar: data.authorAvatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=200&auto=format&fit=crop',
            role: data.authorRole || 'CSU · AI / Data Science',
          },
        };

        parsedPosts.push(post);
      });

      // 如果成功动态解析出文章，按时间倒序排列并返回
      if (parsedPosts.length > 0) {
        parsedPosts.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
        this.postsCache = parsedPosts;
        return parsedPosts;
      }
    } catch (err) {
      console.warn('[MarkdownService] 动态解析文章出现异常，降级至静态数据方案:', err);
    }

    // 3. 高可用降级方案：使用 Raw Fallback 数据
    this.postsCache = RAW_FALLBACK_POSTS;
    return RAW_FALLBACK_POSTS;
  }

  /**
   * 根据 ID 或 Slug 获取单篇文章
   */
  public getPostById(id: string): Post | undefined {
    const posts = this.getAllPosts();
    return posts.find((p) => p.id === id);
  }

  /**
   * 动态检索文章
   */
  public searchPosts(query: string): Post[] {
    const posts = this.getAllPosts();
    const trimmed = query.trim().toLowerCase();
    if (!trimmed) return posts;

    return posts.filter(
      (p) =>
        p.title.toLowerCase().includes(trimmed) ||
        p.content.toLowerCase().includes(trimmed) ||
        p.tags.some((t) => t.toLowerCase().includes(trimmed)) ||
        p.category.toLowerCase().includes(trimmed)
    );
  }

  /**
   * 清理缓存（支持热更新场景）
   */
  public clearCache(): void {
    this.postsCache = null;
  }
}

export const markdownService = new MarkdownService();

