/**
 * 🌌 VFS Git-Style Time-Travel & Version Diff Service
 */

export interface VFSCommit {
  hash: string;
  filePath: string;
  author: string;
  message: string;
  content: string;
  metadata?: Record<string, any>;
  createdAt: string;
  parentHash?: string;
}

export interface DiffLine {
  type: "added" | "removed" | "unchanged";
  oldLineNumber?: number;
  newLineNumber?: number;
  text: string;
}

export interface DiffResult {
  lineCount: number;
  additions: number;
  deletions: number;
  diffLines: DiffLine[];
}

export const vfsGitService = {
  /**
   * Fetch commit history for a file or all files
   */
  async getHistory(filePath?: string): Promise<{ count: number; history: VFSCommit[] }> {
    const url = filePath
      ? `/api/vfs/git/history?path=${encodeURIComponent(filePath)}`
      : `/api/vfs/git/history`;
    const res = await fetch(url);
    if (!res.ok) throw new Error("Failed to fetch commit history");
    return res.json();
  },

  /**
   * Fetch details of a single commit
   */
  async getCommit(hash: string): Promise<VFSCommit> {
    const res = await fetch(`/api/vfs/git/commit/${hash}`);
    if (!res.ok) throw new Error(`Failed to fetch commit ${hash}`);
    return res.json();
  },

  /**
   * Compute line-by-line diff
   */
  async computeDiff(params: {
    oldHash?: string;
    newHash?: string;
    oldText?: string;
    newText?: string;
  }): Promise<DiffResult> {
    const res = await fetch("/api/vfs/git/diff", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(params)
    });
    if (!res.ok) throw new Error("Failed to compute diff");
    return res.json();
  },

  /**
   * Create a snapshot commit manually
   */
  async createSnapshot(params: {
    filePath: string;
    author?: string;
    message: string;
    content: string;
    metadata?: Record<string, any>;
  }): Promise<{ success: boolean; commit: VFSCommit }> {
    const res = await fetch("/api/vfs/git/commit", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(params)
    });
    if (!res.ok) throw new Error("Failed to create commit snapshot");
    return res.json();
  },

  /**
   * Perform Time-Travel Rollback to specific commit
   */
  async rollback(hash: string): Promise<{ success: boolean; message: string; restoredCommit?: VFSCommit }> {
    const res = await fetch("/api/vfs/git/rollback", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ hash })
    });
    if (!res.ok) throw new Error("Failed to perform rollback");
    return res.json();
  }
};
