/**
 * ⚡ NebulaTide (星云潮汐) - 高可用 (HA) & 高性能 (HP) VFS 数据引擎
 * 集成 LRU 缓存、请求合并去重 (Request Coalescing)、熔断断路器 (CircuitBreaker) 与本地离线快照回退
 */

import { LRUCache } from "../architecture/LRUCache";
import { CircuitBreaker } from "../architecture/CircuitBreaker";
import { systemHealthMonitor } from "../architecture/SystemHealthMonitor";
import { globalEventBus } from "../architecture/EventBus";

export interface VFSFileItem {
  path: string;
  title: string;
  filename: string;
  updatedAt: string;
}

export interface VFSCategory {
  count: number;
  files: VFSFileItem[];
}

export interface VFSTreeResponse {
  totalCount: number;
  categories: Record<string, VFSCategory>;
}

export interface VFSFileDetail {
  path: string;
  category: string;
  title: string;
  filename: string;
  metadata: Record<string, any>;
  content: string;
  rawBody: string;
  updatedAt: string;
}

// 1. 高性能 LRU 缓存实例 (容量 200, 30秒 TTL)
const vfsCache = new LRUCache<string, any>({ capacity: 200, defaultTtlMs: 30000 });
systemHealthMonitor.registerLRUCache(vfsCache);

// 2. 高可用断路器 (CircuitBreaker) 容错降级配置
const vfsCircuitBreaker = new CircuitBreaker<any>({
  name: "VFS-Storage-Service",
  failureThreshold: 3,
  recoveryTimeoutMs: 15000,
  fallback: async (pathOrType?: string) => {
    console.warn("🛡️ [VFS HA Service] 激活离线本地快照与降级兜底逻辑");
    globalEventBus.emit("vfs:fallback-activated", { timestamp: new Date().toISOString() });
    
    // 如果是读取单个文件
    if (typeof pathOrType === 'string' && pathOrType.includes('.')) {
      const cachedLocal = localStorage.getItem(`vfs_offline_snapshot_${pathOrType}`);
      if (cachedLocal) {
        try {
          return JSON.parse(cachedLocal);
        } catch {
          // ignore corrupted snapshot
        }
      }
      return {
        path: pathOrType,
        category: "沙盒",
        title: "离线只读快照 (HA Fallback)",
        filename: pathOrType,
        metadata: { status: "offline_fallback" },
        content: "系统网络或远程 VFS 数据服务短暂休眠，已自动启动极高可用离线快照机制。",
        rawBody: "HA Fallback Mode",
        updatedAt: new Date().toISOString()
      };
    }

    // 默认兜底 Tree 数据结构，优先检索本地离线快照
    const treeSnapshot = localStorage.getItem("vfs_offline_tree_snapshot");
    if (treeSnapshot) {
      try {
        return JSON.parse(treeSnapshot);
      } catch {
        // ignore corrupted snapshot
      }
    }
    return {
      totalCount: 0,
      categories: {
        "宣言": { count: 0, files: [] },
        "火花": { count: 0, files: [] },
        "文章": { count: 0, files: [] },
        "项目": { count: 0, files: [] },
        "沙盒": { count: 0, files: [] },
        "档案": { count: 0, files: [] }
      }
    };
  },
  onStateChange: (state, name) => {
    globalEventBus.emit("circuit-breaker:state-changed", { name, state });
  }
});

systemHealthMonitor.registerCircuitBreaker(vfsCircuitBreaker);

export const vfsService = {
  /**
   * 获取 VFS 目录树，带高性能 LRU 缓存与去重
   */
  async getTree(): Promise<VFSTreeResponse> {
    return await vfsCache.getOrFetch("vfs:tree", async () => {
      return await vfsCircuitBreaker.execute(async () => {
        const res = await fetch("/api/vfs/tree");
        if (!res.ok) throw new Error(`HTTP Error ${res.status}`);
        const data = await res.json();
        // 更新离线本地快照以防万一
        localStorage.setItem("vfs_offline_tree_snapshot", JSON.stringify(data));
        return data;
      });
    }, 15000); // 15秒缓存
  },

  /**
   * 获取文件详情，带 LRU 缓存、合并去重与快速反写 snapshot
   */
  async getFile(path: string): Promise<VFSFileDetail | null> {
    const cacheKey = `vfs:file:${path}`;
    return await vfsCache.getOrFetch(cacheKey, async () => {
      return await vfsCircuitBreaker.execute(async () => {
        const res = await fetch(`/api/vfs/file?path=${encodeURIComponent(path)}`);
        if (!res.ok) {
          if (res.status === 404) return null;
          throw new Error(`HTTP Error ${res.status}`);
        }
        const fileDetail = await res.json();
        localStorage.setItem(`vfs_offline_snapshot_${path}`, JSON.stringify(fileDetail));
        return fileDetail;
      }, path);
    }, 60000); // 60秒缓存
  },

  /**
   * 搜索文件带去重与防击穿缓存
   */
  async searchFiles(query: string): Promise<VFSFileDetail[]> {
    if (!query || !query.trim()) return [];
    const cacheKey = `vfs:search:${query.trim().toLowerCase()}`;

    return await vfsCache.getOrFetch(cacheKey, async () => {
      return await vfsCircuitBreaker.execute(async () => {
        const res = await fetch(`/api/vfs/search?q=${encodeURIComponent(query)}`);
        if (!res.ok) throw new Error(`HTTP Error ${res.status}`);
        return await res.json();
      });
    }, 10000); // 10秒缓存
  },

  /**
   * 清理 VFS 缓存
   */
  clearCache() {
    vfsCache.clear();
  }
};
