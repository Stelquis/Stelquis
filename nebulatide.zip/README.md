# 🌌 NebulaTide (星云潮汐) - AI-Native 全栈心智与系统工程

<p align="left">
  <img src="https://img.shields.io/badge/Architecture-AI--Native%20Fullstack-0D9488?style=for-the-badge&logo=react&logoColor=white" alt="AI Native Fullstack" />
  <img src="https://img.shields.io/badge/Agent%20Skill-Square--Q%2Fsubconscious--skill-8B5CF6?style=for-the-badge&logo=github&logoColor=white" alt="Subconscious Skill" />
  <img src="https://img.shields.io/badge/AI%20Engine-Gemini%20%7C%20DeepSeek--V4-10B981?style=for-the-badge&logo=google&logoColor=white" alt="AI Engine" />
  <img src="https://img.shields.io/badge/Protocol-MCP%20v2024--11--05-14B8A6?style=for-the-badge&logo=anthropic&logoColor=white" alt="MCP Protocol" />
  <img src="https://img.shields.io/badge/Content%20Engine-Markdown%20%2B%20Frontmatter-EC4899?style=for-the-badge&logo=markdown&logoColor=white" alt="Markdown Engine" />
  <img src="https://img.shields.io/badge/Frontend-React%2018%20%2B%20Tailwind-6366F1?style=for-the-badge&logo=tailwindcss&logoColor=white" alt="Frontend" />
  <img src="https://img.shields.io/badge/Backend-Express.js%20%2B%20SQLite-3B82F6?style=for-the-badge&logo=express&logoColor=white" alt="Backend" />
  <img src="https://img.shields.io/badge/TypeScript-Strict%20Mode-3178C6?style=for-the-badge&logo=typescript&logoColor=white" alt="TypeScript" />
</p>

> **“清晰不是混沌的对立面，而是混沌的沉积物。潮起时航行，潮落时织网。”**  
> **NebulaTide** 是一个结合 **第一性原理心智哲学** 与 **AI-Native 云原生系统工程** 的全栈个人知识与沉淀系统。系统融合了 React 18 模块化前端、Express RESTful 后端、SQLite 持久化引擎、Square-Q 潜意识 Agent 思考技能、MCP (Model Context Protocol) 协议桥接层，以及基于文件驱动的全栈 Markdown 内容中心。

---

## 💡 核心哲学：心智流转三部曲 (Mindset Triad)

1. **☁️ 星云 (Nebula - 灵感沙盒)**：思绪初生时，允许它像星云般弥漫、缠绕、不打标签。在非结构化的暗处，让灵感自然碰撞。
2. **🌊 潮汐 (Tide - 周期复盘)**：复盘是自然的呼吸。像潮汐般退后一步，捡拾散落的贝壳（收获），划掉沙砾（反思），建立四周周度的反思地图。
3. **🕸️ 织网 (Weaving - 顺势规划)**：把复盘所得的贝壳编织成具象的“织网目标 (OKR)”，感知方向流向，顺势而为。

---

## ✨ 系统八大硬核架构特征 (Core Technical Highlights)

### 1. 🧠 Square-Q 潜意识心智与 Agent 反思层 (`subconscious-skill`)
- **潜意识思考层 (Subconscious Mind Layer)**：集成 [Square-Q/subconscious-skill](https://github.com/Square-Q/subconscious-skill.git) 规范。Agent 在回复前自动提炼用户未言明的深层哲学倾向与心智模式，形成隐式推理链 (Latent Reasoning Chain)。
- **反思引擎 (Reflection Loop)**：挂载 `reflectionEngine.ts`，支持对 Agent 输出的 Payload 与 Action 进行自我修护与字段对齐，保障 99%+ 的动作调用成功率。

### 2. 🔌 Anthropic MCP Protocol (Model Context Protocol v2024-11-05)
- **JSON-RPC 2.0 标准接口**：开放 API 端点 `/api/mcp`，提供 `mcpBridgeEngine.ts` 引擎。
- **Tools / Resources / Prompts 统一暴露**：内置 `nebulatide_subconscious_reflect`、`nebulatide_read_vfs_file`、`nebulatide_create_post` 等工具，实现与外部 Agent 和 IDE 系统的无缝缝合。

### 3. 📑 文件驱动与高可用 Markdown 内容服务
- **结构化存储**：站点文章解耦落盘于 `/content/posts/*.md`，支持标准 YAML Frontmatter 标头字段（标题、副标题、分类、标签、封面图、作者信息）。
- **双模高可用驱动**：`markdownService.ts` 引擎同时支持 Vite `import.meta.glob` 增量加载与内嵌 Fallback 静态安全降级，即便在极低配环境也能提供毫秒级响应。

### 4. ⚡ 语义缓存与 Agent 评估阵列 (Semantic Cache & Eval Harness)
- **语义击中率监控**：集成 `semanticCacheEngine.ts`，基于语义向量比对缓存高频问答，大幅削减 API Token 消耗与响应时延。
- **自动化测试阵列**：搭载 `evalHarnessEngine.ts`，内置 15+ 项自动化测试套件，实时评估 Agent 在系统中的回答精准度与鲁棒性。

### 5. 🌳 上下文感知与 VFS 虚拟文件系统 (VFS Context Awareness)
- **带上下文研讨**：全局 AI 智囊在对话框中键入 `@` 即可一键拉取站内 VFS 节点（包含文章、碎片、复盘记录与工程规范），彻底告别裸聊与幻觉。

### 6. ⏳ VFS Git-Style 时光倒流与版本 Diff (Time-Travel)
- **版本快照**：数据或文件变更时自动生成 Git Commit Hash 与版本快照。
- **可视化 Diff 面板**：通过 `VFSTimeTravelModal` 支持 Line-by-Line 行级代码/文本比对与一键 Rollback 还原。

### 7. 🎨 苹果玻璃美学与沉浸体验 (Apple-Style Aesthetics & Ambient Sound)
- **Light / Dark 极简双主题**：基于 Tailwind CSS v4 与 Motion 物理动画，实现随心切换的苹果高斯模糊 (Glassmorphic) 视觉系统。
- **Web Audio 双声道白噪音**：原生 Web Audio 算法生成海浪、夜雨与篝火声，为创作与复盘打造专注场域。

### 8. 📊 全栈监控与诊断中心 (`DevLogsAndStorageModal`)
- **时间线开发日志**：呈现自 v0.1.0 架构原型至 v1.7.0 的全量版本演进历史。
- **存储与缓存看盘**：支持全站数据库状态诊断、本地/云端同步检查与手动缓存清理。

---

## 🏗️ 全栈项目结构 (Project Structure)

```
NebulaTide Full-Stack System
├── 📄 content/                      # 结构化 Markdown 内容库
│   └── posts/                       # 静态与动态文章 Markdown 文件 (.md)
│
├── 🖥️ server/                       # Node.js + Express 全栈后端
│   ├── agent/                       # Agent 核心引擎阵列
│   │   ├── reflectionEngine.ts      # Agent 自自我反思与自修复引擎
│   │   ├── skillLoaderEngine.ts     # 动态技能加载器 (含 Square-Q/subconscious-skill)
│   │   ├── semanticCacheEngine.ts   # 语义缓存与 Token 优化引擎
│   │   ├── evalHarnessEngine.ts     # Agent 15+ 项自动化评估套件
│   │   └── vfsGitEngine.ts          # VFS Git 快照与版本 Diff 引擎
│   ├── db/                          # SQLite 持久化数据库及 REST 接口
│   ├── mcp/                         # MCP 协议桥接引擎 (mcpBridgeEngine.ts)
│   └── routes/                      # API 路由 (/api/ai, /api/mcp, /api/skills, /api/posts 等)
│
├── 🎨 src/                          # React 18 + TypeScript 前端源码
│   ├── components/
│   │   ├── ai/                      # GlobalAIAssistant 悬浮控制台与预览弹窗
│   │   ├── modals/                  # 全局模态框 (MCPSkillHub, DevLogs, Cmd+K, VFSTimeTravel)
│   │   ├── views/                   # 核心视图 (Manifesto, Articles, Thoughts, Rituals, Weaving)
│   │   └── widgets/                 # 沉浸小组件 (AmbientSoundPlayer, Visual Canvas)
│   ├── data/                        # 基础数据定义与静态降级 Payload
│   ├── services/                    # 通信与业务服务 (markdownService, aiService, mcpSkillService)
│   └── types/                       # 全栈 TypeScript 类型声明
│
├── server.ts                        # 全栈统一启动入口 (Dev 使用 tsx / Prod 使用 esbuild CJS)
└── vite.config.ts                   # Vite 前端构建与构建优化配置
```

---

## 🛠️ 技术选型表 (Tech Stack Breakdown)

| 层级 | 选用技术 | 功能描述 |
| :--- | :--- | :--- |
| **前端框架** | React 18, TypeScript, Vite | 模块化 SPA 架构、组件按需加载与严苛类型安全 |
| **样式与动画** | Tailwind CSS v4, Motion, Lucide Icons | 柔和高斯模糊、苹果级微光过渡与全响应式布局 |
| **AI 智能** | Gemini 2.5/3, DeepSeek-V4 | CoT 思考链展开、Agentic Action 执行与 Subconscious 潜意识隐式推理 |
| **Agent Skill** | Square-Q/subconscious-skill | 潜意识长效心智图谱、隐式意图对齐与暗流反思 |
| **开放协议** | Anthropic MCP v2024-11-05 | JSON-RPC 2.0 API、MCP Tools / Resources 标准开放 |
| **内容解析** | `react-markdown`, `gray-matter` | Markdown 语法解析、代码高亮与 Frontmatter 元数据提取 |
| **存储层** | SQLite (`sql.js`), localStorage | 离线优先持久化、版本快照回滚与前端高可用降级 |
| **音频引擎** | Web Audio API | 原生双声道沉浸式环境音效合成器 |

---

## ⚙️ 快速开始 (Quick Start)

### 1. 环境准备与依赖安装
确保本地安装有 Node.js (v18+) 及 npm 包管理器：
```bash
npm install
```

### 2. 启动全栈开发服务
运行统一开发命令，自动拉起 Express 后端 API 与 Vite 前端 HMR 热更新（统一监听在端口 `3000`）：
```bash
npm run dev
```

### 3. 项目编译与生产部署
项目内置打包指令，将前端打入 `dist/`，后端采用 `esbuild` 编译打包为自包含的单文件 `dist/server.cjs`：
```bash
# 执行全栈打包编译
npm run build

# 启动生产环境全栈服务
npm run start
```

---

## 📜 许可与著作权 (License & Copyright)

本项目采用 [MIT License](LICENSE) 授权开源。

© 2026 Niu (Stelquis) · **NebulaTide System** All Rights Reserved.  
*"🌌 潮起时航行，潮落时织网。—— 星云深处，自有暗流指引。🌊"*
