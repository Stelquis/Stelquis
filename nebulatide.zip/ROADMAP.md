# 🌌 NebulaTide (星云潮汐) - 演进路线图与 Agent 架构试验场 (Roadmap & Agent Sandbox)

<p justify="left">
  <img src="https://img.shields.io/badge/Architecture-Agentic%20Sandbox-0D9488?style=for-the-badge&logo=probot&logoColor=white" alt="Agentic Sandbox" />
  <img src="https://img.shields.io/badge/Protocol-MCP%20%2B%20Tool%20Healing-10B981?style=for-the-badge&logo=powershell&logoColor=white" alt="MCP & Tool Healing" />
  <img src="https://img.shields.io/badge/Version%20Control-VFS%20Git--Style%20Time%20Travel-6366F1?style=for-the-badge&logo=git&logoColor=white" alt="VFS Time Travel" />
  <img src="https://img.shields.io/badge/Optimization-Semantic%20Caching-F59E0B?style=for-the-badge&logo=googlecloud&logoColor=white" alt="Semantic Caching" />
</p>

> **“将全栈博客打造成现代 AI Agent 的前沿试炼场。”**  
> NebulaTide 不仅仅是一个 AI-Native 博客系统，更是一个集成了 MCP 协议、Skills 插件系统、Agentic Reflection 自省修护环与 Git 式 VFS 时光倒流的**极客全栈实验平台**。

---

## 🧭 核心演进规划 (Evolution Modules)

### 🤖 模块一：极客级 Agent 架构与试炼场 (Agentic Sandbox & Self-Healing)

#### 1. 🔄 Agentic Reflection Loop & Tool Healing (自省重试与自我修复环)
- **工程痛点**: 大模型在生成 JSON/Tool Calling 结构化载荷时，偶发 JSON 格式截断、语法错误或字段缺失，导致前端 Action 执行失败。
- **解决方案**: 在服务端 `/api/ai` 引入闭环 Reflection 机制。当 Tool Payload 校验失败或捕获 Error 时，不直接返回错误给用户，而是后台自动发起一次以诊断日志为 Context 的 **Re-Prompt Reflection**，修护语法与补全字段后自动再送达前端。

#### 2. 🔌 MCP (Model Context Protocol) 协议适配层
- **工程痛点**: 各 AI 框架的上下文与工具格式零散，缺乏统一接口标准。
- **解决方案**: 实现 Anthropic 标准 MCP (Model Context Protocol) 协议的服务端 Bridge。将星云潮汐的 SQLite 数据库、VFS 节点树、博客文章 CRUD 包装为标准 `MCP Resources` 与 `MCP Tools`，方便任意第三方 AI Agent 连接与调度。

#### 3. 🧩 Dynamic Skill Loader (技能插件化引擎)
- **工程痛点**: AI 智囊缺乏动态扩展新能力（如架构分析、SEO 自动润色、代码安全审计）的规则体系。
- **解决方案**: 借鉴 `SKILL.md` 规范，在 VFS 中建立 `/skills/` 节点目录。AI 智囊能够根据用户 Prompt 动态检索并加载专属 Skill 约束，无需硬编码系统提示词。

#### 4. 🧪 Agent Evaluation Harness (Agent 沙盒评估基准与真机测速套件)
- **工程痛点**: 缺乏测量 AI Agent 在真机复杂环境下的指令遵从度、Tool Calling 准确率与时延性能。
- **解决方案**: 建立全套自动化基准评估引擎 (`evalHarnessEngine.ts`)，针对 Tool Calling 提取、VFS 索引匹配、语义缓存命中与 Reflection 修复率进行定量打分，并在开发者面板与 AI 智囊中提供真机评测跑分界面。

---

### ⏳ 模块二：VFS Git-Style 版本追踪与时光倒流 (VFS Time-Travel & Version Graph)

#### 1. 📜 全栈节点快照与 Commit Graph (Node Snapshots)
- **工程原理**: 借助已抽象的 VFS 架构，每当用户或 AI Agent 对文章、专栏或配置进行修改（Create / Update / Delete）时，系统自动生成带 SHA Hash 的轻量 `Commit Snapshot`。
- **关联功能**: 记录作者、变更原因、Diff 差异与时间戳，构建 VFS 版本的有向无环图 (Commit Tree)。

#### 2. 🔀 可视化 Git-Style 动态 Diff 界面
- **前端呈现**: 在文章与专栏编辑视图中引入双栏/单栏行号对比面板 (`Line-by-Line Diff Viewer`)，使用绿/红色彩高亮展示每次修改与 AI 自动润色带来的变动。

#### 3. ⏪ 一键时光倒流 (Rollback & Version Switch)
- **一键回滚**: 用户可随时预览历史 Commit 快照，并点击“一键恢复至此版本”，实现全栈数据的版本自由切换与安全防御。

#### 4. 🪵 开发日志与工程演进自动 Commit (Dev Timeline)
- **自动日志**: 将整个 NebulaTide 工程的开发历程、架构重构事件统一录入 VFS Timeline 快照，形成图文并茂的“系统进化史”。

---

### ⚡ 模块三：语义缓存与 Token 优化器 (Semantic Caching & Token Optimizer)

#### 1. 🎯 轻量语义向量余弦缓存 (Semantic Caching Layer)
- **工程原理**: 在 Express 后端设立内存/SQLite 语义缓存区。对用户的 Prompt 计算文本特征与 HashMap，当相似度高于阈值 (>82%) 时，后端直接以毫秒级回放，避免大模型重复 Token 开销。

#### 2. ✂️ Context Keyframe 剪裁 (Context Window Pruning)
- **动态剪裁**: 基于 VFS 文件大小与 Token 消耗，智能提取 Markdown 节点的 H1/H2 标题与核心段落摘要作为 Keyframe，降低发送给大模型的上下文长度。

---

### 🕸️ 模块四：星潮知识拓扑图谱与开放数据枢纽 (Knowledge Topology & Open Data Hub)

#### 1. 🔮 交互式星网知识图谱 (Interactive Knowledge Constellation Map)
- **工程原理**: 实时分析文章、碎片、专栏与 VFS 节点之间的语义标签与交叉引用，采用 D3 / SVG 力导向图或拓扑星座图展现全站知识网络，支持节点点击穿透与 AI 智能关联推荐。

#### 2. 📦 零锁入 VFS 全栈数据导出与 RSS / Webhook 订阅 (Data Portability Studio)
- **数据开放**: 支持一键将 VFS 节点与博客数据打包导出为 JSON / Markdown Zip 包；提供符合标准的 RSS Feed / AI Summary Feed 接口，以及内容更新 Webhook 派发机制。

---

## 📅 落地推进计划 (Implementation Order)

- [x] **阶段 0**: 规范化架构优化、设计 Token 与统一主题调色板预设 (`/src/config/theme.ts`)
- [x] **阶段 1**: 落地 **Agentic Reflection Loop & Tool Healing** (实现自纠正与健壮的 Action 触发, `/server/agent/reflectionEngine.ts`)
- [x] **阶段 2**: 落地 **VFS Git-Style 时光倒流与版本 Diff** (快照生成、可视化 Diff 面板与一键回滚, `/server/agent/vfsGitEngine.ts`, `/src/components/modals/VFSTimeTravelModal.tsx`)
- [x] **阶段 3**: 落地 **MCP 协议桥接层与 Dynamic Skill Loader** (`/server/mcp/mcpBridgeEngine.ts`, `/server/agent/skillLoaderEngine.ts`, `/src/components/modals/MCPSkillHubModal.tsx`)
- [x] **阶段 4**: 落地 **语义缓存 (Semantic Caching)** 与智能 Token 裁剪 (`/server/agent/semanticCacheEngine.ts`, `/api/cache`, DevLogsAndStorageModal)
- [x] **阶段 5**: 落地 **Agent Evaluation Harness** (Agent 自动化评估基准与测速套件, `/server/agent/evalHarnessEngine.ts`, `/api/eval`, DevLogs 评估模态)
- [x] **阶段 6**: 落地 **交互式星网知识图谱 (Knowledge Constellation Map)** (`/src/components/widgets/KnowledgeGraphModal.tsx`)
- [x] **阶段 7**: 落地 **全栈 VFS 数据导出与 RSS Feed 开放枢纽** (`/api/feed.xml`, `/api/export`)

---

*“在星云潮汐中，代码与思想同频演进。”*
