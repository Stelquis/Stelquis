---
id: "post-deepastradraft"
title: "DeepAstraDraft：如何为 DWG/DXF 工业图纸注入 123 项语义索引与自然语言 Agent？"
subtitle: "从几何图元解析到多模态 CAD 智能问答系统"
excerpt: "CAD 图纸是工业界的通用语言，但缺乏可计算的结构化语义。本文拆解我们如何通过图结构提取、参数解析与 Agent 索引，实现 93.1% 的高精度问答..."
category: "系统构建"
tags: ["DeepAstraDraft", "CAD", "Agent", "LLM", "RAG"]
date: "2026-07-05"
readTime: "8 分钟"
coverImage: "https://images.unsplash.com/photo-1581092160607-ee22621dd758?q=80&w=1200&auto=format&fit=crop"
featured: true
likes: 112
authorName: "Niu (Stelquis)"
authorAvatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=200&auto=format&fit=crop"
authorRole: "CSU · AI / Data Science / Cloud-Native"
---

# DeepAstraDraft：CAD 图纸智能问答 Agent 架构拆解

在工业设计与工程建设中，DWG/DXF 格式存储了极其丰富的几何与尺寸信息。然而传统 CAD 数据往往呈现“散沙”状态。

## 1. 第一性原理：CAD 图元与工程语义的解耦
图纸表面上是线段、圆弧、块（Block）与文本（MText），但工程人员关心的本质是**“装配关系、极限偏差、材质属性与工序依赖”**。

- **解析层**：精准提取 DXF 实体层级，构建拓扑图。
- **语义层**：将 123 项核心参数（如公差、螺纹规格、倒角）映射至向量与属性图数据库。
- **Agent 交互层**：采用 Prompt-to-Query 生成器，通过多轮校验解决 CAD 专业用语歧义。

## 2. 核心成果
在测试集中，自然语言理解与参数检索准确率达到了 **93.1%**。这是 NebulaTide 哲学中“将散沙凝结成网络”的典型实战应用。
